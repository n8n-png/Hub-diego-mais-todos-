import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { higienizarTextoLivre } from "@/data/atendimento";

export type KbSource = {
  document_id: string;
  title: string;
  version: number;
  updated_at: string;
  category_name: string | null;
  doc_type: string;
  similarity: number;
};

export type AskResult = {
  answer: string;
  found: boolean;
  sources: KbSource[];
};

export type CopilotResult = {
  alertas: { tipo: "erro" | "atencao" | "info"; texto: string }[];
  checklist: { item: string; ok: boolean }[];
  sugestao: string;
  versao_humanizada: string;
  versao_profissional: string;
  sources: KbSource[];
};

type KbRow = KbSource & { chunk_id: string; content: string };

/** Busca híbrida: significado (embeddings) somado a palavras-chave (texto). */
async function retrieve(supabase: SupabaseClient<Database>, question: string, matchCount = 6) {
  const { embedTexts } = await import("./kb.server");
  const { embeddings, usage } = await embedTexts([question]);
  const { data, error } = await supabase.rpc("match_kb_chunks", {
    query_embedding: JSON.stringify(embeddings[0]),
    match_count: matchCount,
  });
  if (error) throw new Error("Falha ao consultar a base de conhecimento.");
  const vetorial = (data ?? []) as KbRow[];

  // Busca por palavras-chave: garante siglas, códigos e nomes exatos.
  const rpc = supabase.rpc as unknown as (
    nome: string,
    args: Record<string, unknown>,
  ) => Promise<{ data: unknown; error: unknown }>;
  let textual: KbRow[] = [];
  try {
    const res = await rpc("search_kb_chunks_text", {
      query_text: question,
      match_count: Math.max(2, Math.round(matchCount / 2)),
    });
    if (!res.error) textual = (res.data ?? []) as KbRow[];
  } catch {
    textual = [];
  }

  const mapa = new Map<string, KbRow>();
  for (const r of vetorial) mapa.set(r.chunk_id, r);
  for (const r of textual) {
    if (!mapa.has(r.chunk_id)) mapa.set(r.chunk_id, { ...r, similarity: 0.45 });
  }

  const ordenado = [...mapa.values()].sort((a, b) => b.similarity - a.similarity);
  return { rows: ordenado.slice(0, matchCount), usage };
}

function dedupeSources(rows: (KbSource & { content: string })[]): KbSource[] {
  const map = new Map<string, KbSource>();
  for (const r of rows) {
    const existing = map.get(r.document_id);
    if (!existing || r.similarity > existing.similarity) {
      map.set(r.document_id, {
        document_id: r.document_id,
        title: r.title,
        version: r.version,
        updated_at: r.updated_at,
        category_name: r.category_name,
        doc_type: r.doc_type,
        similarity: r.similarity,
      });
    }
  }
  return [...map.values()].sort((a, b) => b.similarity - a.similarity);
}

function buildContext(rows: (KbSource & { content: string })[]) {
  // Conflitos: o documento mais recente tem prioridade.
  const ordered = [...rows].sort(
    (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
  );
  return ordered
    .map(
      (r, i) =>
        `[DOC ${i + 1}] Título: ${r.title} | Categoria: ${r.category_name ?? " · "} | Tipo: ${r.doc_type} | Versão: v${r.version} | Atualizado em: ${new Date(r.updated_at).toLocaleDateString("pt-BR")}\n${r.content}`,
    )
    .join("\n\n---\n\n");
}

const BASE_RULES = `Você é a Maisa, assistente oficial do Hub MaisTODOS, especialista sênior em atendimento e operação da empresa MaisTODOS. Fale como Maisa, com voz acolhedora e profissional, frases curtas e sempre terminando com o próximo passo. Nunca use travessão nem emoji.
Você recebe duas fontes de contexto: os documentos oficiais da base de conhecimento e o conteúdo publicado nas páginas do Hub, como Operação, Crédito PF, Conta Digital, Logística, Pagamentos, módulos de Atendimento, ferramentas, financeiras, comunicados e materiais.
Regras obrigatórias:
- Responda EXCLUSIVAMENTE com base no contexto fornecido, usando as duas fontes quando ajudarem.
- Quando a resposta vier do conteúdo do Hub, indique o caminho na plataforma onde o colaborador resolve o assunto.
- Se a resposta não estiver no contexto, diga claramente que não há procedimento oficial cadastrado e sugira falar com um supervisor ou abrir chamado. Nunca invente.
- Se dois documentos se contradisserem, use o mais recente e avise sobre a divergência.

- Sempre cite ao final: documento utilizado, versão e data da última atualização.
- Escreva em português do Brasil, de forma objetiva e em passos quando for procedimento. Use markdown.`;

/** Indexa (ou reindexa) um documento gerando embeddings dos seus trechos. Somente admin. */
export const indexDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ documentId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) throw new Error("Apenas administradores podem treinar a IA.");

    const { data: doc, error } = await supabase
      .from("kb_documents")
      .select("id, title, content, status")
      .eq("id", data.documentId)
      .maybeSingle();
    if (error || !doc) throw new Error("Documento não encontrado.");

    const { chunkText, embedTexts } = await import("./kb.server");
    const chunks = chunkText(`${doc.title}\n\n${doc.content ?? ""}`);
    await supabase.from("kb_chunks").delete().eq("document_id", doc.id);

    if (chunks.length === 0) {
      await supabase.from("kb_documents").update({ indexed_at: null }).eq("id", doc.id);
      return { chunks: 0 };
    }

    const { embeddings, usage } = await embedTexts(chunks);
    const { registrarUso } = await import("./ai-usage.server");
    const { EMBEDDING_MODEL } = await import("./kb.server");
    await registrarUso({
      kind: "index",
      model: EMBEDDING_MODEL,
      usage,
      userId,
      ref: doc.title,
    });
    const rows = chunks.map((content, i) => ({
      document_id: doc.id,
      chunk_index: i,
      content,
      embedding: JSON.stringify(embeddings[i]),
    }));
    const { error: insErr } = await supabase.from("kb_chunks").insert(rows);
    if (insErr) throw new Error("Falha ao salvar os trechos indexados.");

    await supabase
      .from("kb_documents")
      .update({ indexed_at: new Date().toISOString() })
      .eq("id", doc.id);
    return { chunks: chunks.length };
  });

export type SyncNotionWorkspaceResult = {
  workspace: string;
  paginas_encontradas: number;
  paginas_atualizadas: number;
  paginas_puladas: number;
  trechos_indexados: number;
  erro?: string;
};

export type SyncNotionResult = {
  paginas_encontradas: number;
  paginas_atualizadas: number;
  paginas_puladas: number;
  trechos_indexados: number;
  workspaces: SyncNotionWorkspaceResult[];
};

/**
 * Sincroniza as páginas do Notion compartilhadas com cada integração e as
 * indexa no mesmo pipeline de chunk e embedding usado pelos documentos.
 * Suporta vários workspaces, um token por workspace. Somente admin.
 * A falha de um workspace não interrompe os demais.
 */
export const syncNotion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<SyncNotionResult> => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) throw new Error("Apenas administradores podem sincronizar o Notion.");

    const { listarPaginas, lerConteudo, pausa, lerWorkspaces } = await import("./notion.server");
    const { chunkText, embedTexts, somarUso, usoVazio, EMBEDDING_MODEL } =
      await import("./kb.server");
    const { registrarUso } = await import("./ai-usage.server");

    const workspaces = lerWorkspaces();
    let usoNotion = usoVazio();
    const resumos: SyncNotionWorkspaceResult[] = [];

    for (const ws of workspaces) {
      const resumo: SyncNotionWorkspaceResult = {
        workspace: ws.workspace,
        paginas_encontradas: 0,
        paginas_atualizadas: 0,
        paginas_puladas: 0,
        trechos_indexados: 0,
      };

      try {
        const paginas = await listarPaginas(ws.token);
        resumo.paginas_encontradas = paginas.length;

        for (const pagina of paginas) {
          const { data: existente } = await supabase
            .from("kb_documents")
            .select("id, source_updated_at")
            .eq("notion_page_id", pagina.id)
            .maybeSingle();

          if (existente?.source_updated_at === pagina.lastEditedTime) {
            resumo.paginas_puladas++;
            continue;
          }

          await pausa();
          const conteudo = await lerConteudo(ws.token, pagina.id);

          const registro = {
            title: pagina.title,
            content: conteudo,
            doc_type: "notion" as const,
            notion_page_id: pagina.id,
            notion_url: pagina.url,
            source_updated_at: pagina.lastEditedTime,
            status: "ativo" as const,
            author_name: `Notion · ${ws.workspace}`,
          };

          let documentoId = existente?.id;
          if (documentoId) {
            const { error } = await supabase
              .from("kb_documents")
              .update(registro)
              .eq("id", documentoId);
            if (error) throw new Error(`Não foi possível salvar a página "${pagina.title}".`);
          } else {
            const { data: criado, error } = await supabase
              .from("kb_documents")
              .insert(registro)
              .select("id")
              .single();
            if (error || !criado)
              throw new Error(`Não foi possível salvar a página "${pagina.title}".`);
            documentoId = criado.id;
          }

          await supabase.from("kb_chunks").delete().eq("document_id", documentoId);

          const pedacos = chunkText(`${pagina.title}\n\n${conteudo}`);
          if (pedacos.length > 0) {
            const { embeddings, usage } = await embedTexts(pedacos);
            usoNotion = somarUso(usoNotion, usage);
            const { error: insErr } = await supabase.from("kb_chunks").insert(
              pedacos.map((content, i) => ({
                document_id: documentoId!,
                chunk_index: i,
                content,
                embedding: JSON.stringify(embeddings[i]),
              })),
            );
            if (insErr) throw new Error(`Falha ao indexar a página "${pagina.title}".`);
            resumo.trechos_indexados += pedacos.length;
          }

          await supabase
            .from("kb_documents")
            .update({ indexed_at: pedacos.length > 0 ? new Date().toISOString() : null })
            .eq("id", documentoId);

          resumo.paginas_atualizadas++;
          await pausa();
        }
      } catch (e) {
        resumo.erro =
          e instanceof Error && e.message
            ? e.message
            : "Falha desconhecida ao sincronizar este workspace.";
      }

      resumos.push(resumo);
    }

    await registrarUso({
      kind: "notion",
      model: EMBEDDING_MODEL,
      usage: usoNotion,
      userId,
      ref: "sincronização",
    });

    return {
      paginas_encontradas: resumos.reduce((s, r) => s + r.paginas_encontradas, 0),
      paginas_atualizadas: resumos.reduce((s, r) => s + r.paginas_atualizadas, 0),
      paginas_puladas: resumos.reduce((s, r) => s + r.paginas_puladas, 0),
      trechos_indexados: resumos.reduce((s, r) => s + r.trechos_indexados, 0),
      workspaces: resumos,
    };
  });

/** Pergunta livre à MaisIA usando apenas conteúdo oficial (RAG). */
export const askKb = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        question: z.string().min(2).max(2000),
        history: z
          .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
          .max(12)
          .optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }): Promise<AskResult> => {
    const { supabase, userId } = context;
    const { chatCompletion, somarUso, EMBEDDING_MODEL, CHAT_MODEL } = await import("./kb.server");
    const { registrarUso } = await import("./ai-usage.server");
    const { buscarPlataforma } = await import("./plataforma-conhecimento.server");

    // ATENÇÃO: pergunta, histórico e trechos saem do ambiente e vão para o
    // gateway externo de IA, inclusive no cálculo de embedding. Por isso a
    // higienização acontece ANTES de qualquer chamada a terceiro. O texto
    // original é usado apenas em memória, na busca dentro da plataforma.
    const perguntaHigienizada = higienizarTextoLivre(data.question);
    const historicoHigienizado = (data.history ?? []).map((m) => ({
      role: m.role,
      content: higienizarTextoLivre(m.content),
    }));

    // Primeiro passe econômico: 3 trechos da base e 3 do conteúdo do Hub.
    const primeiro = await retrieve(supabase, perguntaHigienizada, 3);
    let usoBusca = primeiro.usage;
    let relevant = primeiro.rows.filter((r) => r.similarity > 0.14);
    let plataforma = buscarPlataforma(data.question, 3);

    // Se o contexto curto não trouxe material suficiente, amplia a busca.
    const contextoFraco = relevant.length + plataforma.length < 3;
    if (contextoFraco) {
      const amplo = await retrieve(supabase, perguntaHigienizada, 12);
      usoBusca = somarUso(usoBusca, amplo.usage);
      relevant = amplo.rows.filter((r) => r.similarity > 0.14);
      plataforma = buscarPlataforma(data.question, 6);
    }

    let answer: string;
    let uso = usoBusca;
    let modelo = EMBEDDING_MODEL;
    if (relevant.length === 0 && plataforma.length === 0) {
      answer =
        "Não encontrei nenhum procedimento oficial cadastrado sobre isso na base de conhecimento da empresa. Recomendo falar com um supervisor ou abrir um chamado para que o conteúdo seja incluído pelos administradores.";
    } else {
      const blocos: string[] = [];
      if (relevant.length > 0) {
        blocos.push(`Documentos oficiais da base de conhecimento:\n\n${buildContext(relevant)}`);
      }
      if (plataforma.length > 0) {
        blocos.push(
          `Conteúdo publicado no Hub MaisTODOS (páginas da plataforma):\n\n${plataforma
            .map(
              (p, i) => `[HUB ${i + 1}] ${p.titulo} | Caminho na plataforma: ${p.rota}\n${p.texto}`,
            )
            .join("\n\n---\n\n")}`,
        );
      }
      const resposta = await chatCompletion([
        { role: "system", content: BASE_RULES },
        ...historicoHigienizado,
        {
          role: "user",
          content: `${blocos.join("\n\n=====\n\n")}\n\nPergunta do colaborador: ${perguntaHigienizada}`,
        },
      ]);
      answer = resposta.text;
      uso = somarUso(usoBusca, resposta.usage);
      modelo = CHAT_MODEL;
    }

    await registrarUso({
      kind: "ask",
      model: modelo,
      usage: uso,
      userId,
      ref: perguntaHigienizada,
    });

    const sources = dedupeSources(relevant);
    const encontrado = sources.length > 0 || plataforma.length > 0;
    await supabase.from("ai_queries").insert({
      user_id: userId,
      question: perguntaHigienizada,
      // A resposta pode repetir dado que veio na pergunta: higienizada também.
      answer: higienizarTextoLivre(answer),
      used_document_ids: sources.map((s) => s.document_id),
      found: encontrado,
    });

    return { answer, found: encontrado, sources };
  });

/** Copiloto: revisa o rascunho do colaborador antes do envio. */
export const copilotReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        draft: z.string().min(1).max(4000),
        situation: z.string().max(2000).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }): Promise<CopilotResult> => {
    const { supabase, userId } = context;
    // ATENÇÃO: o conteúdo abaixo sai do ambiente e vai para um gateway externo de IA.
    // Por isso o rascunho e a situação são higienizados: CPF, e-mail e telefone
    // são substituídos por [cpf], [email] e [telefone] antes do envio.
    const rascunho = higienizarTextoLivre(data.draft);
    const situacao = data.situation ? higienizarTextoLivre(data.situation) : "";
    const query = `${situacao}\n${rascunho}`.trim();
    const { rows, usage: usoBusca } = await retrieve(supabase, query, 6);
    const relevant = rows.filter((r) => r.similarity > 0.15);
    const { chatCompletion, somarUso, CHAT_MODEL } = await import("./kb.server");
    const { registrarUso } = await import("./ai-usage.server");

    const resposta = await chatCompletion(
      [
        {
          role: "system",
          content: `${BASE_RULES}\n\nVocê está atuando como COPILOTO em tempo real durante um atendimento. Analise o rascunho do colaborador comparando com os documentos oficiais e responda SOMENTE com JSON válido no formato:
{"alertas":[{"tipo":"erro|atencao|info","texto":"..."}],"checklist":[{"item":"...","ok":true|false}],"sugestao":"resposta pronta recomendada","versao_humanizada":"...","versao_profissional":"..."}
Aponte dados faltantes (CPF, comprovante, protocolo), prazos, políticas, macros e procedimentos aplicáveis. Se não houver documento oficial relacionado, deixe alertas com tipo "info" avisando isso e não invente regras.`,
        },
        {
          role: "user",
          content: `Documentos oficiais:\n\n${relevant.length ? buildContext(relevant) : "(nenhum documento oficial relacionado encontrado)"}\n\nSituação do atendimento: ${situacao || "(não informada)"}\n\nRascunho da resposta do colaborador:\n${rascunho}`,
        },
      ],
      { json: true },
    );
    const raw = resposta.text;

    await registrarUso({
      kind: "copilot",
      model: CHAT_MODEL,
      usage: somarUso(usoBusca, resposta.usage),
      userId,
      ref: "revisão de rascunho",
    });

    let parsed: Partial<CopilotResult> = {};
    try {
      parsed = JSON.parse(raw.replace(/^```json\s*|```$/g, "").trim());
    } catch {
      parsed = { sugestao: raw };
    }

    return {
      alertas: parsed.alertas ?? [],
      checklist: parsed.checklist ?? [],
      sugestao: parsed.sugestao ?? "",
      versao_humanizada: parsed.versao_humanizada ?? "",
      versao_profissional: parsed.versao_profissional ?? "",
      sources: dedupeSources(relevant),
    };
  });
