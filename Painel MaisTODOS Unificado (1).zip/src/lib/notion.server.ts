/**
 * Cliente server-side da API do Notion. Nunca importar no browser.
 * Suporta múltiplos workspaces: o token é sempre recebido por argumento e vem
 * de NOTION_TOKENS (ou NOTION_TOKEN). O token nunca é exposto ou logado.
 */

const NOTION_API = "https://api.notion.com/v1";
const NOTION_VERSION = "2022-06-28";

export type NotionPage = {
  id: string;
  url: string;
  title: string;
  lastEditedTime: string;
};

export type NotionWorkspace = {
  workspace: string;
  token: string;
};

/**
 * Lê a configuração de tokens do ambiente, na ordem de preferência:
 * NOTION_TOKENS (JSON array de strings ou de objetos, ou lista separada por
 * vírgula ou quebra de linha) e depois NOTION_TOKEN (um único token).
 */
export function lerWorkspaces(): NotionWorkspace[] {
  const bruto = (process.env["NOTION_TOKENS"] ?? "").trim();
  const entradas: { workspace?: string; token: string }[] = [];

  if (bruto) {
    let json: unknown = null;
    try {
      json = JSON.parse(bruto);
    } catch {
      json = null;
    }

    if (Array.isArray(json)) {
      for (const item of json) {
        if (typeof item === "string" && item.trim()) {
          entradas.push({ token: item.trim() });
        } else if (item && typeof item === "object") {
          const obj = item as Record<string, unknown>;
          const token = String(obj["token"] ?? "").trim();
          const workspace = String(obj["workspace"] ?? obj["name"] ?? "").trim();
          if (token) entradas.push({ token, ...(workspace ? { workspace } : {}) });
        }
      }
    } else {
      for (const parte of bruto.split(/[\n,]+/)) {
        const token = parte.trim();
        if (token) entradas.push({ token });
      }
    }
  }

  if (entradas.length === 0) {
    const unico = (process.env["NOTION_TOKEN"] ?? "").trim();
    if (unico) entradas.push({ token: unico, workspace: "Workspace 1" });
  }

  if (entradas.length === 0) {
    throw new Error(
      "Integração do Notion não configurada. Adicione o segredo NOTION_TOKENS, um token por workspace, ou NOTION_TOKEN para um único workspace, no Lovable Cloud.",
    );
  }

  return entradas.map((e, i) => ({
    workspace: e.workspace && e.workspace.length > 0 ? e.workspace : `Workspace ${i + 1}`,
    token: e.token,
  }));
}

function pausa(ms = 350) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function notionFetch(token: string, path: string, init: RequestInit = {}) {
  const res = await fetch(`${NOTION_API}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Notion-Version": NOTION_VERSION,
      "Content-Type": "application/json",
    },
  });
  if (!res.ok) {
    const body = await res.text();
    // Nunca inclui o token na mensagem, apenas o status e o motivo do Notion.
    const motivo = body
      .replace(/secret_[A-Za-z0-9]+|ntn_[A-Za-z0-9]+/g, "***")
      .split(token)
      .join("***")
      .slice(0, 300);
    if (res.status === 401) {
      throw new Error(
        "O Notion recusou a credencial deste workspace. Verifique o token configurado.",
      );
    }
    if (res.status === 429) {
      throw new Error(
        "O Notion pediu para aguardar, muitas chamadas seguidas. Tente novamente em instantes.",
      );
    }
    throw new Error(`Falha na API do Notion (${res.status}): ${motivo}`);
  }
  return (await res.json()) as Record<string, unknown>;
}

function textoRico(rich: unknown): string {
  if (!Array.isArray(rich)) return "";
  return rich
    .map((r) => (r as { plain_text?: string }).plain_text ?? "")
    .join("")
    .trim();
}

function tituloDaPagina(page: Record<string, unknown>): string {
  const props = (page["properties"] ?? {}) as Record<string, Record<string, unknown>>;
  for (const prop of Object.values(props)) {
    if (prop && prop["type"] === "title") {
      const t = textoRico(prop["title"]);
      if (t) return t;
    }
  }
  return "Página do Notion sem título";
}

/** Lista todas as páginas compartilhadas com a integração, com paginação. */
export async function listarPaginas(token: string): Promise<NotionPage[]> {
  const paginas: NotionPage[] = [];
  let cursor: string | undefined;

  for (let volta = 0; volta < 50; volta++) {
    const json = await notionFetch(token, "/search", {
      method: "POST",
      body: JSON.stringify({
        filter: { property: "object", value: "page" },
        page_size: 100,
        ...(cursor ? { start_cursor: cursor } : {}),
      }),
    });
    const results = (json["results"] ?? []) as Record<string, unknown>[];
    for (const page of results) {
      paginas.push({
        id: String(page["id"]),
        url: String(page["url"] ?? ""),
        title: tituloDaPagina(page),
        lastEditedTime: String(page["last_edited_time"] ?? new Date().toISOString()),
      });
    }
    if (!json["has_more"]) break;
    cursor = String(json["next_cursor"]);
    await pausa();
  }

  return paginas;
}

const PREFIXOS: Record<string, string> = {
  heading_1: "# ",
  heading_2: "## ",
  heading_3: "### ",
  bulleted_list_item: "- ",
  numbered_list_item: "1. ",
  quote: "> ",
  callout: "> ",
};

/** Lê o conteúdo de uma página do Notion como texto legível, descendo nos blocos filhos. */
export async function lerConteudo(token: string, blockId: string, nivel = 0): Promise<string> {
  if (nivel > 3) return "";
  const linhas: string[] = [];
  let cursor: string | undefined;

  for (let volta = 0; volta < 50; volta++) {
    const query = new URLSearchParams({ page_size: "100" });
    if (cursor) query.set("start_cursor", cursor);
    const json = await notionFetch(token, `/blocks/${blockId}/children?${query.toString()}`);
    const results = (json["results"] ?? []) as Record<string, unknown>[];

    for (const block of results) {
      const tipo = String(block["type"]);
      const dados = (block[tipo] ?? {}) as Record<string, unknown>;
      const suportado =
        tipo in PREFIXOS ||
        tipo === "paragraph" ||
        tipo === "to_do" ||
        tipo === "toggle" ||
        tipo === "code";

      if (suportado) {
        const texto = textoRico(dados["rich_text"]);
        if (texto) {
          const recuo = "  ".repeat(nivel);
          if (tipo === "to_do") {
            linhas.push(`${recuo}${dados["checked"] ? "[x]" : "[ ]"} ${texto}`);
          } else if (tipo === "code") {
            linhas.push(`${recuo}\`\`\`\n${texto}\n\`\`\``);
          } else {
            linhas.push(`${recuo}${PREFIXOS[tipo] ?? ""}${texto}`);
          }
        }
      }

      if (block["has_children"]) {
        await pausa();
        const filhos = await lerConteudo(token, String(block["id"]), nivel + 1);
        if (filhos.trim()) linhas.push(filhos);
      }
    }

    if (!json["has_more"]) break;
    cursor = String(json["next_cursor"]);
    await pausa();
  }

  return linhas.join("\n");
}

export { pausa };
