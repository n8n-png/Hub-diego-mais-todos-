/**
 * Conhecimento estático da plataforma para o assistente.
 * Transforma o conteúdo das áreas de Operação, Logística, Conta Digital e
 * Atendimento em documentos de texto pesquisáveis por palavra-chave, para que o
 * assistente responda também sobre o que está publicado no Hub, e não apenas
 * sobre os documentos indexados na base de conhecimento.
 */

import { areas, areaSections } from "@/data/operacao";
import {
  fluxosLogistica,
  automacoesLogistica,
  papeisLogistica,
  sistemasLogistica,
} from "@/data/logistica";
import {
  passosOnboarding,
  providersOnboarding,
  documentosPorTipo,
  retornosOnboarding,
  motivosBankly,
  cadeiaDecisoes,
  glossarioOnboarding,
  acoesRapidas,
} from "@/data/conta-digital";
import { atendimentoModulos } from "@/data/atendimento-modulos";
import { topicosNavegacao } from "@/data/navegacao-assistente";

export type PlataformaDoc = {
  id: string;
  titulo: string;
  rota: string;
  texto: string;
};

/** Serializa qualquer estrutura de dados em texto legível, sem campos técnicos. */
function serializar(valor: unknown, nivel = 0): string {
  const recuo = "  ".repeat(Math.min(nivel, 4));
  if (valor == null || valor === "") return "";
  if (typeof valor === "string" || typeof valor === "number" || typeof valor === "boolean") {
    return `${valor}`;
  }
  if (Array.isArray(valor)) {
    return valor
      .map((item) => {
        const texto = serializar(item, nivel + 1);
        if (!texto) return "";
        return texto.includes("\n") ? `${recuo}- ${texto.trim()}` : `${recuo}- ${texto}`;
      })
      .filter(Boolean)
      .join("\n");
  }
  if (typeof valor === "object") {
    return Object.entries(valor as Record<string, unknown>)
      .filter(
        ([chave]) => !["imagem", "imagemAlt", "emoji", "icon", "classe", "tom"].includes(chave),
      )
      .map(([chave, v]) => {
        const texto = serializar(v, nivel + 1);
        if (!texto) return "";
        return texto.includes("\n") ? `${recuo}${chave}:\n${texto}` : `${recuo}${chave}: ${texto}`;
      })
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

function doc(id: string, titulo: string, rota: string, conteudo: unknown): PlataformaDoc {
  return { id, titulo, rota, texto: serializar(conteudo).trim() };
}

let cache: PlataformaDoc[] | null = null;

/** Monta o corpus com todo o conteúdo publicado na plataforma. */
export function corpusPlataforma(): PlataformaDoc[] {
  if (cache) return cache;
  const docs: PlataformaDoc[] = [];

  for (const area of areas.filter((a) => a.disponivel)) {
    const base = `/operacao/${area.slug}`;
    const secoes = area.secoes ?? areaSections;
    docs.push(
      doc(`area-${area.slug}`, `Operação · ${area.nome}`, base, {
        descricao: area.descricao,
        "guia da operação": secoes
          .filter((s) => s.grupo === "guia")
          .map((s) => ({ card: s.nome, rota: `${base}/${s.slug}` })),
        "rotinas de trabalho": secoes
          .filter((s) => s.grupo === "rotinas")
          .map((s) => ({ card: s.nome, rota: `${base}/${s.slug}` })),
      }),
    );
    if (area.fluxoOperacao) {
      docs.push(
        doc(
          `fluxo-${area.slug}`,
          `${area.nome} · Guia da operação · Fluxo da operação`,
          `${base}/fluxo`,
          area.fluxoOperacao,
        ),
      );
      for (const etapa of area.fluxoOperacao.etapas ?? []) {
        docs.push(
          doc(
            `fluxo-${area.slug}-${normalizar(etapa.titulo).replace(/[^a-z0-9]+/g, "-")}`,
            `${area.nome} · Etapa do fluxo · ${etapa.titulo}`,
            `${base}/fluxo`,
            etapa,
          ),
        );
      }
    }
    for (const ferramenta of area.ferramentas) {
      docs.push(
        doc(
          `ferramenta-${area.slug}-${ferramenta.slug}`,
          `${area.nome} · Ferramenta · ${ferramenta.nome}`,
          `${base}/ferramentas`,
          ferramenta,
        ),
      );
    }
    for (const financeira of area.financeiras) {
      docs.push(
        doc(
          `financeira-${area.slug}-${financeira.slug}`,
          `${area.nome} · Financeira parceira · ${financeira.nome}`,
          `${base}/financeiras`,
          financeira,
        ),
      );
    }
    if (area.comercial.length) {
      docs.push(
        doc(
          `comercial-${area.slug}`,
          `${area.nome} · Time comercial`,
          `${base}/comercial`,
          area.comercial,
        ),
      );
    }
    for (const material of area.materiais) {
      docs.push(
        doc(
          `material-${area.slug}-${normalizar(material.titulo).replace(/[^a-z0-9]+/g, "-")}`,
          `${area.nome} · Guia da operação · Material · ${material.titulo}`,
          `${base}/materiais`,
          material,
        ),
      );
    }
    for (const comunicado of area.comunicados) {
      docs.push(
        doc(
          `comunicado-${area.slug}-${comunicado.data}`,
          `${area.nome} · Guia da operação · Comunicado · ${comunicado.titulo}`,
          `${base}/comunicados`,
          comunicado,
        ),
      );
    }
  }

  for (const fluxo of fluxosLogistica) {
    docs.push(
      doc(
        `logistica-${fluxo.slug}`,
        `Logística · ${fluxo.nome}`,
        `/operacao/logistica/fluxos?fluxo=${fluxo.slug}`,
        {
          resumo: fluxo.resumo,
          sistemas: fluxo.sistemas,
          passos: fluxo.passos,
          pontosCriticos: fluxo.pontosCriticos,
          notas: fluxo.notas,
        },
      ),
    );
  }
  docs.push(
    doc(
      "logistica-apoio",
      "Logística · Automações, papéis e sistemas",
      "/operacao/logistica/fluxos",
      {
        automacoes: automacoesLogistica,
        papeis: papeisLogistica,
        sistemas: sistemasLogistica,
      },
    ),
  );

  docs.push(
    doc(
      "cd-onboarding",
      "Conta Digital · Fluxo de onboarding",
      "/operacao/conta-digital/onboarding",
      {
        providers: providersOnboarding,
        passos: passosOnboarding,
        documentosPorTipo,
        retornosPorEtapa: retornosOnboarding,
      },
    ),
  );
  docs.push(
    doc(
      "cd-reprovacoes",
      "Conta Digital · Reprovações e glossário",
      "/operacao/conta-digital/reprovacoes",
      {
        motivosBankly,
        cadeiaDecisoes,
        glossario: glossarioOnboarding,
        acoesRapidas,
      },
    ),
  );

  docs.push(
    doc(
      "atendimento-modulos",
      "Operação App · Módulos de atendimento",
      "/operacao/app",
      atendimentoModulos,
    ),
  );

  docs.push(
    doc(
      "mapa-navegacao",
      "Onde resolver cada assunto na plataforma",
      "/dashboard",
      topicosNavegacao.map((t) => ({
        assunto: t.titulo,
        caminho: t.caminho,
        rota: t.rota,
        palavras: t.palavras,
      })),
    ),
  );

  cache = docs.filter((d) => d.texto.length > 0);
  return cache;
}

function normalizar(texto: string) {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

const STOPWORDS = new Set([
  "como",
  "para",
  "onde",
  "qual",
  "quais",
  "quando",
  "porque",
  "por",
  "que",
  "uma",
  "dos",
  "das",
  "com",
  "sobre",
  "fazer",
  "preciso",
  "pode",
  "posso",
  "tem",
  "the",
  "and",
  "essa",
  "esse",
  "isso",
  "meu",
  "minha",
  "nao",
  "não",
  "mais",
  "todos",
]);

/** Busca lexical simples no conteúdo da plataforma. */
export function buscarPlataforma(pergunta: string, limite = 4): PlataformaDoc[] {
  const termos = [
    ...new Set(
      normalizar(pergunta)
        .split(/[^a-z0-9]+/)
        .filter((t) => t.length >= 4 && !STOPWORDS.has(t)),
    ),
  ];
  if (termos.length === 0) return [];

  const pontuados = corpusPlataforma().map((d) => {
    const titulo = normalizar(d.titulo);
    const corpo = normalizar(d.texto);
    let pontos = 0;
    for (const termo of termos) {
      if (titulo.includes(termo)) pontos += 5;
      const ocorrencias = corpo.split(termo).length - 1;
      if (ocorrencias > 0) pontos += Math.min(ocorrencias, 6);
    }
    return { d, pontos };
  });

  return pontuados
    .filter((p) => p.pontos >= 3)
    .sort((a, b) => b.pontos - a.pontos)
    .slice(0, limite)
    .map((p) => ({ ...p.d, texto: p.d.texto.slice(0, 6000) }));
}
