import { supabase } from "@/integrations/supabase/client";
import { sanitizarPayloadAuditoria, higienizarTextoLivre } from "@/data/atendimento";

/**
 * Auditoria das ações sensíveis do Atendimento.
 *
 * Toda ação confirmada pelo colaborador é gravada em atendimento_auditoria.
 * A tabela é somente de inserção e leitura: ninguém edita nem apaga registros,
 * garantindo a integridade da trilha.
 *
 * Além do banco, mantemos um espelho em memória para a tela de Auditoria
 * mostrar o registro imediatamente, mesmo antes de recarregar a lista.
 */

export type RegistroAuditoria = {
  id: string;
  modulo: string;
  acao: string;
  alvo: string | null;
  payload: unknown;
  resultado: string;
  observacao: string | null;
  user_name: string | null;
  created_at: string;
};

const espelho: RegistroAuditoria[] = [];

export function auditoriaEmMemoria(): RegistroAuditoria[] {
  return [...espelho];
}

export type NovaAuditoria = {
  modulo: string;
  acao: string;
  alvo?: string | null;
  payload: unknown;
  resultado?: string;
  observacao?: string | null;
};

/**
 * Registra a ação. Nunca lança: falha de auditoria não deve travar a tela,
 * mas o resultado indica se a gravação no banco funcionou.
 */
export async function registrarAuditoria(
  entrada: NovaAuditoria,
): Promise<{ gravado: boolean; erro?: string }> {
  const agora = new Date().toISOString();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;

  // LGPD: nenhum dado pessoal completo entra na trilha de auditoria.
  const payloadSeguro = sanitizarPayloadAuditoria(entrada.payload);

  const local: RegistroAuditoria = {
    id: `local-${agora}-${Math.random().toString(36).slice(2, 8)}`,
    modulo: entrada.modulo,
    acao: entrada.acao,
    alvo: entrada.alvo ?? null,
    payload: payloadSeguro,
    resultado: entrada.resultado ?? "sucesso",
    // A observação é texto livre digitado pelo operador: higienizada antes de
    // gravar, porque o mascaramento por nome de chave não a alcança.
    observacao: entrada.observacao ? higienizarTextoLivre(entrada.observacao) : null,
    user_name: (user?.user_metadata?.["full_name"] as string | undefined) ?? user?.email ?? null,
    created_at: agora,
  };

  espelho.unshift(local);

  if (!user) return { gravado: false, erro: "Sessão não encontrada." };

  const { error } = await supabase.from("atendimento_auditoria").insert({
    user_id: user.id,
    user_name: local.user_name,
    modulo: local.modulo,
    acao: local.acao,
    alvo: local.alvo,
    payload: local.payload as never,
    resultado: local.resultado,
    observacao: local.observacao,
  });

  if (error) return { gravado: false, erro: error.message };
  return { gravado: true };
}

/** Últimos registros do banco, do mais recente para o mais antigo. */
export async function listarAuditoria(limite = 50): Promise<RegistroAuditoria[]> {
  const { data, error } = await supabase
    .from("atendimento_auditoria")
    .select("id, modulo, acao, alvo, payload, resultado, observacao, user_name, created_at")
    .order("created_at", { ascending: false })
    .limit(limite);

  if (error || !data) return auditoriaEmMemoria();
  return data as RegistroAuditoria[];
}
