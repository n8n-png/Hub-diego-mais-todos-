import type { TokenUsage } from "./kb.server";
import { higienizarTextoLivre } from "@/data/atendimento";

export type AiUsageKind = "ask" | "index" | "notion" | "copilot";

/**
 * Registra o consumo real de tokens devolvido pelo gateway.
 * Gravação server-side com service role. Nunca deve quebrar a resposta ao
 * usuário: qualquer falha de log é ignorada.
 */
export async function registrarUso(params: {
  kind: AiUsageKind;
  model: string;
  usage: TokenUsage;
  userId?: string | null;
  ref?: string | null;
}) {
  try {
    if (params.usage.total_tokens <= 0) return;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("ai_usage").insert({
      kind: params.kind,
      model: params.model,
      input_tokens: params.usage.input_tokens,
      output_tokens: params.usage.output_tokens,
      total_tokens: params.usage.total_tokens,
      user_id: params.userId ?? null,
      // O campo ref é texto livre: higienizamos CPF, e-mail e telefone antes de gravar.
      ref: params.ref ? higienizarTextoLivre(params.ref).slice(0, 200) : null,
    });
  } catch {
    /* log de uso é best effort */
  }
}
