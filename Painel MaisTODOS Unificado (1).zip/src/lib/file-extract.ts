/** Extração de texto de arquivos no navegador (PDF, Word, Excel, PowerPoint, TXT/MD/CSV). */

export const ACCEPTED_EXT = [
  ".pdf",
  ".doc",
  ".docx",
  ".xls",
  ".xlsx",
  ".ppt",
  ".pptx",
  ".txt",
  ".md",
  ".csv",
] as const;

export function extOf(name: string) {
  const i = name.lastIndexOf(".");
  return i === -1 ? "" : name.slice(i).toLowerCase();
}

async function fromPdf(file: File): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const workerUrl = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const parts: string[] = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const content = await page.getTextContent();
    const text = content.items
      .map((it) => ("str" in it ? it.str : ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (text) parts.push(`[Página ${p}]\n${text}`);
  }
  return parts.join("\n\n");
}

async function fromDocx(file: File): Promise<string> {
  const mammoth = await import("mammoth/mammoth.browser");
  const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return result.value;
}

async function fromSheet(file: File): Promise<string> {
  const XLSX = await import("xlsx");
  const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
  return wb.SheetNames.map((name) => {
    const csv = XLSX.utils.sheet_to_csv(wb.Sheets[name]!);
    return `[Planilha: ${name}]\n${csv}`;
  }).join("\n\n");
}

async function fromPptx(file: File): Promise<string> {
  const JSZip = (await import("jszip")).default;
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const slides = Object.keys(zip.files)
    .filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
    .sort((a, b) => Number(a.match(/\d+/)![0]) - Number(b.match(/\d+/)![0]));
  const out: string[] = [];
  for (const name of slides) {
    const xml = await zip.files[name]!.async("string");
    const texts = [...xml.matchAll(/<a:t>([^<]*)<\/a:t>/g)].map((m) => m[1]);
    const text = texts.join(" ").replace(/\s+/g, " ").trim();
    if (text) out.push(`[Slide ${name.match(/\d+/)![0]}]\n${text}`);
  }
  return out.join("\n\n");
}

export async function extractText(file: File): Promise<string> {
  const ext = extOf(file.name);
  switch (ext) {
    case ".pdf":
      return fromPdf(file);
    case ".docx":
      return fromDocx(file);
    case ".xlsx":
    case ".xls":
      return fromSheet(file);
    case ".pptx":
      return fromPptx(file);
    case ".txt":
    case ".md":
    case ".csv":
      return file.text();
    case ".doc":
    case ".ppt":
      throw new Error(
        "Formatos antigos .doc e .ppt não são suportados. Salve como .docx ou .pptx e envie novamente.",
      );
    default:
      throw new Error(`Formato ${ext || "desconhecido"} não suportado.`);
  }
}
