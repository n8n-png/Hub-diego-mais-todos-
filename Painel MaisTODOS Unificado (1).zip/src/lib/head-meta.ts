/**
 * Metadados de página em um lugar só.
 * Cada rota repetia cerca de 35 linhas de head(): agora informa título e
 * descrição e recebe o conjunto completo, sempre no mesmo formato.
 */
export function metaPagina({
  titulo,
  descricao,
  descricaoCurta,
}: {
  titulo: string;
  descricao: string;
  /** Versão enxuta usada nos cartões de compartilhamento. */
  descricaoCurta?: string;
}) {
  const curta = descricaoCurta ?? descricao;
  return {
    meta: [
      { title: titulo },
      { name: "description", content: descricao },
      { property: "og:title", content: titulo },
      { property: "og:description", content: curta },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: titulo },
      { name: "twitter:description", content: curta },
    ],
  };
}
