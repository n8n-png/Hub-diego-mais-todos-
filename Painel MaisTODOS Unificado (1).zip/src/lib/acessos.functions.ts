import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { AREAS_ACESSO, rotulosAreaAcesso, type AreaAcesso } from "@/data/areas-acesso";
import { emailProtegido } from "@/data/atendimento";

/**
 * Gestão de acessos: papel admin em user_roles e acesso por módulo em user_area_access.
 * Toda escrita acontece aqui, no servidor, com service role e checagem de admin.
 * O browser nunca escreve direto nessas tabelas.
 */

export const PAPEIS = [
  "admin",
  "gestor",
  "colaborador",
  "atendimento_n1",
  "atendimento_n2",
] as const;

export type Papel = (typeof PAPEIS)[number];

export type UsuarioAcesso = {
  id: string;
  full_name: string | null;
  email: string | null;
  admin: boolean;
  /** Todos os papéis da pessoa, para a tela mostrar a origem do acesso. */
  papeis: Papel[];
  areas: AreaAcesso[];
};

/**
 * GOVERNANÇA: toda concessão e toda remoção de papel ou de área é gravada na
 * trilha de auditoria aqui, no servidor, junto da execução. O navegador não
 * participa desse registro, então a trilha existe mesmo que a tela feche antes
 * de terminar. Módulo "acessos" para ficar filtrável na tela de Auditoria.
 *
 * RETENÇÃO: atendimento_auditoria nunca é expurgada. A trilha é imutável por
 * decisão de produto e o prazo de guarda está pendente de definição jurídica.
 */
type EntradaAcessoAuditoria = {
  autorId: string;
  autorNome: string | null;
  alvoId: string;
  alvoEmail: string | null;
  alvoNome: string | null;
  tipo: "papel" | "area";
  valor: string;
  rotulo: string;
  mudanca: "conceder" | "remover";
};

async function registrarAuditoriaAcesso(entrada: EntradaAcessoAuditoria): Promise<void> {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const concedeu = entrada.mudanca === "conceder";
    await supabaseAdmin.from("atendimento_auditoria").insert({
      user_id: entrada.autorId,
      user_name: entrada.autorNome,
      modulo: "acessos",
      acao: `${concedeu ? "Conceder" : "Remover"} ${entrada.tipo === "papel" ? "papel" : "liberação de área"}: ${entrada.rotulo}`,
      // LGPD: o alvo é identificado de forma mascarada, no padrão do produto.
      alvo: emailProtegido(entrada.alvoEmail),
      payload: {
        tipo: entrada.tipo,
        valor: entrada.valor,
        rotulo: entrada.rotulo,
        mudanca: entrada.mudanca,
        alvo_usuario_id: entrada.alvoId,
        alvo_email: emailProtegido(entrada.alvoEmail),
        alvo_nome: entrada.alvoNome ?? "sem nome",
        concedido_por_usuario_id: entrada.autorId,
        concedido_por: entrada.autorNome ?? "sem nome",
        quando: new Date().toISOString(),
      } as never,
      resultado: "sucesso",
      observacao: null,
    });
  } catch {
    // Falha de auditoria não desfaz a operação já concluída, e não deve
    // derrubar a resposta para quem administra.
  }
}

/** Quem está concedendo e para quem, com o alvo já pronto para mascarar. */
async function contexto(autorId: string, alvoId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("profiles")
    .select("id, full_name, email")
    .in("id", [autorId, alvoId]);
  const autor = (data ?? []).find((p) => p.id === autorId);
  const alvo = (data ?? []).find((p) => p.id === alvoId);
  return {
    autorNome: autor?.full_name ?? autor?.email ?? null,
    alvoNome: alvo?.full_name ?? null,
    alvoEmail: alvo?.email ?? null,
  };
}

function validarPapel(valor: string): Papel {
  const papel = PAPEIS.find((p) => p === valor);
  if (!papel) throw new Error("Papel inválido.");
  return papel;
}

function validarArea(valor: string): AreaAcesso {
  const area = AREAS_ACESSO.find((a) => a === valor);
  if (!area) throw new Error("Módulo inválido.");
  return area;
}

export const listarUsuariosAcesso = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<UsuarioAcesso[]> => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Apenas administradores podem ver a gestão de acessos.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: perfis, error: erroPerfis } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email")
      .order("full_name", { ascending: true });
    if (erroPerfis) throw new Error("Não foi possível carregar a lista de pessoas.");

    const { data: papeis, error: erroPapeis } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role");
    if (erroPapeis) throw new Error("Não foi possível carregar os papéis atuais.");

    const { data: liberacoes, error: erroAreas } = await supabaseAdmin
      .from("user_area_access")
      .select("user_id, area_slug");
    if (erroAreas) throw new Error("Não foi possível carregar os módulos liberados.");

    const papeisPorUsuario = new Map<string, Papel[]>();
    for (const linha of papeis ?? []) {
      const lista = papeisPorUsuario.get(linha.user_id as string) ?? [];
      lista.push(linha.role as Papel);
      papeisPorUsuario.set(linha.user_id as string, lista);
    }

    const admins = new Set(
      (papeis ?? []).filter((l) => l.role === "admin").map((l) => l.user_id as string),
    );

    const porUsuario = new Map<string, AreaAcesso[]>();
    for (const linha of liberacoes ?? []) {
      const lista = porUsuario.get(linha.user_id) ?? [];
      lista.push(linha.area_slug as AreaAcesso);
      porUsuario.set(linha.user_id, lista);
    }

    return (perfis ?? []).map((p) => ({
      id: p.id,
      full_name: p.full_name,
      email: p.email,
      admin: admins.has(p.id),
      papeis: papeisPorUsuario.get(p.id) ?? [],
      areas: porUsuario.get(p.id) ?? [],
    }));
  });

export const concederArea = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; areaSlug: string }) => ({
    userId: String(input.userId),
    areaSlug: validarArea(input.areaSlug),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Apenas administradores podem liberar módulos.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_area_access")
      .insert({ user_id: data.userId, area_slug: data.areaSlug });
    // Liberar um módulo que já está liberado não é erro: apenas confirma o estado atual.
    if (error && error.code !== "23505") throw new Error("Não foi possível liberar o módulo.");

    const ctx = await contexto(userId, data.userId);
    await registrarAuditoriaAcesso({
      autorId: userId,
      autorNome: ctx.autorNome,
      alvoId: data.userId,
      alvoEmail: ctx.alvoEmail,
      alvoNome: ctx.alvoNome,
      tipo: "area",
      valor: data.areaSlug,
      rotulo: rotulosAreaAcesso[data.areaSlug],
      mudanca: "conceder",
    });
    return { ok: true as const };
  });

export const removerArea = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; areaSlug: string }) => ({
    userId: String(input.userId),
    areaSlug: validarArea(input.areaSlug),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Apenas administradores podem remover módulos.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_area_access")
      .delete()
      .eq("user_id", data.userId)
      .eq("area_slug", data.areaSlug);
    if (error) throw new Error("Não foi possível remover o módulo.");

    const ctx = await contexto(userId, data.userId);
    await registrarAuditoriaAcesso({
      autorId: userId,
      autorNome: ctx.autorNome,
      alvoId: data.userId,
      alvoEmail: ctx.alvoEmail,
      alvoNome: ctx.alvoNome,
      tipo: "area",
      valor: data.areaSlug,
      rotulo: rotulosAreaAcesso[data.areaSlug],
      mudanca: "remover",
    });
    return { ok: true as const };
  });

export const concederPapel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; papel: string }) => ({
    userId: String(input.userId),
    papel: validarPapel(input.papel),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Apenas administradores podem conceder papéis.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existente } = await supabaseAdmin
      .from("user_roles")
      .select("id")
      .eq("user_id", data.userId)
      .eq("role", data.papel)
      .maybeSingle();
    // Conceder um papel que já existe não é erro: apenas confirma o estado atual.
    if (existente) return { ok: true as const };

    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.userId, role: data.papel });
    if (error && error.code !== "23505") throw new Error("Não foi possível conceder o papel.");

    const ctx = await contexto(userId, data.userId);
    await registrarAuditoriaAcesso({
      autorId: userId,
      autorNome: ctx.autorNome,
      alvoId: data.userId,
      alvoEmail: ctx.alvoEmail,
      alvoNome: ctx.alvoNome,
      tipo: "papel",
      valor: data.papel,
      rotulo: data.papel,
      mudanca: "conceder",
    });
    return { ok: true as const };
  });

export const removerPapel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; papel: string }) => ({
    userId: String(input.userId),
    papel: validarPapel(input.papel),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Apenas administradores podem remover papéis.");

    if (data.papel === "admin") {
      if (data.userId === userId) {
        throw new Error(
          "Por segurança, você não pode remover o seu próprio acesso de administrador.",
        );
      }
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { count } = await supabaseAdmin
        .from("user_roles")
        .select("id", { count: "exact", head: true })
        .eq("role", "admin");
      if ((count ?? 0) <= 1) {
        throw new Error("A plataforma precisa de pelo menos um administrador ativo.");
      }
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.userId)
      .eq("role", data.papel);
    if (error) throw new Error("Não foi possível remover o papel.");

    const ctx = await contexto(userId, data.userId);
    await registrarAuditoriaAcesso({
      autorId: userId,
      autorNome: ctx.autorNome,
      alvoId: data.userId,
      alvoEmail: ctx.alvoEmail,
      alvoNome: ctx.alvoNome,
      tipo: "papel",
      valor: data.papel,
      rotulo: data.papel,
      mudanca: "remover",
    });
    return { ok: true as const };
  });
