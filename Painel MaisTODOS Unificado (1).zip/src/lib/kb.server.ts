const GATEWAY = "https://ai.gateway.lovable.dev/v1";
export const EMBEDDING_MODEL = "openai/text-embedding-3-small";
export const CHAT_MODEL = "google/gemini-3.6-flash";

function apiKey() {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("LOVABLE_API_KEY não configurada");
  return key;
}

export class GatewayError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function friendly(status: number, body: string) {
  if (status === 429) return "Muitas solicitações à IA agora. Tente novamente em instantes.";
  if (status === 402)
    return "Os créditos de IA da workspace acabaram. Adicione créditos para continuar.";
  return `Falha na IA (${status}): ${body.slice(0, 300)}`;
}

/** Divide um texto longo em pedaços com sobreposição. */
export function chunkText(text: string, size = 1200, overlap = 150): string[] {
  const clean = text
    .replace(/\r/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!clean) return [];
  const paragraphs = clean.split(/\n\n+/);
  const chunks: string[] = [];
  let current = "";
  for (const p of paragraphs) {
    if (p.length > size) {
      if (current.trim()) chunks.push(current.trim());
      current = "";
      for (let i = 0; i < p.length; i += size - overlap) {
        chunks.push(p.slice(i, i + size).trim());
      }
      continue;
    }
    if ((current + "\n\n" + p).length > size) {
      chunks.push(current.trim());
      current = current.slice(Math.max(0, current.length - overlap)) + "\n\n" + p;
    } else {
      current = current ? current + "\n\n" + p : p;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks.filter((c) => c.length > 0);
}

/** Consumo de tokens devolvido pelo gateway, agregado. */
export type TokenUsage = {
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
};

export function usoVazio(): TokenUsage {
  return { input_tokens: 0, output_tokens: 0, total_tokens: 0 };
}

export function somarUso(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    input_tokens: a.input_tokens + b.input_tokens,
    output_tokens: a.output_tokens + b.output_tokens,
    total_tokens: a.total_tokens + b.total_tokens,
  };
}

type GatewayUsage = {
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
};

function lerUso(usage: GatewayUsage | undefined): TokenUsage {
  const entrada = usage?.prompt_tokens ?? 0;
  const saida = usage?.completion_tokens ?? 0;
  return {
    input_tokens: entrada,
    output_tokens: saida,
    total_tokens: usage?.total_tokens ?? entrada + saida,
  };
}

export async function embedTexts(
  inputs: string[],
): Promise<{ embeddings: number[][]; usage: TokenUsage }> {
  const out: number[][] = [];
  let usage = usoVazio();
  for (let i = 0; i < inputs.length; i += 64) {
    const batch = inputs.slice(i, i + 64);
    const res = await fetch(`${GATEWAY}/embeddings`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey() },
      body: JSON.stringify({ model: EMBEDDING_MODEL, input: batch }),
    });
    if (!res.ok) throw new GatewayError(res.status, friendly(res.status, await res.text()));
    const json = (await res.json()) as {
      data: { index: number; embedding: number[] }[];
      usage?: GatewayUsage;
    };
    const sorted = [...json.data].sort((a, b) => a.index - b.index);
    out.push(...sorted.map((d) => d.embedding));
    usage = somarUso(usage, lerUso(json.usage));
  }
  return { embeddings: out, usage };
}

export async function chatCompletion(
  messages: { role: string; content: string }[],
  opts: { json?: boolean } = {},
): Promise<{ text: string; usage: TokenUsage }> {
  const res = await fetch(`${GATEWAY}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey() },
    body: JSON.stringify({
      model: CHAT_MODEL,
      messages,
      ...(opts.json ? { response_format: { type: "json_object" } } : {}),
    }),
  });
  if (!res.ok) throw new GatewayError(res.status, friendly(res.status, await res.text()));
  const json = (await res.json()) as {
    choices: { message: { content: string } }[];
    usage?: GatewayUsage;
  };
  return { text: json.choices[0]?.message?.content ?? "", usage: lerUso(json.usage) };
}
