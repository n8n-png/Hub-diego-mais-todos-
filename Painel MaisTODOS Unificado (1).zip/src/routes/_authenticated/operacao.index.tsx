import { createFileRoute, Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Lock } from "lucide-react";
import { areas } from "@/data/operacao";

export const Route = createFileRoute("/_authenticated/operacao/")({
  component: OperacaoIndex,
  head: () => ({
    meta: [
      { title: "Operação · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Central operacional por área de atendimento: Crédito PF, Conta Digital, Pagamentos, App e Cashback.",
      },
      { property: "og:title", content: "Operação · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Encontre processos, ferramentas e financeiras pela sua área de atendimento.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function OperacaoIndex() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Operação</h1>
          <p className="mt-1 max-w-2xl text-muted-foreground">
            Escolha a sua área de atendimento. Dentro dela você encontra ferramentas, financeiras
            parceiras, fluxos, time comercial, materiais e comunicados · organizados do jeito que
            você trabalha.
          </p>
        </header>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {areas.map((a) =>
            a.disponivel ? (
              <Link key={a.slug} to="/operacao/$area" params={{ area: a.slug }} className="group">
                <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <span className="text-3xl">{a.emoji}</span>
                      <Badge className="bg-lime text-lime-foreground">Disponível</Badge>
                    </div>
                    <h2 className="mt-4 text-lg font-semibold">{a.nome}</h2>
                    <p className="mt-1 text-sm text-muted-foreground">{a.descricao}</p>
                    <div className="mt-4 flex items-center gap-1 text-sm font-medium text-primary">
                      Acessar área{" "}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ) : (
              <Card key={a.slug} className="h-full border-dashed opacity-70">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <span className="text-3xl grayscale">{a.emoji}</span>
                    <Badge variant="secondary">Em breve</Badge>
                  </div>
                  <h2 className="mt-4 text-lg font-semibold">{a.nome}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{a.descricao}</p>
                  <div className="mt-4 flex items-center gap-1 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" /> Estrutura já preparada
                  </div>
                </CardContent>
              </Card>
            ),
          )}
        </div>
      </div>
    </AppLayout>
  );
}
