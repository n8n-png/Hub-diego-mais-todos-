import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, GraduationCap, TrendingUp, Clock, MessageSquare, Trophy } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { GuardaOperacional } from "@/components/GuardaOperacional";

export const Route = createFileRoute("/_authenticated/gestor")({
  component: Gestor,
  head: () => ({ meta: [{ title: "Painel do Gestor · MaisTODOS" }] }),
});

const kpis = [
  { label: "Colaboradores", value: "148", icon: Users, delta: "+6" },
  { label: "Treinamentos concluídos", value: "412", icon: GraduationCap, delta: "+28" },
  { label: "Cursos em andamento", value: "76", icon: TrendingUp, delta: "+12" },
  { label: "Tempo médio de estudo", value: "3h 24min", icon: Clock, delta: "+18min" },
];

const perguntas = [
  { p: "Como cancelar conta com débito?", n: 87 },
  { p: "Emissão de 2ª via de boleto", n: 64 },
  { p: "Como funciona o PIX?", n: 51 },
  { p: "Reset de senha", n: 43 },
];

const ranking = [
  { nome: "Ana Ribeiro", pts: 2840 },
  { nome: "Bruno Costa", pts: 2610 },
  { nome: "Carla Mendes", pts: 2400 },
  { nome: "Diego Lima", pts: 2210 },
];

function Gestor() {
  return (
    <AppLayout>
      {/* Painel do Gestor é operação de gestão: gestor e admin. */}
      <GuardaOperacional modulo="gestor">
        <div className="space-y-6">
          <header>
            <h1 className="text-3xl font-bold tracking-tight">Painel do Gestor</h1>
            <p className="mt-1 text-muted-foreground">
              Visão consolidada de treinamento e conhecimento.
            </p>
          </header>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {kpis.map((k) => {
              const Icon = k.icon;
              return (
                <Card key={k.label} className="shadow-soft">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between">
                      <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" />
                      </div>
                      <Badge className="bg-lime/30 text-lime-foreground border-0">{k.delta}</Badge>
                    </div>
                    <div className="mt-3 text-2xl font-bold">{k.value}</div>
                    <div className="text-xs text-muted-foreground">{k.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageSquare className="h-5 w-5 text-primary" /> Perguntas mais feitas à MaisIA
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {perguntas.map((q) => (
                  <div key={q.p} className="flex items-center gap-3 rounded-lg bg-muted/60 p-3">
                    <div className="flex-1 text-sm font-medium">{q.p}</div>
                    <Badge variant="secondary">{q.n}x</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Trophy className="h-5 w-5 text-primary" /> Ranking de colaboradores
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {ranking.map((r, i) => (
                  <div
                    key={r.nome}
                    className="flex items-center gap-3 rounded-lg p-3 hover:bg-muted/60"
                  >
                    <div
                      className={`grid h-8 w-8 place-items-center rounded-full text-sm font-bold ${i === 0 ? "bg-lime text-lime-foreground" : "bg-primary/10 text-primary"}`}
                    >
                      {i + 1}
                    </div>
                    <div className="flex-1 font-medium">{r.nome}</div>
                    <div className="text-sm font-bold text-primary">{r.pts} pts</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </GuardaOperacional>
    </AppLayout>
  );
}
