import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/fluxogramas")({
  component: Fluxogramas,
  head: () => ({ meta: [{ title: "Fluxogramas · MaisTODOS" }] }),
});

type Node = { label: string; tone?: "start" | "decision" | "end" | "action" };

const fluxo: Node[][] = [
  [{ label: "Cliente deseja cancelar", tone: "start" }],
  [{ label: "Validar identidade", tone: "action" }],
  [{ label: "Existe débito?", tone: "decision" }],
  [
    { label: "SIM → Financeiro", tone: "action" },
    { label: "NÃO → Cancelar", tone: "action" },
  ],
  [{ label: "Cancelar conta", tone: "action" }],
  [{ label: "Encerrar atendimento", tone: "end" }],
];

const toneClass = (t?: Node["tone"]) => {
  switch (t) {
    case "start":
      return "bg-lime text-lime-foreground";
    case "decision":
      return "bg-primary text-primary-foreground";
    case "end":
      return "bg-gradient-primary text-primary-foreground";
    default:
      return "bg-card border border-border";
  }
};

function Fluxogramas() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Fluxogramas</h1>
          <p className="mt-1 text-muted-foreground">
            Visualize os fluxos de decisão dos principais processos.
          </p>
        </header>

        <Card className="shadow-soft">
          <CardContent className="p-8">
            <h2 className="mb-6 text-lg font-semibold">Cancelamento de conta</h2>
            <div className="mx-auto flex max-w-2xl flex-col items-center gap-3">
              {fluxo.map((row, i) => (
                <div key={i} className="flex w-full flex-col items-center gap-3">
                  <div className="flex w-full justify-center gap-4">
                    {row.map((n, j) => (
                      <div
                        key={j}
                        className={`min-w-[180px] rounded-xl px-5 py-3 text-center text-sm font-semibold shadow-soft ${toneClass(n.tone)}`}
                      >
                        {n.label}
                      </div>
                    ))}
                  </div>
                  {i < fluxo.length - 1 && (
                    <div className="h-6 w-0.5 bg-gradient-to-b from-primary to-lime" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
