import { createFileRoute, stripSearchParams } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, FileText, Clock, ArrowRight } from "lucide-react";
import { useState } from "react";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";

const buscaSchema = z.object({
  q: fallback(z.string(), "").default(""),
});

export const Route = createFileRoute("/_authenticated/base")({
  component: Base,
  validateSearch: zodValidator(buscaSchema),
  search: { middlewares: [stripSearchParams({ q: "" })] },
  head: () => ({ meta: [{ title: "Base de Conhecimento · MaisTODOS" }] }),
});

const artigos = [
  {
    titulo: "Como cancelar uma conta com débito em aberto",
    cat: "Cancelamento",
    tags: ["cancelamento", "financeiro"],
    upd: "há 2 dias",
  },
  {
    titulo: "PIX · Contestações e chargebacks",
    cat: "PIX",
    tags: ["pix", "contestação"],
    upd: "há 5 dias",
  },
  {
    titulo: "Emissão de 2ª via de boleto",
    cat: "Financeiro",
    tags: ["boleto", "2ª via"],
    upd: "há 1 semana",
  },
  {
    titulo: "Reset de senha do portal",
    cat: "Acesso",
    tags: ["senha", "acesso"],
    upd: "há 3 dias",
  },
  {
    titulo: "Cadastro de novo cliente PJ",
    cat: "Cadastro",
    tags: ["cadastro", "pj"],
    upd: "há 4 dias",
  },
  {
    titulo: "Bloqueio e desbloqueio de cartão",
    cat: "Cartão",
    tags: ["cartão", "bloqueio"],
    upd: "há 1 dia",
  },
];

const populares = ["cancelamento", "pix", "cartão", "senha", "cadastro", "boleto"];

function Base() {
  const { q: qInicial } = Route.useSearch();
  const [q, setQ] = useState(qInicial);
  const filtered = artigos.filter(
    (a) =>
      q === "" ||
      a.titulo.toLowerCase().includes(q.toLowerCase()) ||
      a.tags.some((t) => t.includes(q.toLowerCase())),
  );

  return (
    <AppLayout>
      <div className="space-y-8">
        <section className="rounded-3xl bg-gradient-hero p-10 text-center text-primary-foreground shadow-glow">
          <h1 className="text-3xl md:text-4xl font-bold">Como posso ajudar você hoje?</h1>
          <p className="mt-2 text-primary-foreground/80">
            Busque procedimentos, artigos e passo-a-passo da MaisTODOS.
          </p>
          <div className="relative mx-auto mt-6 max-w-2xl">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Digite sua dúvida…"
              className="h-14 rounded-full border-0 pl-12 text-base text-foreground shadow-lg"
            />
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {populares.map((p) => (
              <button
                key={p}
                onClick={() => setQ(p)}
                className="rounded-full bg-white/15 px-3 py-1 text-xs backdrop-blur hover:bg-white/25"
              >
                {p}
              </button>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-lg font-semibold">
            {q ? `Resultados para "${q}"` : "Artigos em destaque"}
          </h2>
          <div className="grid gap-4 md:grid-cols-2">
            {filtered.map((a) => (
              <Card
                key={a.titulo}
                className="group shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-glow cursor-pointer"
              >
                <CardContent className="flex gap-4 p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <Badge variant="secondary" className="mb-2">
                      {a.cat}
                    </Badge>
                    <h3 className="font-semibold leading-snug">{a.titulo}</h3>
                    <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" /> Atualizado {a.upd}
                    </div>
                  </div>
                  <ArrowRight className="mt-2 h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </AppLayout>
  );
}
