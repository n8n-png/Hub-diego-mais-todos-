import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ChevronDown,
  FileText,
  Folder,
  Image as ImageIcon,
  Maximize2,
  Minimize2,
  Search,
} from "lucide-react";
import { EstadoVazio } from "@/components/EstadoVazio";
import { OperacaoShell } from "@/components/OperacaoShell";
import { ProcessoMarkdown } from "@/components/ProcessoMarkdown";

import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getArea } from "@/data/operacao";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/operacao/$area/processos")({
  component: Processos,
  head: () => ({
    meta: [
      { title: "Processos e Playbooks · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Processos, playbooks e orientações da operação de Pagamentos, organizados em cards por pasta.",
      },
      { property: "og:title", content: "Processos e Playbooks · Hub MaisTODOS" },
      {
        property: "og:description",
        content:
          "Conteúdo operacional de Pagamentos importado do Notion, com busca e leitura no painel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

type Doc = {
  id: string;
  title: string;
  content: string;
  tags: string[] | null;
  notion_url: string | null;
  updated_at: string | null;
};

function pastaDe(doc: Doc, areaSlug: string): string | null {
  const extras = (doc.tags ?? []).filter((t) => t !== areaSlug && t !== "notion");
  return extras[0] ?? null;
}

function resumo(texto: string) {
  const limpo = texto
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/^#+\s*/gm, "")
    .replace(/[*_`>|]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return limpo.length > 160 ? `${limpo.slice(0, 160)}...` : limpo;
}

function contarImagens(texto: string) {
  return (texto.match(/\(kbimg:/g) ?? []).length;
}

function Processos() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  const [busca, setBusca] = useState("");
  const [aberta, setAberta] = useState<string | null>(null);
  const [doc, setDoc] = useState<Doc | null>(null);
  const [tamanho, setTamanho] = useState<{ w: number; h: number } | null>(null);
  const [amplo, setAmplo] = useState(false);

  useEffect(() => {
    try {
      const salvo = localStorage.getItem("hub:tamanho-topico");
      if (salvo) {
        const v = JSON.parse(salvo) as { w: number; h: number };
        if (v?.w && v?.h) setTamanho(v);
      }
    } catch {
      setTamanho(null);
    }
  }, []);

  function guardarTamanho(el: HTMLElement | null) {
    if (!el) return;
    const v = { w: el.offsetWidth, h: el.offsetHeight };
    setTamanho(v);
    try {
      localStorage.setItem("hub:tamanho-topico", JSON.stringify(v));
    } catch {
      // silencioso
    }
  }

  const docs = useQuery({
    queryKey: ["operacao-processos", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_documents")
        .select("id, title, content, tags, notion_url, updated_at")
        .contains("tags", [slug])
        .order("title");
      if (error) throw error;
      return data as Doc[];
    },
    enabled: Boolean(area?.disponivel),
  });

  const { pastas, soltos } = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    const lista = (docs.data ?? []).filter(
      (d) =>
        !termo ||
        d.title.toLowerCase().includes(termo) ||
        (d.content ?? "").toLowerCase().includes(termo),
    );
    const mapa = new Map<string, Doc[]>();
    const raiz: Doc[] = [];
    for (const d of lista) {
      const pasta = pastaDe(d, slug);
      if (!pasta) {
        raiz.push(d);
        continue;
      }
      const atual = mapa.get(pasta) ?? [];
      atual.push(d);
      mapa.set(pasta, atual);
    }
    // Uma pasta que também existe como documento entra apenas como pasta.
    const nomes = new Set(mapa.keys());
    return {
      pastas: [...mapa.entries()].sort((a, b) => a[0].localeCompare(b[0], "pt-BR")),
      soltos: raiz.filter((d) => !nomes.has(d.title)),
    };
  }, [docs.data, busca, slug]);

  const capa = useMemo(
    () => new Map((docs.data ?? []).map((d) => [d.title, d] as const)),
    [docs.data],
  );

  // Subpáginas do documento aberto: no Notion elas aparecem só como nome,
  // então aqui listamos os filhos com o conteúdo completo disponível.
  const subpaginas = useMemo(() => {
    if (!doc) return [] as Doc[];
    return (docs.data ?? [])
      .filter((d) => d.id !== doc.id && (d.tags ?? []).includes(doc.title))
      .sort((a, b) => a.title.localeCompare(b.title, "pt-BR"));
  }, [doc, docs.data]);

  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Processos e Playbooks" },
      ]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Processos e Playbooks</h1>
          <p className="mt-1 text-muted-foreground">
            Conteúdo operacional de {area.nome}, organizado em cards com as subpastas agregadas.
            Abra um card para ler o procedimento completo aqui no painel.
          </p>
        </header>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar processo, erro, portal ou playbook"
            className="pl-9"
            aria-label="Buscar processo"
          />
        </div>

        {docs.isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-2xl" />
            ))}
          </div>
        ) : docs.isError ? (
          <Card className="shadow-soft">
            <CardContent className="p-6 text-sm text-muted-foreground">
              Não foi possível carregar os processos agora. Tente novamente em instantes.
            </CardContent>
          </Card>
        ) : pastas.length === 0 && soltos.length === 0 ? (
          <EstadoVazio
            titulo={busca.trim() ? "Nenhum processo encontrado" : "Conteúdo em breve"}
            descricao={
              busca.trim()
                ? "Ajuste os termos e tente de novo."
                : `Ainda não há conteúdo didático publicado para ${area.nome}. Assim que o material for enviado, ele aparece aqui em cards, com as subpastas agregadas.`
            }
          />
        ) : (
          <div className="space-y-6">
            {pastas.length > 0 && (
              <section className="space-y-3">
                <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Pastas
                </h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  {pastas.map(([nome, filhos]) => {
                    const expandida = aberta === nome;
                    const principal = capa.get(nome) ?? null;
                    return (
                      <Card key={nome} className="shadow-soft">
                        <CardContent className="p-5">
                          <button
                            type="button"
                            onClick={() => setAberta(expandida ? null : nome)}
                            className="flex w-full items-start gap-3 text-left"
                            aria-expanded={expandida}
                          >
                            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent">
                              <Folder className="h-5 w-5 text-primary" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block font-semibold">{nome}</span>
                              <span className="mt-1 block text-sm text-muted-foreground">
                                {filhos.length} {filhos.length === 1 ? "processo" : "processos"}
                              </span>
                            </span>
                            <ChevronDown
                              className={`mt-2 h-4 w-4 shrink-0 text-muted-foreground transition-transform ${
                                expandida ? "rotate-180" : ""
                              }`}
                            />
                          </button>

                          {expandida && (
                            <ul className="mt-4 space-y-1 border-l border-border pl-3">
                              {principal && (
                                <li>
                                  <button
                                    type="button"
                                    onClick={() => setDoc(principal)}
                                    className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm transition-colors hover:bg-muted"
                                  >
                                    <FileText className="h-4 w-4 shrink-0 text-primary" />
                                    <span className="min-w-0 flex-1 truncate">
                                      Visão geral da pasta
                                    </span>
                                  </button>
                                </li>
                              )}
                              {filhos.map((f) => (
                                <li key={f.id}>
                                  <button
                                    type="button"
                                    onClick={() => setDoc(f)}
                                    className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm transition-colors hover:bg-muted"
                                  >
                                    <FileText className="h-4 w-4 shrink-0 text-primary" />
                                    <span className="min-w-0 flex-1 truncate">{f.title}</span>
                                  </button>
                                </li>
                              ))}
                            </ul>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </section>
            )}

            {soltos.length > 0 && (
              <section className="space-y-3">
                <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Processos
                </h2>
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  {soltos.map((d) => (
                    <Card
                      key={d.id}
                      className="cursor-pointer shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-glow"
                      onClick={() => setDoc(d)}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-center justify-between">
                          <span className="grid h-9 w-9 place-items-center rounded-xl bg-accent">
                            <FileText className="h-4 w-4 text-primary" />
                          </span>
                          <div className="flex items-center gap-2">
                            {contarImagens(d.content ?? "") > 0 && (
                              <Badge variant="outline" className="gap-1">
                                <ImageIcon className="h-3 w-3" />
                                {contarImagens(d.content ?? "")}
                              </Badge>
                            )}
                            <Badge variant="secondary">Processo</Badge>
                          </div>
                        </div>
                        <h3 className="mt-3 font-semibold">{d.title}</h3>
                        <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">
                          {resumo(d.content ?? "")}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>

      <Dialog open={Boolean(doc)} onOpenChange={(o) => !o && setDoc(null)}>
        <DialogContent
          className="flex flex-col gap-0 overflow-hidden p-0 sm:max-w-none"
          style={
            amplo
              ? { width: "95vw", height: "92vh", maxWidth: "95vw" }
              : {
                  width: tamanho?.w ?? 800,
                  height: tamanho?.h ?? 640,
                  minWidth: 340,
                  minHeight: 280,
                  maxWidth: "96vw",
                  maxHeight: "92vh",
                  resize: "both",
                }
          }
          onMouseUp={(e) => !amplo && guardarTamanho(e.currentTarget)}
        >
          <button
            type="button"
            onClick={() => setAmplo((v) => !v)}
            aria-label={amplo ? "Reduzir tópico" : "Ampliar tópico"}
            className="absolute right-12 top-4 rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            {amplo ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
          <DialogHeader className="shrink-0 border-b border-border px-6 py-5 pr-24">
            <DialogTitle>{doc?.title}</DialogTitle>
            <DialogDescription>
              Conteúdo oficial da operação de {area.nome}, com o passo a passo e as imagens da
              página de origem. Arraste o canto inferior direito para ajustar o tamanho.
            </DialogDescription>
          </DialogHeader>
          <div className="min-h-0 flex-1 overflow-auto px-6 py-5">
            {doc && <ProcessoMarkdown content={doc.content ?? ""} />}

            {subpaginas.length > 0 && (
              <section className="mt-6 space-y-3 border-t border-border pt-5">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Subpáginas desta seção
                </h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  {subpaginas.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setDoc(s)}
                      className="rounded-xl border border-border bg-card p-4 text-left transition-colors hover:bg-muted"
                    >
                      <span className="flex items-center gap-2 font-semibold">
                        <FileText className="h-4 w-4 shrink-0 text-primary" />
                        {s.title}
                      </span>
                      <span className="mt-1 block line-clamp-3 text-sm text-muted-foreground">
                        {resumo(s.content ?? "")}
                      </span>
                    </button>
                  ))}
                </div>
              </section>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </OperacaoShell>
  );
}
