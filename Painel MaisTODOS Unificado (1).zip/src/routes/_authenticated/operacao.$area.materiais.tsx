import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getArea } from "@/data/operacao";
import { FileText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/materiais")({
  component: Materiais,
  head: () => ({
    meta: [
      { title: "Materiais de Apoio · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Documentações gerais, políticas, materiais de treinamento e guias internos da operação.",
      },
      { property: "og:title", content: "Materiais de Apoio · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Conteúdos compartilhados entre todas as financeiras da operação.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const filtros = ["Todos", "Documentação geral", "Política", "Treinamento", "Guia interno"] as const;

function Materiais() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  const [filtro, setFiltro] = useState<(typeof filtros)[number]>("Todos");
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  const lista = area.materiais.filter((m) => filtro === "Todos" || m.categoria === filtro);

  return (
    <OperacaoShell
      area={area}
      crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Materiais de Apoio" }]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">📚 Materiais de Apoio</h1>
          <p className="mt-1 text-muted-foreground">
            Conteúdos gerais válidos para todas as financeiras da operação.
          </p>
        </header>

        <div className="flex flex-wrap gap-2">
          {filtros.map((f) => (
            <Button
              key={f}
              size="sm"
              variant={filtro === f ? "default" : "outline"}
              onClick={() => setFiltro(f)}
            >
              {f}
            </Button>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {lista.map((m) => (
            <Card key={m.titulo} className="shadow-soft transition-shadow hover:shadow-glow">
              <CardContent className="flex gap-3 p-5">
                <FileText className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                <div className="min-w-0">
                  <Badge variant="secondary" className="mb-2">
                    {m.categoria}
                  </Badge>
                  <h2 className="font-semibold">{m.titulo}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{m.descricao}</p>
                  <div className="mt-2 text-xs text-muted-foreground">
                    Atualizado em {new Date(m.atualizadoEm).toLocaleDateString("pt-BR")}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </OperacaoShell>
  );
}
