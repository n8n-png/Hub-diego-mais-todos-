import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Undo2 } from "lucide-react";
import { AtendimentoShell } from "@/components/AtendimentoShell";
import { AcaoSensivel } from "@/components/AcaoSensivel";
import { BuscaFiliadoCpf } from "@/components/BuscaFiliadoCpf";
import { CabecalhoFiliado } from "@/components/CabecalhoFiliado";
import { TabelaAtendimento } from "@/components/TabelaAtendimento";
import { BadgeStatus } from "@/components/BadgeStatus";
import { AvisoDadoFicticio } from "@/components/AvisoDadoFicticio";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TableCell, TableRow } from "@/components/ui/table";
import { metaPagina } from "@/lib/head-meta";
import {
  buscarEstornosMock,
  cpfProtegido,
  dataBr,
  moeda,
  situacaoTransacao,
  type Filiado,
  type TransacaoEstorno,
} from "@/data/atendimento";

export const Route = createFileRoute("/_authenticated/atendimento/estornos")({
  component: Estornos,
  head: () =>
    metaPagina({
      titulo: "Estornos · Atendimento MaisTODOS",
      descricao:
        "Solicitação e acompanhamento de estornos do filiado, com pré-visualização do envio, confirmação humana e auditoria.",
      descricaoCurta: "Solicitação e acompanhamento de estornos na área de Atendimento MaisTODOS.",
    }),
});

const MODULO = "Estornos";

function payloadEstorno(t: TransacaoEstorno) {
  if (t.origem === "Wallet") {
    return {
      metodo: "POST",
      url: `/v1/admin/support/transaction/${t.id}/refund`,
    };
  }
  return {
    metodo: "PATCH",
    url: "/v1/admin/support/pedido/estorno",
    body: { pedido: t.pedido ?? t.id, unidade: t.unidade ?? null },
  };
}

function Estornos() {
  const [filiado, setFiliado] = useState<Filiado | null>(null);
  const [transacoes, setTransacoes] = useState<TransacaoEstorno[]>([]);

  function solicitar(id: string) {
    // MOCK: apenas atualiza o estado local. Fase 2 chamará o proxy server-side.
    setTransacoes((atual) =>
      atual.map((t) => (t.id === id ? { ...t, situacao: "Estorno solicitado" } : t)),
    );
  }

  return (
    <AtendimentoShell
      modulo="atendimento_estornos"
      titulo="Estornos"
      descricao="Transações elegíveis a estorno do filiado. Uma transação por vez, com justificativa obrigatória e registro em auditoria."
    >
      <BuscaFiliadoCpf
        titulo="Buscar transações por CPF"
        onEncontrado={(f, cpfDigitos) => {
          setFiliado(f);
          setTransacoes(cpfDigitos ? buscarEstornosMock(cpfDigitos) : []);
        }}
      />

      {filiado && (
        <Card className="shadow-soft">
          <CabecalhoFiliado
            filiado={filiado}
            titulo="Transações elegíveis a estorno"
            icon={Undo2}
            complemento="não existe estorno em massa, uma transação por vez"
            selo={`${transacoes.length} transações`}
          />
          <CardContent className="space-y-4">
            <TabelaAtendimento
              colunas={[
                { rotulo: "ID da transação" },
                { rotulo: "Data" },
                { rotulo: "Descrição" },
                { rotulo: "Valor", alinhamento: "right" },
                { rotulo: "Origem" },
                { rotulo: "Situação" },
                { rotulo: "Ação", alinhamento: "right" },
              ]}
              vazioVisivel={transacoes.length === 0}
              vazio={{
                titulo: "Nenhuma transação elegível",
                descricao: "Este CPF não tem transação elegível a estorno na base de teste.",
              }}
            >
              {transacoes.map((t) => {
                const bloqueado =
                  t.situacao === "Estorno solicitado" || t.situacao === "Estornada";
                return (
                  <TableRow key={t.id}>
                    <TableCell className="whitespace-nowrap font-medium">{t.id}</TableCell>
                    <TableCell className="whitespace-nowrap">{dataBr(t.data)}</TableCell>
                    <TableCell>{t.descricao}</TableCell>
                    <TableCell className="text-right font-medium">{moeda(t.valor)}</TableCell>
                    <TableCell className="whitespace-nowrap">{t.origem}</TableCell>
                    <TableCell>
                      <BadgeStatus estado={situacaoTransacao[t.situacao]} />
                    </TableCell>
                    <TableCell className="text-right">
                      <AcaoSensivel
                        modulo={MODULO}
                        acao={`Abrir estorno da transação ${t.origem}`}
                        alvo={`CPF ${cpfProtegido(filiado.cpf)} · transação ${t.id}`}
                        titulo="Abrir estorno da transação"
                        descricao="Esta ação mexe em dinheiro do filiado. Confira o envio e escreva a justificativa antes de confirmar."
                        rotuloConfirmar="Solicitar estorno"
                        destrutiva
                        observacaoObrigatoria
                        payload={{
                          ...payloadEstorno(t),
                          cpf: cpfProtegido(filiado.cpf),
                          valor: t.valor,
                        }}
                        onConfirmar={() => solicitar(t.id)}
                        disabled={bloqueado}
                      >
                        <Button variant="outline" size="sm" disabled={bloqueado}>
                          Estornar
                        </Button>
                      </AcaoSensivel>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TabelaAtendimento>

            <AvisoDadoFicticio />
          </CardContent>
        </Card>
      )}
    </AtendimentoShell>
  );
}
