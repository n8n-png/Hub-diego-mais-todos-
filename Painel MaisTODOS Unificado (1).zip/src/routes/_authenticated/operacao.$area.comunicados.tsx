import { createFileRoute } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea, type Comunicado } from "@/data/operacao";
import { Megaphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/comunicados")({
  component: Comunicados,
  head: () => ({
    meta: [
      { title: "Comunicados da Operação · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Novidades, alterações de processo, atualizações operacionais e avisos importantes da operação.",
      },
      { property: "og:title", content: "Comunicados da Operação · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Fique por dentro de tudo que muda na operação, em ordem cronológica.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const tipoTone: Record<Comunicado["tipo"], string> = {
  Novidade: "bg-lime text-lime-foreground",
  "Alteração de processo": "bg-primary text-primary-foreground",
  "Atualização operacional": "bg-accent text-accent-foreground",
  "Aviso importante": "bg-destructive text-destructive-foreground",
};

function Comunicados() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Comunicados" }]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">📢 Comunicados</h1>
          <p className="mt-1 text-muted-foreground">
            Tudo que muda na operação, centralizado e em ordem cronológica.
          </p>
        </header>

        <ol className="relative space-y-4 border-l-2 border-primary/20 pl-6">
          {area.comunicados.map((c) => (
            <li key={c.titulo} className="relative">
              <span className="absolute -left-[31px] flex h-6 w-6 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground">
                <Megaphone className="h-3 w-3" />
              </span>
              <Card className={c.destaque ? "border-primary/30 shadow-glow" : "shadow-soft"}>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-muted-foreground">
                      {new Date(c.data).toLocaleDateString("pt-BR", {
                        day: "2-digit",
                        month: "long",
                        year: "numeric",
                      })}
                    </span>
                    <Badge className={tipoTone[c.tipo]}>{c.tipo}</Badge>
                  </div>
                  <h2 className="mt-2 font-semibold">{c.titulo}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{c.resumo}</p>
                </CardContent>
              </Card>
            </li>
          ))}
        </ol>
      </div>
    </OperacaoShell>
  );
}
