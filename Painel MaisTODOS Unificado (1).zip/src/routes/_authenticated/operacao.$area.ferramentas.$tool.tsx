import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getArea } from "@/data/operacao";
import { ExternalLink, Users, KeyRound, GraduationCap, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/ferramentas/$tool")({
  component: FerramentaDetalhe,
  head: () => ({
    meta: [
      { title: "Ferramenta da operação · Hub MaisTODOS" },
      {
        name: "description",
        content: "Descrição, acesso, responsáveis e tutoriais da ferramenta operacional.",
      },
      { property: "og:title", content: "Ferramenta da operação · Hub MaisTODOS" },
      { property: "og:description", content: "Como usar e como solicitar acesso à ferramenta." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function FerramentaDetalhe() {
  const { area: slug, tool } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  const t = area.ferramentas.find((f) => f.slug === tool);

  if (!t) {
    return (
      <OperacaoShell
        area={area}
        crumbs={[
          { label: area.nome, to: `/operacao/${area.slug}` },
          { label: "Central de Ferramentas" },
        ]}
      >
        <Card className="border-dashed">
          <CardContent className="p-10 text-center">
            <p className="text-sm text-muted-foreground">Ferramenta não encontrada.</p>
            <Button asChild className="mt-4" variant="outline">
              <Link to="/operacao/$area/ferramentas" params={{ area: area.slug }}>
                Voltar
              </Link>
            </Button>
          </CardContent>
        </Card>
      </OperacaoShell>
    );
  }

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Central de Ferramentas", to: `/operacao/${area.slug}/ferramentas` },
        { label: t.nome },
      ]}
    >
      <div className="space-y-6">
        <Link
          to="/operacao/$area/ferramentas"
          params={{ area: area.slug }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Todas as ferramentas
        </Link>

        <Card className="overflow-hidden shadow-soft">
          <div className="bg-gradient-primary p-6 text-primary-foreground">
            <Badge className="mb-2 bg-lime text-lime-foreground">{t.categoria}</Badge>
            <h1 className="text-2xl font-bold">{t.nome}</h1>
            <p className="mt-2 max-w-2xl text-sm opacity-90">{t.descricao}</p>
            {t.link && (
              <Button asChild variant="secondary" className="mt-4">
                <a href={t.link} target="_blank" rel="noopener noreferrer">
                  Acessar ferramenta <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            )}
          </div>
        </Card>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="shadow-soft">
            <CardContent className="p-6">
              <h2 className="flex items-center gap-2 font-semibold">
                <Users className="h-4 w-4 text-primary" /> Quem utiliza
              </h2>
              <ul className="mt-3 flex flex-wrap gap-2">
                {t.quemUtiliza.map((p) => (
                  <li key={p}>
                    <Badge variant="secondary">{p}</Badge>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6">
              <h2 className="flex items-center gap-2 font-semibold">
                <KeyRound className="h-4 w-4 text-primary" /> Como solicitar acesso
              </h2>
              <ol className="mt-3 space-y-2 text-sm text-muted-foreground">
                {t.comoSolicitarAcesso.map((p, i) => (
                  <li key={p} className="flex gap-2">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-[11px] font-semibold text-accent-foreground">
                      {i + 1}
                    </span>
                    {p}
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-soft">
          <CardContent className="p-6">
            <h2 className="flex items-center gap-2 font-semibold">
              <GraduationCap className="h-4 w-4 text-primary" /> Tutoriais relacionados
            </h2>
            <ul className="mt-3 divide-y divide-border">
              {t.tutoriais.map((tut) => (
                <li
                  key={tut.titulo}
                  className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm"
                >
                  <span>{tut.titulo}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{tut.tipo}</Badge>
                    {tut.fluxo ? (
                      <Button asChild size="sm" variant="secondary">
                        <Link
                          to="/operacao/$area/fluxos"
                          params={{ area: area.slug }}
                          search={{ fluxo: tut.fluxo }}
                        >
                          Abrir fluxo
                        </Link>
                      </Button>
                    ) : (
                      <span className="text-xs text-muted-foreground">Em breve</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </OperacaoShell>
  );
}
