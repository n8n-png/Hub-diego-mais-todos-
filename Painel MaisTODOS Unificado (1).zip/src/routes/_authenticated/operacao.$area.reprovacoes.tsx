import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, GitBranch, ShieldAlert } from "lucide-react";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea } from "@/data/operacao";
import {
  acoesRapidas,
  cadeiaDecisoes,
  glossarioOnboarding,
  motivosBankly,
} from "@/data/conta-digital";

export const Route = createFileRoute("/_authenticated/operacao/$area/reprovacoes")({
  component: ReprovacoesContaDigital,
  head: () => ({
    meta: [
      { title: "Reprovações e Glossário · Conta Digital · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Motivos de reprovação do Bankly no onboarding da conta digital, separados por correção, bloqueio definitivo e escalonamento, com glossário técnico.",
      },
      {
        property: "og:title",
        content: "Reprovações e Glossário · Conta Digital · Hub MaisTODOS",
      },
      {
        property: "og:description",
        content:
          "Códigos de reprovação, ação de suporte por código, cadeia de decisões por validação e glossário do onboarding.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const tomBorda = {
  corrigivel: "border-l-lime",
  bloqueio: "border-l-destructive",
  escalavel: "border-l-primary",
} as const;

const tomBadge = {
  corrigivel: "bg-lime text-lime-foreground",
  bloqueio: "bg-destructive text-destructive-foreground",
  escalavel: "bg-primary text-primary-foreground",
} as const;

function ReprovacoesContaDigital() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Reprovações e Glossário" },
      ]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Reprovações e Glossário</h1>
          <p className="mt-1 max-w-3xl text-muted-foreground">
            Referência de apoio para a devolutiva ao cliente. Os códigos abaixo valem para as etapas
            5 a 9 do onboarding e indicam se o caso aceita nova tentativa, se é bloqueio definitivo
            ou se depende do Service Desk do Bankly.
          </p>
        </header>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <ShieldAlert className="h-4 w-4 text-primary" /> Ação de suporte nas reprovações comuns
          </h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {acoesRapidas.map((a) => (
              <Card key={a.categoria} className={`border-l-4 shadow-soft ${tomBorda[a.tom]}`}>
                <CardContent className="p-5">
                  <span
                    className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ${tomBadge[a.tom]}`}
                  >
                    {a.categoria}
                  </span>
                  <p className="mt-3 text-sm font-medium">{a.exemplo}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{a.acao}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            Lembrete de biometria: o sistema aceita no máximo 5 tentativas de KYC. Depois disso, a
            liberação exige avaliação manual do time de Prevenção.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-lg font-semibold">Motivos de reprovação Bankly</h2>
          {motivosBankly.map((g) => (
            <Card key={g.slug} className={`border-l-4 shadow-soft ${tomBorda[g.tom]}`}>
              <CardContent className="p-5">
                <h3 className="font-semibold">{g.titulo}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{g.resumo}</p>

                <div className="mt-4 space-y-2">
                  {g.motivos.map((m) => (
                    <div
                      key={m.codigo}
                      className="rounded-xl border border-border bg-card p-4 sm:flex sm:items-start sm:gap-4"
                    >
                      <Badge variant="outline" className="shrink-0 font-mono text-[11px]">
                        {m.codigo}
                      </Badge>
                      <div className="mt-2 min-w-0 sm:mt-0">
                        <p className="text-sm font-medium">{m.descricao}</p>
                        <p className="mt-0.5 text-sm text-muted-foreground">{m.acao}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <GitBranch className="h-4 w-4 text-primary" /> Cadeia de decisões por validação
          </h2>
          <p className="text-sm text-muted-foreground">
            Para cada ponto de decisão: quem valida, que dado usa, onde o retorno fica gravado e
            como o step é avaliado.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            {cadeiaDecisoes.map((c) => (
              <Card key={c.validacao} className="shadow-soft">
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-semibold">{c.validacao}</h3>
                    <Badge variant="secondary">{c.sistema}</Badge>
                  </div>
                  <dl className="mt-3 grid gap-1.5 text-xs text-muted-foreground">
                    <div className="flex flex-wrap gap-1">
                      <dt className="font-medium text-foreground">Dado consultado:</dt>
                      <dd>{c.dado}</dd>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      <dt className="font-medium text-foreground">Onde é gravado:</dt>
                      <dd className="font-mono">{c.grava}</dd>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      <dt className="font-medium text-foreground">Avaliação do step:</dt>
                      <dd>{c.avaliacao}</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <BookOpen className="h-4 w-4 text-primary" /> Glossário
          </h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {glossarioOnboarding.map((g) => (
              <Card key={g.termo} className="shadow-soft">
                <CardContent className="flex gap-3 p-4">
                  <Badge variant="outline" className="h-fit shrink-0">
                    {g.termo}
                  </Badge>
                  <p className="text-sm text-muted-foreground">{g.significado}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </OperacaoShell>
  );
}
