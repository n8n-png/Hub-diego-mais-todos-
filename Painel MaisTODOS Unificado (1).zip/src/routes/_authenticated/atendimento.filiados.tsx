import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Phone, Trash2, UserRound } from "lucide-react";
import { AtendimentoShell } from "@/components/AtendimentoShell";
import { AcaoSensivel } from "@/components/AcaoSensivel";
import { BuscaFiliadoCpf } from "@/components/BuscaFiliadoCpf";
import { BadgeStatus } from "@/components/BadgeStatus";
import { AvisoDadoFicticio } from "@/components/AvisoDadoFicticio";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { metaPagina } from "@/lib/head-meta";
import {
  cpfProtegido,
  emailProtegido,
  somenteDigitos,
  statusFiliado,
  telefoneProtegido,
  type Filiado,
} from "@/data/atendimento";

export const Route = createFileRoute("/_authenticated/atendimento/filiados")({
  component: GerenciamentoFiliados,
  head: () =>
    metaPagina({
      titulo: "Gerenciamento de Filiados · Atendimento MaisTODOS",
      descricao:
        "Consulte o filiado por CPF, veja o card de contexto e atualize ou remova contato com confirmação e registro em auditoria.",
    }),
});

const MODULO = "Gerenciamento de Filiados";

function GerenciamentoFiliados() {
  const [filiado, setFiliado] = useState<Filiado | null>(null);

  return (
    <AtendimentoShell
      modulo="atendimento_filiados"
      titulo="Gerenciamento de Filiados"
      descricao="Busque o filiado por CPF, confira o contexto do atendimento e ajuste os dados de contato com confirmação humana."
    >
      <BuscaFiliadoCpf
        titulo="Buscar filiado por CPF"
        onEncontrado={(f) => setFiliado(f)}
      />

      {filiado && <CardContexto filiado={filiado} onAtualizar={setFiliado} />}
    </AtendimentoShell>
  );
}


function CardContexto({
  filiado,
  onAtualizar,
}: {
  filiado: Filiado;
  onAtualizar: (f: Filiado) => void;
}) {
  const [email, setEmail] = useState(filiado.contato.email ?? "");
  const [telefone, setTelefone] = useState(filiado.contato.telefone ?? "");
  const st = statusFiliado[filiado.status];

  const emailNovo = email.trim();
  const telefoneNovo = somenteDigitos(telefone);
  const emailValido = emailNovo === "" || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailNovo);
  const telefoneValido =
    telefoneNovo === "" || (telefoneNovo.length >= 10 && telefoneNovo.length <= 11);
  const houveMudanca =
    emailNovo !== (filiado.contato.email ?? "") ||
    telefoneNovo !== (filiado.contato.telefone ?? "");
  const temContato = Boolean(filiado.contato.email || filiado.contato.telefone);

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
      <Card className="shadow-soft">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground">
                <UserRound className="h-5 w-5" />
              </span>
              <div>
                <CardTitle className="text-lg">{filiado.nome}</CardTitle>
                <p className="text-xs text-muted-foreground">
                  CPF {cpfProtegido(filiado.cpf)} · matrícula {filiado.matricula}
                </p>
              </div>
            </div>
            <BadgeStatus estado={st} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
            <Campo rotulo="Plano" valor={filiado.plano} />
            <Campo rotulo="Filiado desde" valor={filiado.desde} />
            <Campo rotulo="Nascimento" valor={filiado.nascimento} />
            <Campo rotulo="Praça" valor={`${filiado.cidade} · ${filiado.uf}`} />
            <Campo rotulo="Carteirinha" valor={filiado.carteirinha} />
            <Campo rotulo="E-mail em cadastro" valor={emailProtegido(filiado.contato.email)} />
            <Campo
              rotulo="Telefone em cadastro"
              valor={telefoneProtegido(filiado.contato.telefone)}
            />
          </div>
          <Separator />
          <p className="text-xs text-muted-foreground">
            Contato exibido com mascaramento LGPD. A pré-visualização da ação e o registro em
            auditoria também mostram o valor mascarado: o dado completo não sai da tela de
            edição.
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-soft">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Contato do filiado</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="contato-email">
              <Mail className="mr-1 inline h-3.5 w-3.5" /> E-mail
            </Label>
            <Input
              id="contato-email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="nome@dominio.com.br"
              maxLength={255}
              autoComplete="off"
            />
            {!emailValido && <p className="text-xs text-destructive">E-mail inválido.</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="contato-telefone">
              <Phone className="mr-1 inline h-3.5 w-3.5" /> Telefone
            </Label>
            <Input
              id="contato-telefone"
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
              placeholder="31988776655"
              inputMode="numeric"
              maxLength={20}
              autoComplete="off"
            />
            {!telefoneValido && (
              <p className="text-xs text-destructive">Informe DDD e número, 10 ou 11 dígitos.</p>
            )}
          </div>

          <AcaoSensivel
            modulo={MODULO}
            acao="Atualizar contato do filiado"
            alvo={`CPF ${cpfProtegido(filiado.cpf)} · ${filiado.matricula}`}
            titulo="Atualizar contato"
            descricao="Confira exatamente o que será enviado ao cadastro antes de confirmar."
            rotuloConfirmar="Atualizar contato"
            payload={{
              matricula: filiado.matricula,
              cpf: cpfProtegido(filiado.cpf),
              de: {
                email: emailProtegido(filiado.contato.email),
                telefone: telefoneProtegido(filiado.contato.telefone),
              },
              para: {
                email: emailProtegido(emailNovo || null),
                telefone: telefoneProtegido(telefoneNovo || null),
              },
            }}
            onConfirmar={() => {
              // MOCK: apenas atualiza o estado local. Fase 2 chamará o proxy server-side.
              onAtualizar({
                ...filiado,
                contato: { email: emailNovo || null, telefone: telefoneNovo || null },
              });
            }}
            disabled={!houveMudanca || !emailValido || !telefoneValido}
          >
            <Button className="w-full" disabled={!houveMudanca || !emailValido || !telefoneValido}>
              Atualizar contato
            </Button>
          </AcaoSensivel>

          <AcaoSensivel
            modulo={MODULO}
            acao="Remover contato do filiado"
            alvo={`CPF ${cpfProtegido(filiado.cpf)} · ${filiado.matricula}`}
            titulo="Remover contato"
            descricao="O e-mail e o telefone serão apagados do cadastro. A ação fica registrada na auditoria."
            rotuloConfirmar="Remover contato"
            destrutiva
            payload={{
              matricula: filiado.matricula,
              cpf: cpfProtegido(filiado.cpf),
              remover: ["email", "telefone"],
              valoresAtuais: {
                email: emailProtegido(filiado.contato.email),
                telefone: telefoneProtegido(filiado.contato.telefone),
              },
            }}
            onConfirmar={() => {
              // MOCK: apenas atualiza o estado local. Fase 2 chamará o proxy server-side.
              onAtualizar({ ...filiado, contato: { email: null, telefone: null } });
              setEmail("");
              setTelefone("");
            }}
            disabled={!temContato}
          >
            <Button variant="outline" className="w-full" disabled={!temContato}>
              <Trash2 className="mr-2 h-4 w-4" /> Remover contato
            </Button>
          </AcaoSensivel>

          <AvisoDadoFicticio />
        </CardContent>
      </Card>
    </div>
  );
}

function Campo({ rotulo, valor }: { rotulo: string; valor: string }) {
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
        {rotulo}
      </div>
      <div className="mt-0.5 font-medium">{valor}</div>
    </div>
  );
}
