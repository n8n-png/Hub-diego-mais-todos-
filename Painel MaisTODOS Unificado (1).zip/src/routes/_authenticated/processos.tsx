import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, AlertTriangle, CheckSquare, FileText, Video, GitBranch } from "lucide-react";

export const Route = createFileRoute("/_authenticated/processos")({
  component: Processos,
  head: () => ({ meta: [{ title: "Processos · MaisTODOS" }] }),
});

const processos = [
  {
    nome: "Cancelamento de conta",
    cat: "Atendimento",
    tempo: "6 min",
    erros: "Falta de validação de identidade",
  },
  {
    nome: "Emissão de 2ª via de boleto",
    cat: "Financeiro",
    tempo: "3 min",
    erros: "Enviar boleto vencido",
  },
  {
    nome: "Antecipação de recebíveis",
    cat: "Financeiro",
    tempo: "10 min",
    erros: "Cálculo de taxa incorreto",
  },
  {
    nome: "Reset de senha",
    cat: "Acesso",
    tempo: "2 min",
    erros: "Não confirmar e-mail cadastrado",
  },
];

function Processos() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Processos internos</h1>
          <p className="mt-1 text-muted-foreground">
            Passo a passo oficial dos procedimentos da MaisTODOS.
          </p>
        </header>

        <div className="grid gap-4 lg:grid-cols-2">
          {processos.map((p) => (
            <Card key={p.nome} className="shadow-soft transition-all hover:shadow-glow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <Badge variant="secondary" className="mb-2">
                      {p.cat}
                    </Badge>
                    <h3 className="text-lg font-semibold">{p.nome}</h3>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <div className="flex items-center gap-1 justify-end">
                      <Clock className="h-3 w-3" /> {p.tempo}
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-2 rounded-lg bg-muted p-2">
                    <GitBranch className="h-3 w-3 text-primary" /> Fluxograma
                  </div>
                  <div className="flex items-center gap-2 rounded-lg bg-muted p-2">
                    <CheckSquare className="h-3 w-3 text-primary" /> Checklist
                  </div>
                  <div className="flex items-center gap-2 rounded-lg bg-muted p-2">
                    <FileText className="h-3 w-3 text-primary" /> Documentos
                  </div>
                  <div className="flex items-center gap-2 rounded-lg bg-muted p-2">
                    <Video className="h-3 w-3 text-primary" /> Vídeo
                  </div>
                </div>

                <div className="mt-4 flex items-start gap-2 rounded-lg bg-destructive/5 p-3 text-xs text-destructive">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <div>
                    <strong>Erro comum:</strong> {p.erros}
                  </div>
                </div>

                <Button className="mt-4 w-full">Abrir procedimento</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
