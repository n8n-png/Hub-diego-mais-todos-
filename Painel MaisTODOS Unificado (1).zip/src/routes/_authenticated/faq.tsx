import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/_authenticated/faq")({
  component: Faq,
  head: () => ({ meta: [{ title: "FAQ · MaisTODOS" }] }),
});

const faq = [
  {
    q: "Como funciona a Universidade MaisTODOS?",
    a: "É uma plataforma de treinamento com cursos, avaliações e certificados baseados nos processos oficiais da empresa.",
  },
  {
    q: "Posso acessar do celular?",
    a: "Sim, toda a plataforma é responsiva e funciona em qualquer dispositivo.",
  },
  {
    q: "Como pergunto à Maisa, a assistente do Hub?",
    a: "Clique no botão flutuante do assistente, no canto da tela, e digite sua dúvida em linguagem natural.",
  },
  {
    q: "Onde encontro os certificados?",
    a: "Na área 'Meu Progresso' você pode baixar todos os seus certificados.",
  },
  {
    q: "Como reportar um erro no conteúdo?",
    a: "Abra um chamado com o seu supervisor informando o documento e o trecho incorreto.",
  },
];

function Faq() {
  return (
    <AppLayout>
      <div className="mx-auto max-w-3xl space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Perguntas Frequentes</h1>
          <p className="mt-1 text-muted-foreground">
            Tire suas dúvidas mais comuns sobre a plataforma.
          </p>
        </header>
        <Accordion type="single" collapsible className="rounded-2xl border bg-card p-2 shadow-soft">
          {faq.map((f, i) => (
            <AccordionItem key={i} value={`i-${i}`} className="border-b last:border-0">
              <AccordionTrigger className="px-4 text-left font-medium hover:no-underline">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="px-4 text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </AppLayout>
  );
}
