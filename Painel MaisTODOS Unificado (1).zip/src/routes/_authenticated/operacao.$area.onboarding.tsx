import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, FileCheck2, Info, Layers, ShieldCheck } from "lucide-react";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { FluxogramaFases } from "@/components/FluxogramaFases";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea } from "@/data/operacao";
import {
  atualizacaoOnboarding,
  documentosPorTipo,
  fasesOnboarding,
  passosOnboarding,
  providersOnboarding,
  retornosOnboarding,
} from "@/data/conta-digital";

export const Route = createFileRoute("/_authenticated/operacao/$area/onboarding")({
  component: OnboardingContaDigital,
  head: () => ({
    meta: [
      { title: "Fluxo de Onboarding · Conta Digital · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "As 10 etapas do onboarding da conta digital MaisTODOS, com providers, retornos possíveis, onde verificar e a ação de suporte em cada etapa.",
      },
      { property: "og:title", content: "Fluxo de Onboarding · Conta Digital · Hub MaisTODOS" },
      {
        property: "og:description",
        content:
          "Mapeamento de retornos do onboarding: KYB, KYC, perfis e conta no Bankly, com ação de suporte por situação.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function OnboardingContaDigital() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Fluxo de Onboarding" },
      ]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Fluxo de Onboarding</h1>
          <p className="mt-1 max-w-3xl text-muted-foreground">
            O onboarding da conta digital tem 10 etapas em sequência: cada uma depende do sucesso da
            anterior. Aqui estão o caminho completo, os providers responsáveis e o que fazer quando
            uma etapa retorna erro ou reprovação. Última atualização: {atualizacaoOnboarding}.
          </p>
        </header>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Layers className="h-4 w-4 text-primary" /> Providers envolvidos
          </h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {providersOnboarding.map((p) => (
              <Card key={p.nome} className="shadow-soft">
                <CardContent className="p-5">
                  <h3 className="font-semibold">{p.nome}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{p.papel}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <Card className="border-primary/20 bg-accent/40 shadow-soft">
          <CardContent className="p-5">
            <h2 className="flex items-center gap-2 font-semibold text-primary">
              <ShieldCheck className="h-4 w-4" /> Como ler o fluxo
            </h2>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li className="flex gap-2">
                <span aria-hidden className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                Etapas 1 a 4 validam identidade e empresa: cadastro interno, KYB automático na CAF,
                envio de documentos e biometria facial.
              </li>
              <li className="flex gap-2">
                <span aria-hidden className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                Etapas 5 a 9 montam a estrutura bancária no Bankly: verificação de conta existente,
                perfil pessoal, perfil empresarial e criação da conta.
              </li>
              <li className="flex gap-2">
                <span aria-hidden className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />A
                etapa 10 apenas conclui e ativa a conta, então falha aqui quase sempre vem de uma
                etapa anterior.
              </li>
            </ul>
          </CardContent>
        </Card>

        <section className="space-y-3">
          <h2 className="text-lg font-semibold">As 10 etapas, passo a passo</h2>
          <FluxogramaFases fases={fasesOnboarding} passos={passosOnboarding} />
        </section>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <FileCheck2 className="h-4 w-4 text-primary" /> Documentos obrigatórios por tipo
            societário
          </h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {documentosPorTipo.map((d) => (
              <Card key={d.tipo} className="shadow-soft">
                <CardContent className="p-5">
                  <h3 className="font-semibold">{d.tipo}</h3>
                  <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">
                    {d.itens.map((i) => (
                      <li key={i} className="flex gap-2">
                        <span
                          aria-hidden
                          className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary"
                        />
                        {i}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-lg font-semibold">Retornos possíveis e ação do suporte</h2>
          {retornosOnboarding.map((etapa) => (
            <Card key={etapa.slug} className="shadow-soft">
              <CardContent className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-semibold">{etapa.titulo}</h3>
                  <Badge variant="outline">{etapa.provider}</Badge>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{etapa.contexto}</p>

                {etapa.alerta && (
                  <p className="mt-3 flex gap-2 rounded-lg bg-muted px-3 py-2 text-xs text-foreground/80">
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    <span>{etapa.alerta}</span>
                  </p>
                )}

                <div className="mt-4 space-y-3">
                  {etapa.retornos.map((r) => (
                    <article
                      key={r.situacao}
                      className="rounded-xl border border-border border-l-4 border-l-primary/60 bg-card p-4"
                    >
                      <h4 className="font-medium leading-snug">{r.situacao}</h4>
                      <dl className="mt-2 grid gap-2 text-sm sm:grid-cols-2">
                        <div>
                          <dt className="text-xs font-medium text-foreground">Causa</dt>
                          <dd className="text-muted-foreground">{r.causa}</dd>
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-foreground">
                            O que o cliente vê
                          </dt>
                          <dd className="text-muted-foreground">{r.usuarioVe}</dd>
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-foreground">Onde verificar</dt>
                          <dd className="text-muted-foreground">{r.ondeVerificar}</dd>
                        </div>
                        <div>
                          <dt className="text-xs font-medium text-foreground">Ação do suporte</dt>
                          <dd className="text-muted-foreground">{r.acao}</dd>
                        </div>
                      </dl>
                      <p className="mt-3 flex gap-2 text-xs text-muted-foreground">
                        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                        <span>Escalar: {r.escalar}</span>
                      </p>
                    </article>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </section>
      </div>
    </OperacaoShell>
  );
}
