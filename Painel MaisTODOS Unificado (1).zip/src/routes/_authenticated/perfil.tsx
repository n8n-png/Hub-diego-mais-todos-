import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Camera, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { initials, useProfile } from "@/hooks/use-profile";

export const Route = createFileRoute("/_authenticated/perfil")({
  component: Perfil,
  head: () => ({
    meta: [
      { title: "Meu Perfil · Hub MaisTODOS" },
      {
        name: "description",
        content: "Atualize seu nome, foto de perfil e senha no Hub MaisTODOS.",
      },
      { property: "og:title", content: "Meu Perfil · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Atualize seu nome, foto de perfil e senha no Hub MaisTODOS.",
      },
    ],
  }),
});

const nameSchema = z.string().trim().min(3, "Informe seu nome completo").max(120);
const passwordSchema = z.string().min(6, "A senha deve ter no mínimo 6 caracteres").max(72);

function Perfil() {
  const { user, profile, avatarSrc, loading, reload } = useProfile();
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [changing, setChanging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) setName(profile.full_name ?? "");
  }, [profile]);

  async function saveName() {
    const parsed = nameSchema.safeParse(name);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: parsed.data })
      .eq("id", user.id);
    setSaving(false);
    if (error) {
      toast.error("Não foi possível salvar seu nome.");
      return;
    }
    toast.success("Perfil atualizado.");
    void reload();
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !user) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Selecione um arquivo de imagem.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 5MB.");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "jpg";
    const path = `${user.id}/avatar-${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(path, file, { upsert: true });
    if (uploadError) {
      setUploading(false);
      toast.error("Falha ao enviar a imagem.");
      return;
    }
    const { error } = await supabase
      .from("profiles")
      .update({ avatar_url: path })
      .eq("id", user.id);
    setUploading(false);
    if (error) {
      toast.error("Falha ao salvar a foto.");
      return;
    }
    toast.success("Foto atualizada.");
    void reload();
  }

  async function changePassword() {
    const parsed = passwordSchema.safeParse(password);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (password !== confirm) {
      toast.error("As senhas não conferem.");
      return;
    }
    setChanging(true);
    const { error } = await supabase.auth.updateUser({ password: parsed.data });
    setChanging(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setPassword("");
    setConfirm("");
    toast.success("Senha alterada com sucesso.");
  }

  return (
    <AppLayout>
      <div className="mx-auto max-w-3xl space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Meu Perfil</h1>
          <p className="mt-1 text-muted-foreground">Gerencie seus dados pessoais e sua senha.</p>
        </header>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Informações pessoais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center gap-5">
              <div className="relative">
                <Avatar className="h-20 w-20">
                  {avatarSrc && <AvatarImage src={avatarSrc} alt="Foto de perfil" />}
                  <AvatarFallback className="bg-gradient-primary text-lg font-semibold text-primary-foreground">
                    {initials(profile?.full_name, profile?.email)}
                  </AvatarFallback>
                </Avatar>
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                  aria-label="Alterar foto de perfil"
                  className="absolute -bottom-1 -right-1 rounded-full bg-primary p-2 text-primary-foreground shadow-md transition-transform hover:scale-105"
                >
                  {uploading ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Camera className="h-3.5 w-3.5" />
                  )}
                </button>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={onFile}
                />
              </div>
              <div className="text-sm text-muted-foreground">
                JPG ou PNG, até 5MB.
                <div className="font-medium text-foreground">{profile?.email}</div>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="nome">Nome completo</Label>
              <Input
                id="nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={120}
                disabled={loading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="perfil-email">E-mail</Label>
              <Input id="perfil-email" value={profile?.email ?? ""} disabled />
            </div>
            <Button className="bg-gradient-primary" onClick={saveName} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Salvar alterações
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Alterar senha</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="nova-senha">Nova senha</Label>
              <Input
                id="nova-senha"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="conf-senha">Confirmar nova senha</Label>
              <Input
                id="conf-senha"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <Button variant="outline" onClick={changePassword} disabled={changing}>
              {changing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Atualizar senha
            </Button>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
