import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AlertTriangle, CreditCard, Database } from "lucide-react";
import { AtendimentoShell } from "@/components/AtendimentoShell";
import { AcaoSensivel } from "@/components/AcaoSensivel";
import { BuscaFiliadoCpf } from "@/components/BuscaFiliadoCpf";
import { CabecalhoFiliado } from "@/components/CabecalhoFiliado";
import { TabelaAtendimento } from "@/components/TabelaAtendimento";
import { BadgeStatus } from "@/components/BadgeStatus";
import { AvisoDadoFicticio } from "@/components/AvisoDadoFicticio";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TableCell, TableRow } from "@/components/ui/table";
import { metaPagina } from "@/lib/head-meta";
import {
  buscarCarteirinhasMock,
  cpfProtegido,
  situacaoCartao,
  type CarteirinhasFiliado,
  type Filiado,
} from "@/data/atendimento";

export const Route = createFileRoute("/_authenticated/atendimento/carteirinhas")({
  component: Carteirinhas,
  head: () =>
    metaPagina({
      titulo: "Carteirinhas · Atendimento MaisTODOS",
      descricao:
        "Emissão e conferência de carteirinhas do filiado, com apoio das bases Softnex e Metabase e registro em auditoria.",
      descricaoCurta: "Emissão e conferência de carteirinhas na área de Atendimento MaisTODOS.",
    }),
});

const MODULO = "Carteirinhas";

function Carteirinhas() {
  const [filiado, setFiliado] = useState<Filiado | null>(null);
  const [dados, setDados] = useState<CarteirinhasFiliado>({ softnex: [], metabase: [] });

  function cancelarCartao(numero: string) {
    // MOCK: apenas atualiza o estado local. Fase 2 chamará o proxy server-side.
    setDados((atual) => ({
      ...atual,
      softnex: atual.softnex.map((c) =>
        c.numero === numero ? { ...c, situacao: "Cancelado" as const } : c,
      ),
    }));
  }

  return (
    <AtendimentoShell
      modulo="atendimento_carteirinhas"
      titulo="Carteirinhas"
      descricao="Conferência das carteirinhas do filiado, com a origem de cada dado sempre etiquetada."
    >
      <div className="flex items-start gap-3 rounded-xl border border-warning/40 bg-warning-soft px-4 py-3 text-sm text-warning-foreground">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" aria-hidden="true" />
        <p>Softnex ainda sem endpoint definido. Dados fictícios. Endpoint a levantar na Fase 2.</p>
      </div>

      <BuscaFiliadoCpf
        titulo="Buscar carteirinhas por CPF"
        onEncontrado={(f, cpfDigitos) => {
          setFiliado(f);
          setDados(cpfDigitos ? buscarCarteirinhasMock(cpfDigitos) : { softnex: [], metabase: [] });
        }}
      />

      {filiado && (
        <>
          <Card className="shadow-soft">
            <CabecalhoFiliado
              filiado={filiado}
              titulo="Carteirinhas vinculadas"
              icon={CreditCard}
              selo="Fonte: Softnex"
            />
            <CardContent className="space-y-4">
              <TabelaAtendimento
                colunas={[
                  { rotulo: "Cartão" },
                  { rotulo: "Vínculo" },
                  { rotulo: "Titularidade" },
                  { rotulo: "Validade" },
                  { rotulo: "Entrada e saída" },
                  { rotulo: "Situação" },
                  { rotulo: "Ações", alinhamento: "right" },
                ]}
                vazioVisivel={dados.softnex.length === 0}
                vazio={{
                  titulo: "Nenhuma carteirinha vinculada",
                  descricao: "Este CPF não tem carteirinha vinculada na base de teste.",
                }}
              >
                {dados.softnex.map((c) => {
                  const cancelado = c.situacao === "Cancelado";
                  return (
                    <TableRow key={c.numero}>
                      <TableCell className="whitespace-nowrap font-medium">{c.numero}</TableCell>
                      <TableCell className="whitespace-nowrap">{c.vinculo}</TableCell>
                      <TableCell>{c.nome}</TableCell>
                      <TableCell className="whitespace-nowrap">{c.validade}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {c.entrada} · {c.saida ?? "sem saída registrada"}
                      </TableCell>
                      <TableCell>
                        <BadgeStatus estado={situacaoCartao[c.situacao]} />
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap justify-end gap-2">
                          <AcaoSensivel
                            modulo={MODULO}
                            acao="Cancelar cartão"
                            alvo={`CPF ${cpfProtegido(filiado.cpf)} · cartão ${c.numero}`}
                            titulo="Cancelar cartão"
                            descricao="O cartão deixa de funcionar para o filiado. Escreva a justificativa antes de confirmar."
                            rotuloConfirmar="Cancelar cartão"
                            destrutiva
                            observacaoObrigatoria
                            payload={{
                              origem: "Softnex",
                              acao: "cancelar-cartao",
                              cpf: cpfProtegido(filiado.cpf),
                              cartao: c.numero,
                              vinculo: c.vinculo,
                            }}
                            onConfirmar={() => cancelarCartao(c.numero)}
                            disabled={cancelado}
                          >
                            <Button variant="outline" size="sm" disabled={cancelado}>
                              Cancelar cartão
                            </Button>
                          </AcaoSensivel>

                          <AcaoSensivel
                            modulo={MODULO}
                            acao="Estornar transação do cartão"
                            alvo={`CPF ${cpfProtegido(filiado.cpf)} · cartão ${c.numero}`}
                            titulo="Estornar transação do cartão"
                            descricao="Esta ação mexe em dinheiro do filiado. Confira o envio e escreva a justificativa antes de confirmar."
                            rotuloConfirmar="Solicitar estorno"
                            destrutiva
                            observacaoObrigatoria
                            payload={{
                              origem: "Softnex",
                              acao: "estornar-transacao-cartao",
                              cpf: cpfProtegido(filiado.cpf),
                              cartao: c.numero,
                            }}
                            onConfirmar={() => {
                              // MOCK: nenhuma alteração de dado nesta onda.
                            }}
                            disabled={cancelado}
                          >
                            <Button variant="outline" size="sm" disabled={cancelado}>
                              Estornar transação
                            </Button>
                          </AcaoSensivel>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TabelaAtendimento>

              <AvisoDadoFicticio fonte="Softnex" />
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CabecalhoFiliado
              filiado={filiado}
              titulo="Private Labels, cartões emitidos"
              icon={Database}
              complemento="consulta somente leitura, sem ações disponíveis"
              selo="Fonte: Metabase"
            />
            <CardContent className="space-y-4">
              <TabelaAtendimento
                colunas={[
                  { rotulo: "Identificador" },
                  { rotulo: "Produto" },
                  { rotulo: "Emissão" },
                  { rotulo: "Bandeira" },
                  { rotulo: "Situação" },
                ]}
                vazioVisivel={dados.metabase.length === 0}
                vazio={{
                  titulo: "Nenhum Private Label emitido",
                  descricao: "Este CPF não tem Private Label emitido na base de teste.",
                }}
              >
                {dados.metabase.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.id}</TableCell>
                    <TableCell>{p.produto}</TableCell>
                    <TableCell className="whitespace-nowrap">{p.emissao}</TableCell>
                    <TableCell>{p.bandeira}</TableCell>
                    <TableCell>{p.situacao}</TableCell>
                  </TableRow>
                ))}
              </TabelaAtendimento>

              <AvisoDadoFicticio fonte="Metabase" />
            </CardContent>
          </Card>
        </>
      )}
    </AtendimentoShell>
  );
}
