import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { EstadoVazio } from "@/components/EstadoVazio";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { getArea } from "@/data/operacao";
import { Search, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/ferramentas/")({
  component: Ferramentas,
  head: () => ({
    meta: [
      { title: "Central de Ferramentas · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Todas as ferramentas da operação com descrição, acesso, responsáveis e tutoriais.",
      },
      { property: "og:title", content: "Central de Ferramentas · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Zendesk, Slack, Retool, MetaBase e demais sistemas da operação em um só lugar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Ferramentas() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  const [q, setQ] = useState("");
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  const termo = q.trim().toLowerCase();
  const lista = area.ferramentas.filter(
    (t) =>
      !termo ||
      t.nome.toLowerCase().includes(termo) ||
      t.descricao.toLowerCase().includes(termo) ||
      t.categoria.toLowerCase().includes(termo),
  );

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Central de Ferramentas" },
      ]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
            🛠️ Central de Ferramentas
          </h1>
          <p className="mt-1 text-muted-foreground">
            Cada ferramenta possui página própria com descrição, link de acesso, quem utiliza, como
            solicitar acesso e tutoriais.
          </p>
        </header>

        <div className="relative max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar ferramenta…"
            className="pl-9"
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {lista.map((t) => (
            <Link
              key={t.slug}
              to="/operacao/$area/ferramentas/$tool"
              params={{ area: area.slug, tool: t.slug }}
              className="group"
            >
              <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                <CardContent className="p-5">
                  <Badge variant="secondary" className="mb-2">
                    {t.categoria}
                  </Badge>
                  <h2 className="font-semibold">{t.nome}</h2>
                  <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{t.descricao}</p>
                  <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                    Ver detalhes{" "}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
        {lista.length === 0 && (
          <EstadoVazio
            titulo="Nenhuma ferramenta encontrada"
            descricao="Ajuste os termos da busca para ver outras ferramentas desta área."
          />
        )}
      </div>
    </OperacaoShell>
  );
}
