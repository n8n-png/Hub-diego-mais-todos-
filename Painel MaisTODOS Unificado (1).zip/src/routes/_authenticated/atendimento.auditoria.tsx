import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, RefreshCw, XCircle } from "lucide-react";
import { AtendimentoShell } from "@/components/AtendimentoShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Carregando } from "@/components/Carregando";
import { EstadoVazio } from "@/components/EstadoVazio";
import { listarAuditoria } from "@/lib/atendimento-auditoria";
import { sanitizarPayloadAuditoria, higienizarTextoLivre } from "@/data/atendimento";

import { usePodeOperar } from "@/components/GuardaOperacional";

export const Route = createFileRoute("/_authenticated/atendimento/auditoria")({
  component: Auditoria,
  head: () => ({
    meta: [
      { title: "Auditoria · Atendimento MaisTODOS" },
      {
        name: "description",
        content:
          "Trilha completa das ações sensíveis do Atendimento: quem executou, quando, qual módulo e quais dados foram enviados.",
      },
      { property: "og:title", content: "Auditoria · Atendimento MaisTODOS" },
      {
        property: "og:description",
        content: "Trilha completa das ações sensíveis do Atendimento MaisTODOS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Auditoria · Atendimento MaisTODOS" },
      {
        name: "twitter:description",
        content: "Trilha completa das ações sensíveis do Atendimento MaisTODOS.",
      },
    ],
  }),
});

function Auditoria() {
  // Ler a auditoria é operação de gestão: gestor e admin. A gravação segue para todos.
  const { liberado } = usePodeOperar("auditoria");
  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["atendimento-auditoria"],
    queryFn: () => listarAuditoria(50),
    staleTime: 15_000,
    enabled: liberado,
  });

  const registros = data ?? [];

  return (
    <AtendimentoShell
      modulo="auditoria"
      titulo="Auditoria"
      descricao="Toda ação sensível confirmada no Atendimento fica registrada aqui, sem possibilidade de edição ou exclusão."
    >
      {/*
        RETENÇÃO DA TRILHA: pendente de definição jurídica e de compliance.
        Nada é apagado desta tabela e não existe expurgo agendado para ela.
        A rotina public.expurgar_dados_ia_antigos limpa apenas ai_queries e
        ai_usage, com 12 meses, e nunca toca em atendimento_auditoria.
      */}
      <div className="rounded-xl border border-border bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
        Retenção desta trilha: pendente de definição jurídica e de compliance. Por decisão de
        produto, nenhum registro é apagado nem editado, e não há expurgo agendado. Os dados
        operacionais de IA, perguntas e consumo, seguem política própria de 12 meses.
      </div>

      <div className="flex justify-end">
        <Button variant="outline" onClick={() => void refetch()} disabled={isFetching}>
          <RefreshCw className={isFetching ? "mr-2 h-4 w-4 animate-spin" : "mr-2 h-4 w-4"} />
          Atualizar
        </Button>
      </div>

      {isLoading ? (
        <Carregando mensagem="Carregando a trilha de auditoria…" blocos={2} />
      ) : registros.length === 0 ? (
        <EstadoVazio
          titulo="Nenhuma ação registrada ainda"
          descricao="Assim que uma ação sensível for confirmada, ela aparece nesta trilha com o responsável, o horário e os dados enviados."
        />
      ) : (
        <div className="space-y-3">
          {registros.map((r) => {
            const sucesso = r.resultado === "sucesso";
            return (
              <Card key={r.id} className="shadow-soft">
                <CardContent className="space-y-3 p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        {sucesso ? (
                          <CheckCircle2 className="h-4 w-4 text-success" />
                        ) : (
                          <XCircle className="h-4 w-4 text-destructive" />
                        )}
                        <span className="font-semibold">{r.acao}</span>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {r.modulo}
                        {r.alvo ? ` · ${r.alvo}` : ""} · {r.user_name ?? "colaborador"} ·{" "}
                        {new Date(r.created_at).toLocaleString("pt-BR")}
                      </p>
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        sucesso
                          ? "border-success/30 bg-success/10 text-success"
                          : "border-destructive/30 bg-destructive/10 text-destructive"
                      }
                    >
                      {sucesso ? "Sucesso" : "Falha"}
                    </Badge>
                  </div>

                  {r.observacao && (
                    <p className="text-sm text-secondary-foreground">{higienizarTextoLivre(r.observacao)}</p>
                  )}

                  <pre className="max-h-40 overflow-auto rounded-xl border border-border bg-secondary p-3 text-xs leading-relaxed text-secondary-foreground">
                    {JSON.stringify(sanitizarPayloadAuditoria(r.payload), null, 2)}
                  </pre>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </AtendimentoShell>
  );
}
