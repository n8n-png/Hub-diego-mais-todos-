import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getArea } from "@/data/operacao";
import { ArrowLeft, ArrowRight, MapPin, Phone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/comercial/$segmento/")({
  component: Segmento,
  head: () => ({
    meta: [
      { title: "Regionais comerciais · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Regionais do segmento comercial com consultores responsáveis e cobertura por estado.",
      },
      { property: "og:title", content: "Regionais comerciais · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Norte, Nordeste, Centro-Oeste, Sudeste e Sul: quem atende cada região.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Segmento() {
  const { area: slug, segmento } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  const seg = area.comercial.find((s) => s.slug === segmento);

  if (!seg) {
    return (
      <OperacaoShell
        area={area}
        crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Time Comercial" }]}
      >
        <Card className="border-dashed">
          <CardContent className="p-10 text-center">
            <p className="text-sm text-muted-foreground">Segmento não encontrado.</p>
            <Button asChild className="mt-4" variant="outline">
              <Link to="/operacao/$area/comercial" params={{ area: area.slug }}>
                Voltar
              </Link>
            </Button>
          </CardContent>
        </Card>
      </OperacaoShell>
    );
  }

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Time Comercial", to: `/operacao/${area.slug}/comercial` },
        { label: seg.nome },
      ]}
    >
      <div className="space-y-6">
        <Link
          to="/operacao/$area/comercial"
          params={{ area: area.slug }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Todos os segmentos
        </Link>

        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{seg.nome}</h1>
          <p className="mt-1 text-muted-foreground">{seg.descricao}</p>
        </header>

        {seg.coordenador && (
          <Card className="overflow-hidden shadow-soft">
            <CardContent className="flex flex-wrap items-center justify-between gap-4 bg-gradient-primary p-5 text-primary-foreground">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-widest opacity-80">
                  {seg.coordenador.cargo}
                </div>
                <div className="mt-1 text-xl font-bold">{seg.coordenador.nome}</div>
              </div>
              <a
                href={`tel:${seg.coordenador.telefone.replace(/\D/g, "")}`}
                className="inline-flex items-center gap-2 rounded-xl bg-primary-foreground/15 px-4 py-2 text-sm font-medium transition-colors hover:bg-primary-foreground/25"
              >
                <Phone className="h-4 w-4" /> {seg.coordenador.telefone}
              </a>
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Regionais
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {seg.regionais.map((r) => (
              <Link
                key={r.slug}
                to="/operacao/$area/comercial/$segmento/$regional"
                params={{ area: area.slug, segmento: seg.slug, regional: r.slug }}
                className="group"
              >
                <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      <h3 className="font-semibold">{r.nome}</h3>
                    </div>
                    <p className="mt-2 text-sm font-medium">{r.consultor}</p>
                    <p className="text-xs text-muted-foreground">{r.cargo}</p>
                    <p className="mt-1 text-xs text-muted-foreground">📞 {r.telefone}</p>
                    <div className="mt-3 flex flex-wrap gap-1">
                      {r.estados.map((e) => (
                        <Badge key={e} variant="secondary" className="text-[10px]">
                          {e}
                        </Badge>
                      ))}
                    </div>
                    <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                      Ver contato{" "}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </OperacaoShell>
  );
}
