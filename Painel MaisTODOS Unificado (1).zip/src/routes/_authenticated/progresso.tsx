import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Award, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/progresso")({
  component: Progresso,
  head: () => ({ meta: [{ title: "Meu Progresso · MaisTODOS" }] }),
});

const trilhas = [
  { nome: "Atendimento", progresso: 90 },
  { nome: "Financeiro", progresso: 55 },
  { nome: "Sistema Interno", progresso: 40 },
  { nome: "Boas Práticas", progresso: 20 },
];

const certs = ["Atendimento humanizado", "Maquininhas · setup"];

function Progresso() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Meu Progresso</h1>
          <p className="mt-1 text-muted-foreground">
            Acompanhe sua evolução e certificados conquistados.
          </p>
        </header>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="shadow-soft lg:col-span-2">
            <CardHeader>
              <CardTitle>Trilhas de aprendizado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {trilhas.map((t) => (
                <div key={t.nome}>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="font-medium">{t.nome}</span>
                    <span className="text-primary font-semibold">{t.progresso}%</span>
                  </div>
                  <Progress value={t.progresso} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="shadow-soft bg-gradient-primary text-primary-foreground border-0">
            <CardHeader>
              <CardTitle className="text-primary-foreground">Certificados</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {certs.map((c) => (
                <div
                  key={c}
                  className="flex items-center gap-3 rounded-lg bg-white/10 p-3 backdrop-blur"
                >
                  <Award className="h-5 w-5 text-lime" />
                  <span className="flex-1 text-sm font-medium">{c}</span>
                  <Button size="icon" variant="ghost" className="text-white hover:bg-white/20">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Badge className="bg-lime text-lime-foreground border-0 mt-2">
                +2 conquistados este mês
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
