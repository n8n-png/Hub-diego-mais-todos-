import { createFileRoute } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel, VazioSecao } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea } from "@/data/operacao";
import { ShieldAlert } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/fluxo")({
  component: FluxoOperacao,
  head: () => ({
    meta: [
      { title: "Fluxo da Operação · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Jornada operacional completa, do recebimento da demanda até a conclusão, independentemente da financeira.",
      },
      { property: "og:title", content: "Fluxo da Operação · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Etapas, responsáveis, SLAs e regras de ouro da operação.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function FluxoOperacao() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  const fluxo = area.fluxoOperacao;

  return (
    <OperacaoShell
      area={area}
      crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Fluxo da Operação" }]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">📊 Fluxo da Operação</h1>
          <p className="mt-1 max-w-3xl text-muted-foreground">{fluxo?.resumo}</p>
        </header>

        {!fluxo ? (
          <VazioSecao
            titulo="Fluxo em construção"
            descricao="Ainda não há um fluxo macro publicado para esta área."
          />
        ) : (
          <>
            <ol className="relative space-y-4 border-l-2 border-primary/20 pl-6">
              {fluxo.etapas.map((e, i) => (
                <li key={e.titulo} className="relative">
                  <span className="absolute -left-[31px] flex h-6 w-6 items-center justify-center rounded-full bg-gradient-primary text-[11px] font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <Card className="shadow-soft">
                    <CardContent className="p-5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h2 className="font-semibold">{e.titulo}</h2>
                        <div className="flex gap-2">
                          <Badge variant="secondary">{e.responsavel}</Badge>
                          <Badge className="bg-accent text-accent-foreground">{e.sla}</Badge>
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">{e.descricao}</p>
                    </CardContent>
                  </Card>
                </li>
              ))}
            </ol>

            <Card className="border-destructive/20 bg-destructive/5 shadow-soft">
              <CardContent className="p-6">
                <h2 className="flex items-center gap-2 font-semibold text-destructive">
                  <ShieldAlert className="h-4 w-4" /> Regras de ouro
                </h2>
                <ul className="mt-3 space-y-2 text-sm text-foreground/90">
                  {fluxo.regras.map((r) => (
                    <li key={r} className="flex gap-2">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-destructive" />
                      {r}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </OperacaoShell>
  );
}
