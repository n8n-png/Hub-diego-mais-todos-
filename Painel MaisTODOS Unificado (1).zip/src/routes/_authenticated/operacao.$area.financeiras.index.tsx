import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea } from "@/data/operacao";
import { ArrowRight, Clock } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/financeiras/")({
  component: Financeiras,
  head: () => ({
    meta: [
      { title: "Financeiras Parceiras · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Todas as financeiras parceiras com processo, fluxograma, scripts, prazos e canais de acionamento.",
      },
      { property: "og:title", content: "Financeiras Parceiras · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Capim, Parcelex, Lara, Nupay, INSS e demais parceiras da operação.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Financeiras() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Financeiras Parceiras" },
      ]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
            🏦 Financeiras Parceiras
          </h1>
          <p className="mt-1 text-muted-foreground">
            Todas as parceiras seguem a mesma estrutura: visão geral, processo, fluxograma, scripts,
            prazos, canais de acionamento, documentação e histórico.
          </p>
        </header>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {area.financeiras.map((f) => (
            <Link
              key={f.slug}
              to="/operacao/$area/financeiras/$parceira"
              params={{ area: area.slug, parceira: f.slug }}
              className="group"
            >
              <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-semibold">{f.nome}</h2>
                    <Badge variant="secondary">{f.canais.length} canal</Badge>
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{f.resumo}</p>
                  <div className="mt-3 flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" /> {f.visaoGeral.sla}
                  </div>
                  <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                    Abrir financeira{" "}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </OperacaoShell>
  );
}
