import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Wallet } from "lucide-react";
import { AtendimentoShell } from "@/components/AtendimentoShell";
import { AcaoSensivel } from "@/components/AcaoSensivel";
import { BuscaFiliadoCpf } from "@/components/BuscaFiliadoCpf";
import { CabecalhoFiliado } from "@/components/CabecalhoFiliado";
import { TabelaAtendimento } from "@/components/TabelaAtendimento";
import { BadgeStatus } from "@/components/BadgeStatus";
import { AvisoDadoFicticio } from "@/components/AvisoDadoFicticio";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TableCell, TableRow } from "@/components/ui/table";
import { metaPagina } from "@/lib/head-meta";
import {
  buscarCashbackMock,
  cpfProtegido,
  dataBr,
  moeda,
  statusCashback,
  type CashbackStatus,
  type Filiado,
  type LancamentoCashback,
} from "@/data/atendimento";

export const Route = createFileRoute("/_authenticated/atendimento/cashback")({
  component: Cashback,
  head: () =>
    metaPagina({
      titulo: "Cashback · Atendimento MaisTODOS",
      descricao:
        "Consulta de cashback do filiado e liberação em lote, com pré-visualização, confirmação humana e registro em auditoria.",
      descricaoCurta:
        "Consulta de cashback do filiado e liberação em lote na área de Atendimento.",
    }),
});

const MODULO = "Cashback";
const WORKFLOW = "267b9b80-1397-4911-b055-d5c8a9b0c507";

const STATUS: CashbackStatus[] = ["Pending", "Authorized", "Expired", "Dead", "Canceled"];

function Cashback() {
  const [filiado, setFiliado] = useState<Filiado | null>(null);
  const [cpf, setCpf] = useState("");
  const [lancamentos, setLancamentos] = useState<LancamentoCashback[]>([]);
  const [status, setStatus] = useState<string>("todos");
  const [de, setDe] = useState("");
  const [ate, setAte] = useState("");

  const filtrados = useMemo(
    () =>
      lancamentos.filter((l) => {
        if (status !== "todos" && l.status !== status) return false;
        if (de && l.data < de) return false;
        if (ate && l.data > ate) return false;
        return true;
      }),
    [lancamentos, status, de, ate],
  );

  const totalFiltrado = filtrados.reduce((soma, l) => soma + l.valor, 0);
  const pendentes = lancamentos.filter((l) => l.status === "Pending");
  const totalPendente = pendentes.reduce((soma, l) => soma + l.valor, 0);

  function liberarLote() {
    // MOCK: apenas atualiza o estado local. Fase 2 chamará o proxy server-side.
    setLancamentos((atual) =>
      atual.map((l) =>
        l.status === "Pending"
          ? {
              ...l,
              status: "Authorized",
              autorizado: true,
              liquidacao: new Date().toISOString().slice(0, 10),
            }
          : l,
      ),
    );
  }

  return (
    <AtendimentoShell
      modulo="atendimento_cashback"
      titulo="Cashback"
      descricao="Consulta do histórico de cashback do filiado, somente leitura, e liberação em lote dos lançamentos pendentes."
    >
      <BuscaFiliadoCpf
        titulo="Buscar cashback por CPF"
        onEncontrado={(f, cpfDigitos) => {
          setFiliado(f);
          setCpf(cpfDigitos);
          setLancamentos(cpfDigitos ? buscarCashbackMock(cpfDigitos) : []);
          setStatus("todos");
          setDe("");
          setAte("");
        }}
      />

      {filiado && (
        <>
          <Card className="shadow-soft">
            <CabecalhoFiliado
              filiado={filiado}
              titulo="Lançamentos de cashback"
              complemento="consulta somente leitura"
              selo={`${filtrados.length} de ${lancamentos.length} lançamentos`}
            />
            <CardContent className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label htmlFor="cb-status">Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger id="cb-status">
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos</SelectItem>
                      {STATUS.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="cb-de">Data inicial</Label>
                  <Input
                    id="cb-de"
                    type="date"
                    value={de}
                    onChange={(e) => setDe(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="cb-ate">Data final</Label>
                  <Input
                    id="cb-ate"
                    type="date"
                    value={ate}
                    onChange={(e) => setAte(e.target.value)}
                  />
                </div>
              </div>

              <TabelaAtendimento
                colunas={[
                  { rotulo: "Data" },
                  { rotulo: "Descrição" },
                  { rotulo: "Valor (R$)", alinhamento: "right" },
                  { rotulo: "Status" },
                  { rotulo: "Data de liquidação" },
                  { rotulo: "Autorizado" },
                ]}
                vazioVisivel={filtrados.length === 0}
                vazio={{
                  titulo: "Nenhum lançamento encontrado",
                  descricao: "Ajuste o status ou o período para ver outros lançamentos.",
                }}
                rodape={
                  <TableRow>
                    <TableCell colSpan={2}>Total filtrado</TableCell>
                    <TableCell className="text-right font-semibold">
                      {moeda(totalFiltrado)}
                    </TableCell>
                    <TableCell colSpan={3} />
                  </TableRow>
                }
              >
                {filtrados.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="whitespace-nowrap">{dataBr(l.data)}</TableCell>
                    <TableCell>{l.descricao}</TableCell>
                    <TableCell className="text-right font-medium">{moeda(l.valor)}</TableCell>
                    <TableCell>
                      <BadgeStatus estado={statusCashback[l.status]} />
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-muted-foreground">
                      {dataBr(l.liquidacao)}
                    </TableCell>
                    <TableCell className={l.autorizado ? "font-medium text-success" : undefined}>
                      {l.autorizado ? "sim" : "não"}
                    </TableCell>
                  </TableRow>
                ))}
              </TabelaAtendimento>

              <AvisoDadoFicticio fonte="Solatio ProspectorAPI/Cashback" />
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Wallet className="h-4 w-4 text-primary" />
                Liberação de cashback pendente em lote
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-border bg-secondary p-3">
                  <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                    Lançamentos pendentes
                  </div>
                  <div className="mt-0.5 text-lg font-semibold">{pendentes.length}</div>
                </div>
                <div className="rounded-xl border border-border bg-secondary p-3">
                  <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                    Total pendente
                  </div>
                  <div className="mt-0.5 text-lg font-semibold">{moeda(totalPendente)}</div>
                </div>
              </div>

              <AcaoSensivel
                modulo={MODULO}
                acao="Liberar cashback pendente em lote"
                alvo={`CPF ${cpfProtegido(filiado.cpf)} · ${filiado.matricula}`}
                titulo="Liberar cashback pendente em lote"
                descricao="Todos os lançamentos com status Pending deste CPF passam para Authorized."
                rotuloConfirmar="Liberar em lote"
                payload={{
                  metodo: "POST",
                  url: "/webhook/cashback/liberar-lote",
                  body: { cpf: cpfProtegido(cpf || filiado.cpf), workflow: WORKFLOW },
                }}
                onConfirmar={liberarLote}
                disabled={pendentes.length === 0}
              >
                <Button className="w-full sm:w-auto" disabled={pendentes.length === 0}>
                  Liberar {pendentes.length} lançamento(s) pendente(s)
                </Button>
              </AcaoSensivel>

              <AvisoDadoFicticio />
            </CardContent>
          </Card>
        </>
      )}
    </AtendimentoShell>
  );
}
