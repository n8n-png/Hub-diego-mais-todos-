import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, Info, Users, Workflow } from "lucide-react";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { FluxogramaFases } from "@/components/FluxogramaFases";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getArea } from "@/data/operacao";
import {
  automacoesLogistica,
  fluxosLogistica,
  papeisLogistica,
  type FluxoLogistica,
} from "@/data/logistica";

export const Route = createFileRoute("/_authenticated/operacao/$area/fluxos")({
  component: FluxosLogistica,
  validateSearch: (search: Record<string, unknown>) => ({
    fluxo: typeof search.fluxo === "string" ? search.fluxo : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Fluxos de Envio · Logística · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Passo a passo dos fluxos de Logística Supply: maquininhas, bobinas, carteirinhas Private Label e follow-up de rastreio.",
      },
      { property: "og:title", content: "Fluxos de Envio · Logística · Hub MaisTODOS" },
      {
        property: "og:description",
        content:
          "Fluxogramas detalhados, responsáveis por etapa, pontos críticos e automações priorizadas da Logística.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function FluxoDetalhe({ fluxo }: { fluxo: FluxoLogistica }) {
  return (
    <div className="space-y-6">
      <Card className="shadow-soft">
        <CardContent className="p-5">
          <h2 className="font-semibold">{fluxo.nome}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{fluxo.resumo}</p>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {fluxo.sistemas.map((s) => (
              <Badge key={s} variant="outline">
                {s}
              </Badge>
            ))}
          </div>

          <dl className="mt-4 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
            <div className="flex gap-1">
              <dt className="font-medium text-foreground">Fases:</dt>
              <dd>{fluxo.fases.length}</dd>
            </div>
            <div className="flex gap-1">
              <dt className="font-medium text-foreground">Etapas mapeadas:</dt>
              <dd>{fluxo.passos.length}</dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      {fluxo.notas && fluxo.notas.length > 0 && (
        <Card className="border-primary/20 bg-accent/40 shadow-soft">
          <CardContent className="p-5">
            <h3 className="flex items-center gap-2 font-semibold text-primary">
              <Info className="h-4 w-4" /> Pontos de atenção antes de começar
            </h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              {fluxo.notas.map((n) => (
                <li key={n} className="flex gap-2">
                  <span aria-hidden className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {n}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <FluxogramaFases fases={fluxo.fases} passos={fluxo.passos} />

      <Card className="border-destructive/20 bg-destructive/5 shadow-soft">
        <CardContent className="p-5">
          <h3 className="flex items-center gap-2 font-semibold text-destructive">
            <AlertTriangle className="h-4 w-4" /> Pontos críticos deste fluxo
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            {fluxo.pontosCriticos.map((c) => (
              <li key={c} className="flex gap-2">
                <span
                  aria-hidden
                  className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-destructive"
                />
                {c}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

function FluxosLogistica() {
  const { area: slug } = Route.useParams();
  const { fluxo: fluxoParam } = Route.useSearch();
  const area = getArea(slug);

  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  const inicial =
    fluxosLogistica.find((f) => f.slug === fluxoParam)?.slug ?? fluxosLogistica[0]!.slug;

  return (
    <OperacaoShell
      area={area}
      crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Fluxos de Envio" }]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Fluxos de Envio</h1>
          <p className="mt-1 max-w-3xl text-muted-foreground">
            Mapeamento dos processos de Supply, do pedido até o gatilho de cobrança. Cada fluxo traz
            o fluxograma montado aqui no Hub, com o caminho exato em cada sistema, o responsável de
            cada etapa e os pontos críticos que precisam de atenção.
          </p>
        </header>

        <Tabs key={inicial} defaultValue={inicial} className="space-y-6">
          <TabsList className="flex h-auto flex-wrap justify-start gap-1">
            {fluxosLogistica.map((f) => (
              <TabsTrigger key={f.slug} value={f.slug}>
                {f.nome}
              </TabsTrigger>
            ))}
          </TabsList>

          {fluxosLogistica.map((f) => (
            <TabsContent key={f.slug} value={f.slug}>
              <FluxoDetalhe fluxo={f} />
            </TabsContent>
          ))}
        </Tabs>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Users className="h-4 w-4 text-primary" /> Quem participa dos fluxos
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {papeisLogistica.map((p) => (
              <Card key={p.area} className="shadow-soft">
                <CardContent className="p-5">
                  <h3 className="font-semibold">{p.area}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{p.responsabilidade}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Workflow className="h-4 w-4 text-primary" /> Automações priorizadas
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {automacoesLogistica.map((a) => (
              <Card key={a.titulo} className="shadow-soft">
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-semibold">{a.titulo}</h3>
                    <Badge variant="outline">Prioridade {a.prioridade.toLowerCase()}</Badge>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{a.descricao}</p>
                  <dl className="mt-3 grid gap-1 text-xs text-muted-foreground">
                    <div className="flex gap-1">
                      <dt className="font-medium text-foreground">Pré-requisito:</dt>
                      <dd>{a.preRequisito}</dd>
                    </div>
                    <div className="flex gap-1">
                      <dt className="font-medium text-foreground">Complexidade:</dt>
                      <dd>{a.complexidade}</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </OperacaoShell>
  );
}
