import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download as DL, Presentation, FileCheck, Chrome } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/downloads")({
  component: Downloads,
  head: () => ({
    meta: [
      { title: "Downloads e Extensão IA · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Baixe a extensão do Copiloto MaisIA para Chrome e os manuais, apresentações e modelos oficiais da MaisTODOS.",
      },
      { property: "og:title", content: "Downloads e Extensão IA · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Extensão do Copiloto de IA e materiais oficiais para colaboradores MaisTODOS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const files = [
  { nome: "Manual do Colaborador 2026", tipo: "PDF", tamanho: "3.2 MB", icon: FileText },
  { nome: "Apresentação Institucional", tipo: "PPTX", tamanho: "8.7 MB", icon: Presentation },
  { nome: "Modelo de proposta comercial", tipo: "DOCX", tamanho: "180 KB", icon: FileCheck },
  { nome: "Guia de Atendimento", tipo: "PDF", tamanho: "1.5 MB", icon: FileText },
  { nome: "Checklist de cancelamento", tipo: "PDF", tamanho: "90 KB", icon: FileCheck },
];

function baixarExtensao() {
  fetch("/maisia-copiloto.zip")
    .then((res) => {
      if (!res.ok) throw new Error(`Falha no download: ${res.status}`);
      return res.blob();
    })
    .then((blob) => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "maisia-copiloto.zip";
      a.click();
      URL.revokeObjectURL(a.href);
    })
    .catch((err) => toast.error(err.message));
}

function Downloads() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Downloads</h1>
          <p className="mt-1 text-muted-foreground">Manuais, apresentações e modelos oficiais.</p>
        </header>

        <Card className="border-primary/30 bg-primary/5 shadow-soft">
          <CardContent className="space-y-4 p-5">
            <div className="flex flex-wrap items-center gap-4">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary text-primary-foreground">
                <Chrome className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-lg font-semibold">Extensão Copiloto MaisIA</span>
                  <Badge>Chrome / Edge</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Abre o Copiloto em um painel lateral sobre qualquer sistema de atendimento, com
                  atalho de seleção de texto para revisão.
                </p>
              </div>
              <Button onClick={baixarExtensao}>
                <DL className="mr-2 h-4 w-4" /> Baixar extensão
              </Button>
            </div>
            <ol className="list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
              <li>Descompacte o arquivo baixado.</li>
              <li>
                Abra <code>chrome://extensions</code> no Chrome (ou Edge, Brave, Arc, Opera).
              </li>
              <li>Ative o "Modo do desenvolvedor" no canto superior direito.</li>
              <li>Clique em "Carregar sem compactação" e selecione a pasta descompactada.</li>
              <li>Clique no ícone da extensão ou no botão flutuante roxo para abrir o Copiloto.</li>
            </ol>
          </CardContent>
        </Card>

        <div className="grid gap-3">
          {files.map((f) => {
            const Icon = f.icon;
            return (
              <Card key={f.nome} className="shadow-soft transition-all hover:shadow-glow">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{f.nome}</div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Badge variant="secondary">{f.tipo}</Badge>
                      <span>{f.tamanho}</span>
                    </div>
                  </div>
                  <Button variant="outline">
                    <DL className="mr-2 h-4 w-4" /> Baixar
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </AppLayout>
  );
}
