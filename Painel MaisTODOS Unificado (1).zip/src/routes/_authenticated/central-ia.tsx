import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BrainCircuit,
  Upload,
  FileText,
  RefreshCw,
  Trash2,
  Archive,
  CheckCircle2,
  BarChart3,
  ShieldAlert,
  Loader2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { indexDocument } from "@/lib/kb.functions";
import { ACCEPTED_EXT, extractText } from "@/lib/file-extract";
import { FontesConhecimento } from "@/components/FontesConhecimento";
import { ConsumoTokens } from "@/components/ConsumoTokens";
import { AcaoSensivel } from "@/components/AcaoSensivel";
import { EstadoVazio } from "@/components/EstadoVazio";
import { Carregando } from "@/components/Carregando";
import { AcessoRestrito } from "@/components/AcessoRestrito";
import { usePodeOperar } from "@/components/GuardaOperacional";

export const Route = createFileRoute("/_authenticated/central-ia")({
  component: CentralIA,
  head: () => ({
    meta: [
      { title: "Central de Conhecimento IA · MaisTODOS" },
      {
        name: "description",
        content:
          "Painel administrativo para treinar a MaisIA com documentos oficiais da MaisTODOS e acompanhar o uso do conhecimento.",
      },
      { property: "og:title", content: "Central de Conhecimento IA · MaisTODOS" },
      {
        property: "og:description",
        content: "Envie documentos oficiais, organize por categoria e treine a MaisIA.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const DOC_TYPES = [
  "procedimento",
  "artigo",
  "faq",
  "politica",
  "script",
  "macro",
  "fluxo",
  "arquivo",
] as const;

type DocType = (typeof DOC_TYPES)[number];

function CentralIA() {
  // Ler a Central é conteúdo, aberto a todos. Publicar, treinar, arquivar e
  // excluir é operação, restrita pelo módulo conhecimento_escrita.
  const { liberado: podeEscrever, loading: rolesLoading } = usePodeOperar("conhecimento_escrita");
  const qc = useQueryClient();
  const runIndex = useServerFn(indexDocument);

  const categories = useQuery({
    queryKey: ["kb-categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_categories")
        .select("id, name, slug")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const documents = useQuery({
    queryKey: ["kb-documents"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_documents")
        .select(
          "id, title, doc_type, status, version, tags, usage_count, indexed_at, updated_at, file_name, category_id",
        )
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const queries = useQuery({
    queryKey: ["ai-queries"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_queries")
        .select("id, question, found, created_at")
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return data;
    },
    enabled: podeEscrever,
  });

  const [aba, setAba] = useState("fontes");

  // Formulário
  const [title, setTitle] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [docType, setDocType] = useState<DocType>("procedimento");
  const [tags, setTags] = useState("");
  const [content, setContent] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const catName = (id: string | null) =>
    categories.data?.find((c) => c.id === id)?.name ?? "Sem categoria";

  const save = useMutation({
    mutationFn: async () => {
      if (!title.trim()) throw new Error("Informe um título.");
      let text = content;
      let filePath: string | null = null;
      let fileName: string | null = null;

      if (file) {
        setBusy("Extraindo texto do arquivo…");
        text = await extractText(file);
        if (!text.trim()) throw new Error("Não foi possível extrair texto deste arquivo.");
        setBusy("Enviando arquivo…");
        const path = `${crypto.randomUUID()}-${file.name}`;
        const { error: upErr } = await supabase.storage.from("kb-files").upload(path, file);
        if (upErr) throw new Error("Falha ao enviar o arquivo.");
        filePath = path;
        fileName = file.name;
      }

      if (!text.trim()) throw new Error("Envie um arquivo ou escreva o conteúdo.");

      setBusy("Salvando documento…");
      const { data: userData } = await supabase.auth.getUser();
      const { data: doc, error } = await supabase
        .from("kb_documents")
        .insert({
          title: title.trim(),
          content: text,
          doc_type: docType,
          category_id: categoryId || null,
          tags: tags
            .split(",")
            .map((t) => t.trim().toLowerCase())
            .filter(Boolean),
          file_path: filePath,
          file_name: fileName,
          author_id: userData.user?.id ?? null,
          author_name:
            (userData.user?.user_metadata?.["full_name"] as string) ?? userData.user?.email ?? null,
        })
        .select("id")
        .single();
      if (error) throw new Error("Falha ao salvar o documento.");

      setBusy("Treinando a IA (gerando embeddings)…");
      const res = await runIndex({ data: { documentId: doc.id } });
      return res;
    },
    onSuccess: (res) => {
      toast.success(`Documento treinado com sucesso (${res.chunks} trechos indexados).`);
      setTitle("");
      setContent("");
      setTags("");
      setFile(null);
      void qc.invalidateQueries({ queryKey: ["kb-documents"] });
    },
    onError: (e: Error) => toast.error(e.message),
    onSettled: () => setBusy(null),
  });

  const reindex = useMutation({
    mutationFn: (id: string) => runIndex({ data: { documentId: id } }),
    onSuccess: (res) => {
      toast.success(`Reindexado: ${res.chunks} trechos.`);
      void qc.invalidateQueries({ queryKey: ["kb-documents"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "ativo" | "arquivado" }) => {
      const { error } = await supabase.from("kb_documents").update({ status }).eq("id", id);
      if (error) throw new Error("Falha ao atualizar o status.");
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["kb-documents"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("kb_documents").delete().eq("id", id);
      if (error) throw new Error("Falha ao excluir o documento.");
    },
    onSuccess: () => {
      toast.success("Documento removido.");
      void qc.invalidateQueries({ queryKey: ["kb-documents"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (rolesLoading) {
    return (
      <AppLayout>
        <Carregando inline mensagem="Carregando permissões…" className="flex h-64 items-center justify-center gap-2 text-sm text-muted-foreground" />
      </AppLayout>
    );
  }

  const docs = documents.data ?? [];
  const qs = queries.data ?? [];
  const notFound = qs.filter((q) => !q.found);
  const topQuestions = Object.entries(
    qs.reduce<Record<string, number>>((acc, q) => {
      const k = q.question.trim().toLowerCase();
      acc[k] = (acc[k] ?? 0) + 1;
      return acc;
    }, {}),
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  return (
    <AppLayout>
      <div className="space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-3xl font-bold tracking-tight">
              <BrainCircuit className="h-7 w-7 text-primary" /> Central de Conhecimento IA
            </h1>
            <p className="mt-1 text-muted-foreground">
              Todo conteúdo enviado aqui é o único material que a MaisIA usa para responder.
            </p>
          </div>
          <Badge variant="secondary">
            {podeEscrever ? "Leitura aberta, escrita de administrador" : "Consulta"}
          </Badge>
        </header>

        <Tabs value={aba} onValueChange={setAba}>
          <TabsList>
            <TabsTrigger value="fontes">Fontes</TabsTrigger>
            {podeEscrever && <TabsTrigger value="enviar">Treinar a IA</TabsTrigger>}
            <TabsTrigger value="docs">Documentos ({docs.length})</TabsTrigger>
            {podeEscrever && <TabsTrigger value="analytics">Analytics</TabsTrigger>}
          </TabsList>

          <TabsContent value="fontes" className="mt-4">
            <FontesConhecimento
              totalDocumentos={docs.length}
              totalTreinados={docs.filter((d) => d.indexed_at).length}
              onTreinar={() => setAba("enviar")}
              podeOperar={podeEscrever}
            />
          </TabsContent>

          <TabsContent value="enviar" className="mt-4">
            {!podeEscrever ? (
              <AcessoRestrito mensagem="Publicar, editar e treinar a base de conhecimento é operação de administrador. A leitura dos documentos continua aberta para você." />
            ) : (
              <Card className="shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Upload className="h-5 w-5 text-primary" /> Novo conteúdo oficial
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="titulo">Título</Label>
                      <Input
                        id="titulo"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Ex.: Cancelamento de conta com débito"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="categoria">Categoria</Label>
                      <Select value={categoryId} onValueChange={setCategoryId}>
                        <SelectTrigger id="categoria">
                          <SelectValue placeholder="Selecione a categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {(categories.data ?? []).map((c) => (
                            <SelectItem key={c.id} value={c.id}>
                              {c.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tipo-conteudo">Tipo de conteúdo</Label>
                      <Select value={docType} onValueChange={(v) => setDocType(v as DocType)}>
                        <SelectTrigger id="tipo-conteudo">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {DOC_TYPES.map((t) => (
                            <SelectItem key={t} value={t}>
                              {t}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tags">Tags (separadas por vírgula)</Label>
                      <Input
                        id="tags"
                        value={tags}
                        onChange={(e) => setTags(e.target.value)}
                        placeholder="cancelamento, financeiro"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="arquivo">Arquivo ({ACCEPTED_EXT.join(", ")})</Label>
                    <Input
                      id="arquivo"
                      type="file"
                      accept={ACCEPTED_EXT.join(",")}
                      onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                    />
                    <p className="text-xs text-muted-foreground">
                      O texto é extraído do arquivo e transformado em conhecimento pesquisável.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="conteudo">Ou escreva o conteúdo</Label>
                    <Textarea
                      id="conteudo"
                      rows={8}
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Cole aqui o procedimento, política, script ou FAQ oficial…"
                    />
                  </div>

                  <Button
                    onClick={() => save.mutate()}
                    disabled={save.isPending}
                    className="bg-gradient-primary"
                  >
                    {save.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {busy ?? "Processando…"}
                      </>
                    ) : (
                      <>
                        <BrainCircuit className="mr-2 h-4 w-4" /> Salvar e treinar a IA
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="docs" className="mt-4 space-y-3">
            {docs.length === 0 && (
              <EstadoVazio
                titulo="Nenhum documento cadastrado ainda"
                descricao="Publique o primeiro procedimento oficial para a assistente poder consultar."
                icon={FileText}
              />
            )}
            {docs.map((d) => (
              <Card key={d.id} className="shadow-soft">
                <CardContent className="flex flex-wrap items-center gap-4 p-4">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="min-w-56 flex-1">
                    <div className="font-semibold">{d.title}</div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <Badge variant="secondary">{catName(d.category_id)}</Badge>
                      <Badge variant="outline">{d.doc_type}</Badge>
                      <span>v{d.version}</span>
                      <span>· {d.usage_count} usos</span>
                      <span>· atualizado {new Date(d.updated_at).toLocaleDateString("pt-BR")}</span>
                      {d.file_name && <span>· {d.file_name}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {d.indexed_at ? (
                      <Badge className="border-0 bg-lime/30 text-lime-foreground">
                        <CheckCircle2 className="mr-1 h-3 w-3" /> Treinado
                      </Badge>
                    ) : (
                      <Badge variant="destructive">Não treinado</Badge>
                    )}
                    <Badge variant={d.status === "ativo" ? "default" : "secondary"}>
                      {d.status}
                    </Badge>
                    {podeEscrever && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={reindex.isPending}
                        aria-label={`Treinar novamente o documento ${d.title}`}
                        onClick={() => reindex.mutate(d.id)}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    )}
                    {podeEscrever && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            toggleStatus.mutate({
                              id: d.id,
                              status: d.status === "ativo" ? "arquivado" : "ativo",
                            })
                          }
                          aria-label={
                            d.status === "ativo"
                              ? `Arquivar o documento ${d.title}`
                              : `Reativar o documento ${d.title}`
                          }
                        >
                          <Archive className="h-4 w-4" />
                        </Button>
                        <AcaoSensivel
                          modulo="Central de Conhecimento IA"
                          acao="Excluir documento da base"
                          alvo={d.title}
                          titulo="Excluir documento"
                          descricao="A exclusão é definitiva: o documento e seus trechos indexados saem da base de conhecimento."
                          rotuloConfirmar="Excluir documento"
                          destrutiva
                          observacaoObrigatoria
                          payload={{
                            documento_id: d.id,
                            titulo: d.title,
                            tipo: d.doc_type,
                            versao: d.version,
                            status: d.status,
                          }}
                          onConfirmar={() => remove.mutateAsync(d.id)}
                        >
                          <Button size="sm" variant="destructive" aria-label="Excluir documento">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AcaoSensivel>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="analytics" className="mt-4 space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Documentos", value: docs.length },
                { label: "Treinados", value: docs.filter((d) => d.indexed_at).length },
                { label: "Consultas à MaisIA", value: qs.length },
                { label: "Sem resposta oficial", value: notFound.length },
              ].map((k) => (
                <Card key={k.label} className="shadow-soft">
                  <CardContent className="p-5">
                    <div className="text-2xl font-bold">{k.value}</div>
                    <div className="text-xs text-muted-foreground">{k.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BarChart3 className="h-5 w-5 text-primary" /> Perguntas mais frequentes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {topQuestions.length === 0 && (
                    <EstadoVazio
                      titulo="Nenhuma consulta registrada"
                      descricao="As perguntas feitas à assistente aparecem aqui."
                      icon={BarChart3}
                    />
                  )}
                  {topQuestions.map(([q, n]) => (
                    <div key={q} className="flex items-center gap-3 rounded-lg bg-muted/60 p-3">
                      <span className="flex-1 text-sm">{q}</span>
                      <Badge variant="secondary">{n}x</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="shadow-soft">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <ShieldAlert className="h-5 w-5 text-primary" /> Lacunas de conhecimento
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {notFound.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      Toda pergunta encontrou conteúdo oficial.
                    </p>
                  )}
                  {notFound.slice(0, 10).map((q) => (
                    <div key={q.id} className="rounded-lg border border-border p-3 text-sm">
                      {q.question}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <ConsumoTokens />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
