import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea } from "@/data/operacao";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operacao/$area/comercial/")({
  component: Comercial,
  head: () => ({
    meta: [
      { title: "Time Comercial · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Time comercial organizado por área de negócio e regionais, com consultores responsáveis e contatos.",
      },
      { property: "og:title", content: "Time Comercial · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Odonto, Medicina e Novos Negócios: quem é o consultor de cada regional.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Comercial() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;

  return (
    <OperacaoShell
      area={area}
      crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Time Comercial" }]}
    >
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">👥 Time Comercial</h1>
          <p className="mt-1 text-muted-foreground">
            Organizado por área de negócio e, dentro dela, por regional.
          </p>
        </header>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {area.comercial.map((s) => (
            <Link
              key={s.slug}
              to="/operacao/$area/comercial/$segmento"
              params={{ area: area.slug, segmento: s.slug }}
              className="group"
            >
              <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-semibold">{s.nome}</h2>
                    <Badge variant="secondary">{s.regionais.length} regionais</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{s.descricao}</p>
                  <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                    Ver regionais{" "}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </OperacaoShell>
  );
}
