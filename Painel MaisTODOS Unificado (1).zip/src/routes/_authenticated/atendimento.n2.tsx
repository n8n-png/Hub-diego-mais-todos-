import { createFileRoute } from "@tanstack/react-router";
import { AtendimentoShell, AtendimentoEmConstrucao } from "@/components/AtendimentoShell";

export const Route = createFileRoute("/_authenticated/atendimento/n2")({
  component: PainelN2,
  head: () => ({
    meta: [
      { title: "Painel N2 · Atendimento MaisTODOS" },
      {
        name: "description",
        content:
          "Ações restritas de engenharia do Atendimento nível 2, com dupla checagem, confirmação humana e trilha de auditoria.",
      },
      { property: "og:title", content: "Painel N2 · Atendimento MaisTODOS" },
      {
        property: "og:description",
        content: "Ações restritas de engenharia do Atendimento nível 2 da MaisTODOS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Painel N2 · Atendimento MaisTODOS" },
      {
        name: "twitter:description",
        content: "Ações restritas de engenharia do Atendimento nível 2 da MaisTODOS.",
      },
    ],
  }),
});

function PainelN2() {
  return (
    <AtendimentoShell
      modulo="atendimento_n2"
      titulo="Painel N2"
      descricao="Ações restritas de engenharia, disponíveis somente para o Atendimento nível 2 e administradores."
    >
      <AtendimentoEmConstrucao
        modulo="Painel N2"
        proximoPasso="A próxima onda traz reprocessamentos, correções de cadastro e ferramentas de diagnóstico, todas com dupla checagem."
      />
    </AtendimentoShell>
  );
}
