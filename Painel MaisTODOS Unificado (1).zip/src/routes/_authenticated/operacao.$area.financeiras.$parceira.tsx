import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getArea, type SlackChannel } from "@/data/operacao";
import {
  ArrowLeft,
  Copy,
  Check,
  Hash,
  Clock,
  FileText,
  History,
  MessageSquare,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/operacao/$area/financeiras/$parceira")({
  component: FinanceiraDetalhe,
  head: () => ({
    meta: [
      { title: "Financeira parceira · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Visão geral, processo, fluxograma, scripts, prazos, canais de acionamento e documentação da financeira.",
      },
      { property: "og:title", content: "Financeira parceira · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Tudo sobre a financeira parceira em uma estrutura única e padronizada.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const toneClass = (t?: string) => {
  switch (t) {
    case "start":
      return "bg-lime text-lime-foreground";
    case "decision":
      return "bg-primary text-primary-foreground";
    case "end":
      return "bg-gradient-primary text-primary-foreground";
    default:
      return "bg-card border border-border";
  }
};

function SlackCard({ canal }: { canal: SlackChannel }) {
  const [copied, setCopied] = useState(false);
  const copiar = () => {
    navigator.clipboard.writeText(canal.modeloMensagem);
    setCopied(true);
    toast.success("Modelo de mensagem copiado!");
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Card className="shadow-soft">
      <CardContent className="space-y-5 p-6">
        <div className="flex flex-wrap items-center gap-2">
          <Hash className="h-4 w-4 text-primary" />
          <h3 className="font-semibold">{canal.nomeGrupo}</h3>
          <Badge variant="secondary">Slack</Badge>
        </div>

        <Field titulo="Objetivo do grupo" texto={canal.objetivo} />
        <Field titulo="Quando utilizar" texto={canal.quandoUtilizar} />

        <div className="grid gap-5 md:grid-cols-2">
          <ListField titulo="Tipos de demanda" itens={canal.tiposDemanda} />
          <ListField titulo="Quem marcar" itens={canal.quemMarcar} />
        </div>

        <ListField
          titulo="Informações obrigatórias antes do acionamento"
          itens={canal.informacoesObrigatorias}
        />

        <div>
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Modelo de mensagem
            </h4>
            <Button size="sm" variant="outline" onClick={copiar}>
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              <span className="ml-2">{copied ? "Copiado" : "Copiar"}</span>
            </Button>
          </div>
          <pre className="whitespace-pre-wrap rounded-xl bg-muted/60 p-4 text-sm leading-relaxed text-foreground/90">
            {canal.modeloMensagem}
          </pre>
        </div>
      </CardContent>
    </Card>
  );
}

function Field({ titulo, texto }: { titulo: string; texto: string }) {
  return (
    <div>
      <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        {titulo}
      </h4>
      <p className="mt-1 text-sm text-foreground/90">{texto}</p>
    </div>
  );
}

function ListField({ titulo, itens }: { titulo: string; itens: string[] }) {
  return (
    <div>
      <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        {titulo}
      </h4>
      <ul className="mt-2 space-y-1 text-sm text-foreground/90">
        {itens.map((i) => (
          <li key={i} className="flex gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
            {i}
          </li>
        ))}
      </ul>
    </div>
  );
}

function FinanceiraDetalhe() {
  const { area: slug, parceira } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  const f = area.financeiras.find((x) => x.slug === parceira);

  if (!f) {
    return (
      <OperacaoShell
        area={area}
        crumbs={[
          { label: area.nome, to: `/operacao/${area.slug}` },
          { label: "Financeiras Parceiras" },
        ]}
      >
        <Card className="border-dashed">
          <CardContent className="p-10 text-center">
            <p className="text-sm text-muted-foreground">Financeira não encontrada.</p>
            <Button asChild className="mt-4" variant="outline">
              <Link to="/operacao/$area/financeiras" params={{ area: area.slug }}>
                Voltar
              </Link>
            </Button>
          </CardContent>
        </Card>
      </OperacaoShell>
    );
  }

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Financeiras Parceiras", to: `/operacao/${area.slug}/financeiras` },
        { label: f.nome },
      ]}
    >
      <div className="space-y-6">
        <Link
          to="/operacao/$area/financeiras"
          params={{ area: area.slug }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Todas as financeiras
        </Link>

        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{f.nome}</h1>
          <p className="mt-1 text-muted-foreground">{f.resumo}</p>
        </header>

        <Tabs defaultValue="visao" className="w-full">
          <div className="overflow-x-auto pb-1">
            <TabsList className="w-max">
              <TabsTrigger value="visao">Visão Geral</TabsTrigger>
              <TabsTrigger value="processo">Processo</TabsTrigger>
              <TabsTrigger value="fluxograma">Fluxograma</TabsTrigger>
              <TabsTrigger value="scripts">Scripts</TabsTrigger>
              <TabsTrigger value="prazos">Prazos</TabsTrigger>
              <TabsTrigger value="canais">Canais de Acionamento</TabsTrigger>
              <TabsTrigger value="documentacao">Documentação</TabsTrigger>
              <TabsTrigger value="historico">Histórico</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="visao" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="grid gap-5 p-6 md:grid-cols-2">
                <Field titulo="Produto" texto={f.visaoGeral.produto} />
                <Field titulo="Público" texto={f.visaoGeral.publico} />
                <Field titulo="Horário de atendimento" texto={f.visaoGeral.horario} />
                <Field titulo="SLA" texto={f.visaoGeral.sla} />
                <div className="md:col-span-2">
                  <ListField titulo="Observações" itens={f.visaoGeral.observacoes} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="processo" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="p-6">
                <ol className="space-y-4">
                  {f.processo.map((p) => (
                    <li key={p.passo} className="flex gap-3 border-l-2 border-primary/30 pl-4">
                      <div>
                        <div className="font-semibold">{p.passo}</div>
                        <p className="text-sm text-muted-foreground">{p.detalhe}</p>
                      </div>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="fluxograma" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="p-8">
                <div className="mx-auto flex max-w-2xl flex-col items-center gap-3">
                  {f.fluxograma.map((row, i) => (
                    <div key={i} className="flex w-full flex-col items-center gap-3">
                      <div className="flex w-full flex-wrap justify-center gap-4">
                        {row.map((n) => (
                          <div
                            key={n.label}
                            className={`min-w-[170px] rounded-xl px-5 py-3 text-center text-sm font-semibold shadow-soft ${toneClass(n.tone)}`}
                          >
                            {n.label}
                          </div>
                        ))}
                      </div>
                      {i < f.fluxograma.length - 1 && (
                        <div className="h-6 w-0.5 bg-gradient-to-b from-primary to-lime" />
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="scripts" className="mt-4">
            <div className="grid gap-4 lg:grid-cols-2">
              {f.scripts.map((s) => (
                <ScriptCard key={s.titulo} titulo={s.titulo} tag={s.tag} texto={s.texto} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="prazos" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="p-6">
                <ul className="divide-y divide-border">
                  {f.prazos.map((p) => (
                    <li key={p.item} className="flex items-center justify-between gap-3 py-3">
                      <span className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-primary" />
                        {p.item}
                      </span>
                      <Badge className="bg-accent text-accent-foreground">{p.prazo}</Badge>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="canais" className="mt-4 space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MessageSquare className="h-4 w-4 text-primary" />
              Canal oficial de acionamento. Novos canais podem ser adicionados no futuro.
            </div>
            {f.canais.map((c) => (
              <SlackCard key={c.slack.nomeGrupo} canal={c.slack} />
            ))}
          </TabsContent>

          <TabsContent value="documentacao" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="p-6">
                <ul className="divide-y divide-border">
                  {f.documentacao.map((d) => (
                    <li key={d.titulo} className="flex items-start justify-between gap-3 py-3">
                      <div className="flex gap-3">
                        <FileText className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                        <div>
                          <div className="text-sm font-medium">{d.titulo}</div>
                          <p className="text-sm text-muted-foreground">{d.descricao}</p>
                        </div>
                      </div>
                      <Badge variant="outline">{d.tipo}</Badge>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="historico" className="mt-4">
            <Card className="shadow-soft">
              <CardContent className="p-6">
                <ol className="space-y-4">
                  {f.historico.map((h) => (
                    <li key={h.data} className="flex gap-3">
                      <History className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(h.data).toLocaleDateString("pt-BR")}
                        </div>
                        <div className="text-sm font-medium">{h.titulo}</div>
                        <p className="text-sm text-muted-foreground">{h.descricao}</p>
                      </div>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </OperacaoShell>
  );
}

function ScriptCard({ titulo, tag, texto }: { titulo: string; tag: string; texto: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Card className="shadow-soft">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <Badge variant="secondary" className="mb-2">
              {tag}
            </Badge>
            <h3 className="font-semibold">{titulo}</h3>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              navigator.clipboard.writeText(texto);
              setCopied(true);
              toast.success("Script copiado!");
              setTimeout(() => setCopied(false), 1500);
            }}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
        <p className="mt-3 rounded-lg bg-muted/60 p-4 text-sm leading-relaxed text-foreground/90">
          "{texto}"
        </p>
      </CardContent>
    </Card>
  );
}
