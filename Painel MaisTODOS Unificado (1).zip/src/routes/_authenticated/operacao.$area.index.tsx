import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getArea, areaSections, gruposSecao, type SecaoGrupo } from "@/data/operacao";
import { ArrowRight, Lock } from "lucide-react";
import { atendimentoModulos } from "@/data/atendimento-modulos";
import { useAreaAccess } from "@/hooks/use-area-access";
import { useRoles } from "@/hooks/use-roles";
import { podeOperar, type ModuloOperacional } from "@/data/permissoes";
import { Carregando } from "@/components/Carregando";

export const Route = createFileRoute("/_authenticated/operacao/$area/")({
  component: AreaHome,
  head: () => ({
    meta: [
      { title: "Área da Operação · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Visão geral da área operacional: ferramentas, financeiras parceiras, fluxo, time comercial, materiais e comunicados.",
      },
      { property: "og:title", content: "Área da Operação · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Tudo o que a operação precisa, organizado por área de atendimento.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function AreaHome() {
  const { area: slug } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  if (area.slug === "app") return <AppAtendimento />;

  const counts: Record<string, string> = {
    ferramentas: `${area.ferramentas.length} ferramentas`,
    financeiras: `${area.financeiras.length} parceiras`,
    fluxo: `${area.fluxoOperacao?.etapas.length ?? 0} etapas`,
    comercial: `${area.comercial.length} segmentos`,
    materiais: `${area.materiais.length} documentos`,
    comunicados: `${area.comunicados.length} publicações`,
    processos: "processos e playbooks",
    fluxos: "fluxos mapeados",
    onboarding: "10 etapas mapeadas",
    reprovacoes: "códigos e glossário",
  };

  const secoes = area.secoes ?? areaSections;

  return (
    <OperacaoShell area={area} crumbs={[{ label: area.nome }]}>
      <div className="space-y-8">
        <header>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{area.nome}</h1>
          <p className="mt-1 text-muted-foreground">{area.descricao}</p>
        </header>

        {(["rotinas", "guia"] as SecaoGrupo[]).map((grupo) => {
          const doGrupo = secoes.filter((s) => s.grupo === grupo);
          const info = gruposSecao[grupo];
          if (doGrupo.length === 0) return null;
          return (
            <section key={grupo} className="space-y-3">
              <div>
                <h2 className="text-lg font-semibold">{info.nome}</h2>
                <p className="text-sm text-muted-foreground">{info.descricao}</p>
              </div>

              {
                <div className="grid gap-4 sm:grid-cols-2">
                  {doGrupo.map((s) => (
                    <Link
                      key={s.slug}
                      to={`/operacao/$area/${s.slug}` as "/operacao/$area/materiais"}
                      params={{ area: area.slug }}
                      className="group"
                    >
                      <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                        <CardContent className="p-5">
                          <div className="flex items-center justify-between">
                            <span className="text-2xl">{s.emoji}</span>
                            {counts[s.slug] && <Badge variant="secondary">{counts[s.slug]}</Badge>}
                          </div>
                          <h3 className="mt-3 font-semibold">{s.nome}</h3>
                          <div className="mt-2 flex items-center gap-1 text-sm font-medium text-primary">
                            Abrir{" "}
                            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              }
            </section>
          );
        })}
      </div>
    </OperacaoShell>
  );
}

/**
 * Operação · App: casa dos módulos de Atendimento.
 * O guia da área é conteúdo, aberto a qualquer pessoa autenticada.
 * Os módulos de Atendimento são operação: aparecem conforme o papel, lido de
 * src/data/permissoes.ts, e a rota de cada um tem guarda própria.
 */
function AppAtendimento() {
  const area = getArea("app")!;
  const { roles, loading } = useRoles();
  const { areas } = useAreaAccess();
  const opera = (modulo: ModuloOperacional) => podeOperar(modulo, roles, areas);
  const modulosLiberados = atendimentoModulos.filter((m) => opera(m.modulo));

  return (
    <OperacaoShell area={area} crumbs={[{ label: area.nome }]}>
      {loading ? (
        <Carregando mensagem="Carregando a área…" blocos={2} />
      ) : (
        <div className="space-y-8">
          <header>
            <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{area.nome}</h1>
            <p className="mt-1 text-muted-foreground">{area.descricao}</p>
          </header>

          <section className="space-y-3">
            <div>
              <h2 className="text-lg font-semibold">{gruposSecao.rotinas.nome}</h2>
              <p className="text-sm text-muted-foreground">{gruposSecao.rotinas.descricao}</p>
            </div>

            {modulosLiberados.length === 0 ? (
              <Card className="border-dashed shadow-soft">
                <CardContent className="flex flex-col items-center p-8 text-center">
                  <Lock className="h-8 w-8 text-primary" />
                  <h3 className="mt-3 font-semibold">Rotinas restritas ao Atendimento</h3>
                  <p className="mt-1 max-w-md text-sm text-muted-foreground">
                    Executar rotinas do App depende do papel de Atendimento. Todo o material de
                    estudo desta área continua aberto para você, nas seções abaixo.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {modulosLiberados.map((m) => {
                  const Icon = m.icon;
                  return (
                    <Link key={m.to} to={m.to} className="group">
                      <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                        <CardContent className="p-5">
                          <div className="flex items-center justify-between">
                            <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent">
                              <Icon className="h-5 w-5 text-primary" />
                            </span>
                            {m.modulo === "atendimento_n2" && (
                              <Badge variant="secondary">Nível 2</Badge>
                            )}
                          </div>
                          <h3 className="mt-3 font-semibold">{m.nome}</h3>
                          <p className="mt-1 text-sm text-muted-foreground">{m.descricao}</p>
                          <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                            Abrir{" "}
                            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            )}

            <p className="text-xs text-muted-foreground">
              Dados dos módulos ainda são fictícios. As integrações reais são Fase 2, sempre via
              proxy server-side, com CPF, e-mail e telefone mascarados, conforme LGPD.
            </p>
          </section>

          <section className="space-y-3">
            <div>
              <h2 className="text-lg font-semibold">{gruposSecao.guia.nome}</h2>
              <p className="text-sm text-muted-foreground">{gruposSecao.guia.descricao}</p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {(area.secoes ?? [])
                .filter((s) => s.grupo === "guia")
                .map((s) => (
                  <Link
                    key={s.slug}
                    to={`/operacao/$area/${s.slug}` as "/operacao/$area/materiais"}
                    params={{ area: area.slug }}
                    className="group"
                  >
                    <Card className="h-full shadow-soft transition-all group-hover:-translate-y-0.5 group-hover:shadow-glow">
                      <CardContent className="p-5">
                        <span className="text-2xl">{s.emoji}</span>
                        <h3 className="mt-3 font-semibold">{s.nome}</h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Conteúdo didático da operação do App. Assim que o material for enviado,
                          ele aparece organizado em cards aqui.
                        </p>
                        <div className="mt-3 flex items-center gap-1 text-sm font-medium text-primary">
                          Abrir{" "}
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
            </div>
          </section>
        </div>
      )}
    </OperacaoShell>
  );
}
