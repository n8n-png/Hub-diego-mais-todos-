import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { PlayCircle, Clock, User, Award } from "lucide-react";

export const Route = createFileRoute("/_authenticated/universidade")({
  component: Universidade,
  head: () => ({ meta: [{ title: "Universidade · MaisTODOS" }] }),
});

const categorias = [
  "Todos",
  "Atendimento",
  "Cancelamentos",
  "Financeiro",
  "Produtos",
  "Sistema Interno",
  "Boas Práticas",
];

const cursos = [
  {
    titulo: "Atendimento humanizado",
    cat: "Atendimento",
    prof: "Ana Ribeiro",
    tempo: "2h 30min",
    progresso: 80,
  },
  {
    titulo: "Cancelamento com débito",
    cat: "Cancelamentos",
    prof: "Bruno Costa",
    tempo: "1h 15min",
    progresso: 40,
  },
  {
    titulo: "Antecipação de recebíveis",
    cat: "Financeiro",
    prof: "Camila Souza",
    tempo: "3h",
    progresso: 0,
  },
  {
    titulo: "Maquininhas · setup",
    cat: "Produtos",
    prof: "Diego Lima",
    tempo: "45min",
    progresso: 100,
  },
  {
    titulo: "Sistema Interno Vol.1",
    cat: "Sistema Interno",
    prof: "Eduardo Reis",
    tempo: "4h",
    progresso: 60,
  },
  {
    titulo: "Boas práticas de conformidade",
    cat: "Boas Práticas",
    prof: "Fernanda Alves",
    tempo: "1h",
    progresso: 20,
  },
];

function Universidade() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Universidade MaisTODOS</h1>
          <p className="mt-1 text-muted-foreground">
            Aprenda todos os processos da empresa em trilhas estruturadas.
          </p>
        </header>

        <div className="flex flex-wrap gap-2">
          {categorias.map((c, i) => (
            <Badge
              key={c}
              variant={i === 0 ? "default" : "secondary"}
              className={
                i === 0
                  ? "bg-primary text-primary-foreground cursor-pointer"
                  : "cursor-pointer hover:bg-accent"
              }
            >
              {c}
            </Badge>
          ))}
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {cursos.map((c) => (
            <Card
              key={c.titulo}
              className="group overflow-hidden shadow-soft transition-all hover:-translate-y-1 hover:shadow-glow"
            >
              <div className="relative h-32 bg-gradient-hero">
                <div className="absolute inset-0 grid place-items-center">
                  <PlayCircle className="h-12 w-12 text-white/90" />
                </div>
                {c.progresso === 100 && (
                  <Badge className="absolute right-3 top-3 bg-lime text-lime-foreground border-0">
                    <Award className="mr-1 h-3 w-3" /> Concluído
                  </Badge>
                )}
              </div>
              <CardContent className="space-y-3 p-5">
                <Badge variant="secondary">{c.cat}</Badge>
                <h3 className="font-semibold leading-tight">{c.titulo}</h3>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3" /> {c.prof}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {c.tempo}
                  </span>
                </div>
                <Progress value={c.progresso} className="h-1.5" />
                <Button className="w-full" variant={c.progresso === 0 ? "default" : "secondary"}>
                  {c.progresso === 0 ? "Começar" : c.progresso === 100 ? "Revisar" : "Continuar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
