import { createFileRoute, Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Sparkles, ArrowRight, BookOpen, Workflow, ScrollText, Search } from "lucide-react";
import { useProfile } from "@/hooks/use-profile";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
  head: () => ({ meta: [{ title: "Dashboard · Hub MaisTODOS" }] }),
});

const cursos = [
  { titulo: "Cancelamento de contas", categoria: "Atendimento", progresso: 80 },
  { titulo: "Antecipação de recebíveis", categoria: "Financeiro", progresso: 45 },
  { titulo: "Sistema Interno · Módulo 2", categoria: "Sistema", progresso: 22 },
];

const processos = [
  "Emissão de 2ª via de boleto",
  "Cancelamento com débito em aberto",
  "Reset de senha do portal",
];

const sugestoes = [
  "Você acessou 'Cancelamento' 3x. Quer revisar o fluxograma?",
  "Novo artigo disponível: 'PIX · Contestações'.",
  "Faltam 2 aulas para concluir 'Boas Práticas'.",
];

const atalhos = [
  { to: "/processos", label: "Processos", icon: Workflow },
  { to: "/base", label: "Base", icon: BookOpen },
  { to: "/scripts", label: "Scripts", icon: ScrollText },
  { to: "/fluxogramas", label: "Fluxogramas", icon: Sparkles },
];

function Dashboard() {
  const { profile, user, loading } = useProfile();
  const nomeCompleto = profile?.full_name?.trim() || user?.email?.split("@")[0] || "";
  const primeiroNome = nomeCompleto ? nomeCompleto.split(/\s+/)[0] : "";
  const saudacao = loading ? "Olá" : primeiroNome ? `Olá, ${primeiroNome}` : "Olá";

  return (
    <AppLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-hero p-8 text-primary-foreground shadow-glow">
          <div className="absolute inset-0 bg-gradient-primary opacity-30" aria-hidden="true" />
          <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <Badge
                variant="outline"
                className="mb-3 border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground"
              >
                {saudacao}
              </Badge>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
                Bem-vindo ao Hub de conhecimento
              </h1>
              <p className="mt-3 max-w-xl text-lg font-medium text-primary-foreground">
                Todo o conhecimento de CX em um só lugar.
              </p>
              <p className="mt-1 max-w-xl text-primary-foreground/80">
                Processos, informações e orientações para facilitar o seu dia a dia.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Button
                  asChild
                  size="lg"
                  variant="secondary"
                  className="border-0 bg-primary-foreground/10 text-primary-foreground backdrop-blur hover:bg-primary-foreground/20"
                >
                  <Link to="/base">
                    <Search className="mr-2 h-4 w-4" />
                    Pesquisar procedimento
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Atalhos */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {atalhos.map((a) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.to}
                to={a.to}
                className="group flex items-center justify-between rounded-2xl border border-border bg-card p-4 shadow-soft transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-glow"
              >
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="font-medium">{a.label}</span>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
              </Link>
            );
          })}
        </section>

        {/* Grid */}
        <section className="grid gap-6 lg:grid-cols-3">
          <Card className="shadow-soft lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Últimos cursos</CardTitle>
                <p className="mt-1 text-xs text-muted-foreground">Exemplos de vitrine</p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/universidade">
                  Ver todos <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {cursos.map((c) => (
                <div key={c.titulo} className="rounded-xl border border-border p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{c.titulo}</div>
                      <Badge variant="secondary" className="mt-1">
                        {c.categoria}
                      </Badge>
                    </div>
                    <span className="text-sm font-medium text-primary">{c.progresso}%</span>
                  </div>
                  <Progress value={c.progresso} className="mt-3 h-1.5" />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="shadow-soft bg-gradient-to-br from-primary to-primary-glow text-primary-foreground border-0">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
                <div>
                  <CardTitle className="text-lg text-primary-foreground">
                    Sugestões do Assistente
                  </CardTitle>
                  <p className="mt-1 text-xs text-primary-foreground/80">Exemplos de vitrine</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {sugestoes.map((s, i) => (
                <div key={i} className="rounded-lg bg-primary-foreground/10 p-3 text-sm backdrop-blur">
                  {s}
                </div>
              ))}
              <Button asChild className="w-full bg-primary-foreground text-primary hover:bg-primary-foreground/90">
                <Link to="/base">Abrir a base de conhecimento</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-soft lg:col-span-3">
            <CardHeader>
              <CardTitle className="text-lg">Últimos processos acessados</CardTitle>
              <p className="mt-1 text-xs text-muted-foreground">Exemplos de vitrine</p>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-3">
              {processos.map((p) => (
                <Link
                  key={p}
                  to="/processos"
                  className="flex items-center justify-between rounded-xl bg-muted/60 p-4 text-sm font-medium hover:bg-accent"
                >
                  <span>{p}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                </Link>
              ))}
            </CardContent>
          </Card>
        </section>
      </div>
    </AppLayout>
  );
}
