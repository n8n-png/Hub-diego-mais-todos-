import { createFileRoute, Link } from "@tanstack/react-router";
import { OperacaoShell } from "@/components/OperacaoShell";
import { AreaIndisponivel } from "@/components/OperacaoEmpty";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getArea } from "@/data/operacao";
import { ArrowLeft, Mail, Phone, Hash, MapPin } from "lucide-react";

export const Route = createFileRoute(
  "/_authenticated/operacao/$area/comercial/$segmento/$regional",
)({
  component: RegionalDetalhe,
  head: () => ({
    meta: [
      { title: "Consultor da regional · Hub MaisTODOS" },
      {
        name: "description",
        content:
          "Consultor responsável pela regional, contatos e informações relevantes de atendimento.",
      },
      { property: "og:title", content: "Consultor da regional · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Quem acionar em cada regional comercial e por qual canal.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function RegionalDetalhe() {
  const { area: slug, segmento, regional } = Route.useParams();
  const area = getArea(slug);
  if (!area?.disponivel) return <AreaIndisponivel slug={slug} />;
  const seg = area.comercial.find((s) => s.slug === segmento);
  const reg = seg?.regionais.find((r) => r.slug === regional);

  if (!seg || !reg) {
    return (
      <OperacaoShell
        area={area}
        crumbs={[{ label: area.nome, to: `/operacao/${area.slug}` }, { label: "Time Comercial" }]}
      >
        <Card className="border-dashed">
          <CardContent className="p-10 text-center">
            <p className="text-sm text-muted-foreground">Regional não encontrada.</p>
            <Button asChild className="mt-4" variant="outline">
              <Link to="/operacao/$area/comercial" params={{ area: area.slug }}>
                Voltar
              </Link>
            </Button>
          </CardContent>
        </Card>
      </OperacaoShell>
    );
  }

  return (
    <OperacaoShell
      area={area}
      crumbs={[
        { label: area.nome, to: `/operacao/${area.slug}` },
        { label: "Time Comercial", to: `/operacao/${area.slug}/comercial` },
        { label: seg.nome, to: `/operacao/${area.slug}/comercial/${seg.slug}` },
        { label: reg.nome },
      ]}
    >
      <div className="space-y-6">
        <Link
          to="/operacao/$area/comercial/$segmento"
          params={{ area: area.slug, segmento: seg.slug }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Regionais de {seg.nome}
        </Link>

        <Card className="overflow-hidden shadow-soft">
          <div className="bg-gradient-primary p-6 text-primary-foreground">
            <Badge className="mb-2 bg-lime text-lime-foreground">
              {seg.nome} · {reg.nome}
            </Badge>
            <h1 className="text-2xl font-bold">{reg.consultor}</h1>
            <p className="text-sm opacity-90">{reg.cargo}</p>
          </div>
          <CardContent className="grid gap-4 p-6 md:grid-cols-2">
            <a
              href={`tel:${reg.telefone.replace(/\D/g, "")}`}
              className="flex items-center gap-3 rounded-xl bg-muted/60 p-4 text-sm transition-colors hover:bg-muted"
            >
              <Phone className="h-4 w-4 text-primary" /> {reg.telefone}
            </a>
            {reg.email && (
              <a
                href={`mailto:${reg.email}`}
                className="flex items-center gap-3 rounded-xl bg-muted/60 p-4 text-sm transition-colors hover:bg-muted"
              >
                <Mail className="h-4 w-4 text-primary" /> {reg.email}
              </a>
            )}
            {reg.slack && (
              <div className="flex items-center gap-3 rounded-xl bg-muted/60 p-4 text-sm">
                <Hash className="h-4 w-4 text-primary" /> {reg.slack}
              </div>
            )}
            <div className="flex items-start gap-3 rounded-xl bg-muted/60 p-4 text-sm">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span>{reg.estados.join(" · ")}</span>
            </div>
          </CardContent>
        </Card>

        {seg.coordenador && (
          <Card className="shadow-soft">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-6">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                  {seg.coordenador.cargo} · {seg.nome}
                </div>
                <div className="mt-1 font-semibold">{seg.coordenador.nome}</div>
              </div>
              <a
                href={`tel:${seg.coordenador.telefone.replace(/\D/g, "")}`}
                className="inline-flex items-center gap-2 rounded-xl bg-muted/60 px-4 py-2 text-sm transition-colors hover:bg-muted"
              >
                <Phone className="h-4 w-4 text-primary" /> {seg.coordenador.telefone}
              </a>
            </CardContent>
          </Card>
        )}
      </div>
    </OperacaoShell>
  );
}
