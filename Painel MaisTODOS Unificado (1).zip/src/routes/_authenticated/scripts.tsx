import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/scripts")({
  component: Scripts,
  head: () => ({ meta: [{ title: "Scripts · MaisTODOS" }] }),
});

const scripts = [
  {
    titulo: "Cliente bravo",
    tag: "Atendimento",
    texto:
      "Compreendo perfeitamente sua situação e peço desculpas pelo transtorno. Vou verificar agora mesmo o que aconteceu e resolver da melhor forma possível.",
  },
  {
    titulo: "Cliente quer cancelar",
    tag: "Cancelamento",
    texto:
      "Entendi. Antes de prosseguir com o cancelamento, gostaria de entender o motivo para ver se conseguimos alguma alternativa que atenda melhor sua necessidade.",
  },
  {
    titulo: "Cliente quer desconto",
    tag: "Retenção",
    texto:
      "Vou verificar nossas condições especiais disponíveis para o seu perfil. Um momento, por favor.",
  },
  {
    titulo: "Cliente quer 2ª via",
    tag: "Financeiro",
    texto:
      "Sem problemas! Vou gerar agora a segunda via do boleto e enviar para o e-mail cadastrado. Confirma para mim se o e-mail X está correto?",
  },
  {
    titulo: "Cliente esqueceu senha",
    tag: "Acesso",
    texto:
      "Tranquilo, vou te ajudar a redefinir. Por segurança, vou fazer algumas perguntas de validação de identidade.",
  },
];

function Scripts() {
  const [copied, setCopied] = useState<string | null>(null);
  const copy = (titulo: string, texto: string) => {
    navigator.clipboard.writeText(texto);
    setCopied(titulo);
    toast.success("Script copiado!");
    setTimeout(() => setCopied(null), 1500);
  };
  return (
    <AppLayout>
      <div className="space-y-6">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Biblioteca de Scripts</h1>
          <p className="mt-1 text-muted-foreground">
            Frases prontas para diferentes cenários de atendimento.
          </p>
        </header>
        <div className="grid gap-4 lg:grid-cols-2">
          {scripts.map((s) => (
            <Card key={s.titulo} className="shadow-soft">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <Badge variant="secondary" className="mb-2">
                      {s.tag}
                    </Badge>
                    <h3 className="font-semibold">{s.titulo}</h3>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => copy(s.titulo, s.texto)}>
                    {copied === s.titulo ? (
                      <Check className="h-4 w-4 text-lime-foreground" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                    <span className="ml-2">{copied === s.titulo ? "Copiado" : "Copiar"}</span>
                  </Button>
                </div>
                <p className="mt-3 rounded-lg bg-muted/60 p-4 text-sm leading-relaxed text-foreground/90">
                  "{s.texto}"
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
