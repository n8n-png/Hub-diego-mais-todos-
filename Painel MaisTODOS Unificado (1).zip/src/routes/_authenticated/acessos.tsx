import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { RefreshCw, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { GuardaOperacional } from "@/components/GuardaOperacional";
import { MatrizPermissoes } from "@/components/MatrizPermissoes";
import { OrigemAcesso } from "@/components/OrigemAcesso";
import { AcaoSensivel } from "@/components/AcaoSensivel";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Carregando } from "@/components/Carregando";
import { EstadoVazio } from "@/components/EstadoVazio";
import { supabase } from "@/integrations/supabase/client";
import { areasOperacaoAcesso, rotulosAreaAcesso, type AreaAcesso } from "@/data/areas-acesso";
import {
  concederArea,
  concederPapel,
  listarUsuariosAcesso,
  removerArea,
  removerPapel,
} from "@/lib/acessos.functions";

export const Route = createFileRoute("/_authenticated/acessos")({
  component: Acessos,
  head: () => ({
    meta: [
      { title: "Gestão de acessos · MaisTODOS" },
      {
        name: "description",
        content:
          "Ferramenta de administração para liberar módulos da Operação e o acesso de administrador no Hub MaisTODOS.",
      },
      { property: "og:title", content: "Gestão de acessos · MaisTODOS" },
      {
        property: "og:description",
        content: "Libere módulos da Operação por pessoa no Hub MaisTODOS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Gestão de acessos · MaisTODOS" },
      {
        name: "twitter:description",
        content: "Libere módulos da Operação por pessoa no Hub MaisTODOS.",
      },
    ],
  }),
});

/**
 * A trava desta tela usa o guarda único e a fonte de verdade em
 * src/data/permissoes.ts, módulo "acessos". Nenhuma regra de papel escrita
 * direto na rota. A trava que protege de verdade continua no servidor.
 */
function Acessos() {
  return (
    <AppLayout>
      <GuardaOperacional modulo="acessos">
        <PainelAcessos />
      </GuardaOperacional>
    </AppLayout>
  );
}

function PainelAcessos() {
  const qc = useQueryClient();
  const carregar = useServerFn(listarUsuariosAcesso);
  const conceder = useServerFn(concederPapel);
  const remover = useServerFn(removerPapel);
  const liberarArea = useServerFn(concederArea);
  const retirarArea = useServerFn(removerArea);

  const eu = useQuery({
    queryKey: ["meu-uid"],
    queryFn: async () => (await supabase.auth.getUser()).data.user?.id ?? null,
    staleTime: 300_000,
  });

  const usuarios = useQuery({
    queryKey: ["acessos-usuarios"],
    queryFn: () => carregar({ data: undefined }),
  });

  function recarregar() {
    void qc.invalidateQueries({ queryKey: ["acessos-usuarios"] });
    void qc.invalidateQueries({ queryKey: ["user-roles"] });
    void qc.invalidateQueries({ queryKey: ["user-area-access"] });
  }

  const alterarAdmin = useMutation({
    mutationFn: async (v: { userId: string; conceder: boolean }) => {
      if (v.conceder) await conceder({ data: { userId: v.userId, papel: "admin" } });
      else await remover({ data: { userId: v.userId, papel: "admin" } });
      return v;
    },
    onSuccess: (v) => {
      toast.success(
        v.conceder ? "Acesso de administrador concedido." : "Acesso de administrador removido.",
      );
      recarregar();
    },
    onError: (e) => toast.error((e as Error).message),
  });

  const alterarArea = useMutation({
    mutationFn: async (v: { userId: string; areaSlug: AreaAcesso; conceder: boolean }) => {
      if (v.conceder) await liberarArea({ data: { userId: v.userId, areaSlug: v.areaSlug } });
      else await retirarArea({ data: { userId: v.userId, areaSlug: v.areaSlug } });
      return v;
    },
    onSuccess: (v) => {
      toast.success(
        v.conceder
          ? `Módulo ${rotulosAreaAcesso[v.areaSlug]} liberado.`
          : `Módulo ${rotulosAreaAcesso[v.areaSlug]} removido.`,
      );
      recarregar();
    },
    onError: (e) => toast.error((e as Error).message),
  });

  const lista = usuarios.data ?? [];
  const ocupado = alterarAdmin.isPending || alterarArea.isPending;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight md:text-3xl">
              <ShieldCheck className="h-6 w-6 text-primary" /> Gestão de acessos
            </h1>
            <p className="mt-1 text-muted-foreground">
              O administrador enxerga tudo. Conteúdo de estudo é aberto a todas as pessoas
              autenticadas: aqui você libera apenas quem pode OPERAR cada módulo. As mudanças valem
              na próxima navegação da pessoa.
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => void usuarios.refetch()}
            disabled={usuarios.isFetching}
          >
            <RefreshCw
              className={usuarios.isFetching ? "mr-2 h-4 w-4 animate-spin" : "mr-2 h-4 w-4"}
            />
            Atualizar
          </Button>
        </header>

        <MatrizPermissoes />

        {usuarios.isLoading ? (
          <Carregando mensagem="Carregando pessoas…" blocos={2} />
        ) : usuarios.isError ? (
          <Card className="border-destructive/30">
            <CardContent className="p-6 text-sm text-destructive">
              {(usuarios.error as Error).message}
            </CardContent>
          </Card>
        ) : lista.length === 0 ? (
          <EstadoVazio
            titulo="Nenhuma pessoa cadastrada ainda"
            descricao="Assim que alguém entrar na plataforma, o perfil aparece aqui para receber acessos."
          />
        ) : (
          <div className="space-y-3">
            {lista.map((u) => {
              const souEu = u.id === eu.data;
              const temApp = u.admin || u.areas.includes("app");
              return (
                <Card key={u.id} className="shadow-soft">
                  <CardContent className="space-y-5 p-5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold">{u.full_name ?? "Sem nome"}</div>
                        <div className="truncate text-xs text-muted-foreground">{u.email}</div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {u.admin ? (
                          <Badge variant="secondary">Administrador</Badge>
                        ) : u.areas.length === 0 ? (
                          <Badge variant="secondary">Sem módulo liberado</Badge>
                        ) : (
                          u.areas.map((a) => (
                            <Badge key={a} variant="secondary">
                              {rotulosAreaAcesso[a]}
                            </Badge>
                          ))
                        )}
                      </div>
                    </div>

                    <OrigemAcesso papeis={u.papeis} areas={u.areas} />

                    <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-muted/40 px-3 py-2.5 text-sm">
                      <span>
                        <span className={u.admin ? "font-semibold" : "font-medium"}>
                          Administrador
                        </span>
                        <span className="block text-xs text-muted-foreground">
                          Acesso global: vê e gerencia tudo, inclusive todos os módulos.
                        </span>
                      </span>
                      <AcaoSensivel
                        modulo="Gestão de acessos"
                        acao={
                          u.admin
                            ? "Remover acesso de administrador"
                            : "Conceder acesso de administrador"
                        }
                        alvo={u.email ?? u.full_name ?? u.id}
                        titulo={u.admin ? "Remover administrador" : "Conceder administrador"}
                        descricao="O acesso de administrador libera toda a plataforma. Confirme com atenção."
                        rotuloConfirmar={
                          u.admin ? "Remover administrador" : "Conceder administrador"
                        }
                        destrutiva={u.admin}
                        observacaoObrigatoria
                        payload={{
                          pessoa: u.full_name ?? "sem nome",
                          usuario_id: u.id,
                          papel: "admin",
                          mudanca: u.admin ? "remover" : "conceder",
                        }}
                        onConfirmar={() =>
                          alterarAdmin
                            .mutateAsync({ userId: u.id, conceder: !u.admin })
                            .then(() => undefined)
                        }
                        disabled={ocupado || (u.admin && souEu)}
                      >
                        <Button
                          variant={u.admin ? "outline" : "default"}
                          size="sm"
                          disabled={ocupado || (u.admin && souEu)}
                          aria-label={`${u.admin ? "Remover" : "Conceder"} acesso de administrador para ${u.full_name ?? u.email ?? "pessoa"}`}
                        >
                          {u.admin ? "Remover administrador" : "Conceder administrador"}
                        </Button>
                      </AcaoSensivel>
                    </div>

                    <div className="space-y-3">
                      <div className="text-xs font-semibold uppercase tracking-widest text-primary">
                        Módulos da Operação
                      </div>
                      {u.admin && (
                        <p className="text-xs text-muted-foreground">
                          Esta pessoa é administradora, então já tem acesso a todos os módulos. Os
                          controles abaixo ficam desativados.
                        </p>
                      )}
                      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {areasOperacaoAcesso.map((a) => {
                          const ativo = u.admin || u.areas.includes(a);
                          return (
                            <label
                              key={a}
                              className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-3 py-2 text-sm"
                            >
                              <span className={ativo ? "font-medium" : "text-muted-foreground"}>
                                {rotulosAreaAcesso[a]}
                              </span>
                              <Switch
                                checked={ativo}
                                disabled={ocupado || u.admin}
                                onCheckedChange={(valor) =>
                                  alterarArea.mutate({
                                    userId: u.id,
                                    areaSlug: a,
                                    conceder: valor,
                                  })
                                }
                                aria-label={`${rotulosAreaAcesso[a]} para ${u.full_name ?? u.email ?? "pessoa"}`}
                              />
                            </label>
                          );
                        })}
                      </div>

                      <div className="flex items-center justify-between gap-3 rounded-xl border border-dashed border-border bg-card px-3 py-2.5 text-sm">
                        <span>
                          <span
                            className={
                              u.admin || u.areas.includes("app_n2")
                                ? "font-medium"
                                : "text-muted-foreground"
                            }
                          >
                            App: Painel N2
                          </span>
                          <span className="block text-xs text-muted-foreground">
                            Permissão extra de engenharia dentro do App. Precisa do módulo App
                            liberado para navegar.
                          </span>
                        </span>
                        {(() => {
                          const temN2 = u.admin || u.areas.includes("app_n2");
                          return (
                            <AcaoSensivel
                              modulo="Gestão de acessos"
                              acao={temN2 ? "Remover Painel N2" : "Liberar Painel N2"}
                              alvo={u.email ?? u.full_name ?? u.id}
                              titulo={temN2 ? "Remover Painel N2" : "Liberar Painel N2"}
                              descricao="O Painel N2 dá acesso a ações restritas de engenharia dentro do App."
                              rotuloConfirmar={temN2 ? "Remover Painel N2" : "Liberar Painel N2"}
                              destrutiva={temN2}
                              observacaoObrigatoria
                              payload={{
                                pessoa: u.full_name ?? "sem nome",
                                usuario_id: u.id,
                                modulo_alvo: "app_n2",
                                mudanca: temN2 ? "remover" : "liberar",
                              }}
                              onConfirmar={() =>
                                alterarArea
                                  .mutateAsync({
                                    userId: u.id,
                                    areaSlug: "app_n2",
                                    conceder: !temN2,
                                  })
                                  .then(() => undefined)
                              }
                              disabled={ocupado || u.admin}
                            >
                              <Button
                                variant={temN2 ? "outline" : "default"}
                                size="sm"
                                disabled={ocupado || u.admin}
                                aria-label={`${temN2 ? "Remover" : "Liberar"} Painel N2 para ${u.full_name ?? u.email ?? "pessoa"}`}
                              >
                                {temN2 ? "Remover Painel N2" : "Liberar Painel N2"}
                              </Button>
                            </AcaoSensivel>
                          );
                        })()}
                      </div>

                      {!u.admin && u.areas.includes("app_n2") && !temApp && (
                        <p className="text-xs text-muted-foreground">
                          O Painel N2 está liberado, mas o módulo App ainda não. Libere o App para a
                          pessoa chegar até lá.
                        </p>
                      )}
                    </div>

                    {souEu && (
                      <p className="text-xs text-muted-foreground">
                        Este é o seu próprio acesso: o acesso de administrador não pode ser removido
                        por você.
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
    </div>
  );
}
