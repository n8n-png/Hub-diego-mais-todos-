import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Sparkles, Loader2 } from "lucide-react";
import logoAsset from "@/assets/maistodos-logo.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/auth")({
  component: Auth,
  head: () => ({
    meta: [
      { title: "Entrar · Hub MaisTODOS" },
      {
        name: "description",
        content: "Acesse sua conta do Hub MaisTODOS com e-mail e senha ou com o Google.",
      },
      { property: "og:title", content: "Entrar · Hub MaisTODOS" },
      {
        property: "og:description",
        content: "Acesse sua conta do Hub MaisTODOS com e-mail e senha ou com o Google.",
      },
    ],
  }),
});

/** O Hub é interno: apenas contas do domínio corporativo podem ser criadas. */
const DOMINIO_CORPORATIVO = "maistodos.com.br";

const loginSchema = z.object({
  email: z.string().trim().email({ message: "Informe um e-mail válido" }).max(255),
  password: z.string().min(10, { message: "A senha deve ter no mínimo 10 caracteres" }).max(72),
});

const signupSchema = loginSchema
  .extend({
    fullName: z.string().trim().min(3, { message: "Informe seu nome completo" }).max(120),
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, {
    message: "As senhas não conferem",
    path: ["confirm"],
  })
  .refine((v) => v.email.toLowerCase().endsWith(`@${DOMINIO_CORPORATIVO}`), {
    message: `O Hub é um ambiente interno: use seu e-mail corporativo @${DOMINIO_CORPORATIVO} para criar a conta.`,
    path: ["email"],
  });

function Auth() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      if (data.session) navigate({ to: "/dashboard", replace: true });
      else setChecking(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (session && (event === "SIGNED_IN" || event === "INITIAL_SESSION")) {
        navigate({ to: "/dashboard", replace: true });
      }
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [navigate]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "login") {
        const parsed = loginSchema.safeParse({ email, password });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { error } = await supabase.auth.signInWithPassword(parsed.data);
        if (error) {
          toast.error(
            error.message.includes("Invalid login") ? "E-mail ou senha incorretos." : error.message,
          );
          return;
        }
        toast.success("Bem-vindo de volta!");
        navigate({ to: "/dashboard", replace: true });
      } else {
        const parsed = signupSchema.safeParse({ fullName, email, password, confirm });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { data, error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: parsed.data.fullName },
          },
        });
        if (error) {
          toast.error(
            error.message.includes("already registered")
              ? "Este e-mail já possui uma conta."
              : error.message,
          );
          return;
        }
        if (data.session) {
          navigate({ to: "/dashboard", replace: true });
        } else {
          toast.success("Conta criada! Confirme seu e-mail para acessar.");
          setMode("login");
        }
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogle() {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setLoading(false);
      toast.error("Não foi possível entrar com o Google.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard", replace: true });
  }

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex items-center justify-center p-6">
        <Card className="w-full max-w-md border-0 p-8 shadow-none">
          <img src={logoAsset.url} alt="MaisTODOS" className="h-14 w-14 rounded-xl" />
          <h1 className="mt-6 text-3xl font-bold tracking-tight">
            {mode === "login" ? "Bem-vindo de volta" : "Criar sua conta"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "login"
              ? "Entre para acessar o Hub MaisTODOS."
              : "Preencha seus dados para começar."}
          </p>

          <form className="mt-8 space-y-4" onSubmit={handleSubmit}>
            {mode === "signup" && (
              <div className="grid gap-2">
                <Label htmlFor="fullName">Nome completo</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Seu nome"
                  className="h-11"
                  maxLength={120}
                />
              </div>
            )}
            <div className="grid gap-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={`voce@${DOMINIO_CORPORATIVO}`}
                className="h-11"
                maxLength={255}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="h-11"
              />
            </div>
            {mode === "signup" && (
              <div className="grid gap-2">
                <Label htmlFor="confirm">Confirmar senha</Label>
                <Input
                  id="confirm"
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  className="h-11"
                />
              </div>
            )}

            <Button
              type="submit"
              size="lg"
              disabled={loading}
              className="w-full bg-gradient-primary shadow-glow"
            >
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {mode === "login" ? "Entrar" : "Criar conta"}
            </Button>
          </form>

          <div className="my-6 flex items-center gap-3">
            <span className="h-px flex-1 bg-border" />
            <span className="text-xs uppercase tracking-wider text-muted-foreground">ou</span>
            <span className="h-px flex-1 bg-border" />
          </div>

          <Button
            type="button"
            variant="outline"
            size="lg"
            className="w-full"
            disabled={loading}
            onClick={handleGoogle}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.76h3.57c2.08-1.92 3.27-4.74 3.27-8.09Z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.76c-.99.66-2.26 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.11a6.6 6.6 0 0 1 0-4.22V7.05H2.18a11 11 0 0 0 0 9.9l3.66-2.84Z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.05l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38Z"
              />
            </svg>
            Entrar com Google
          </Button>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {mode === "login" ? "Primeiro acesso?" : "Já tem uma conta?"}{" "}
            <button
              type="button"
              className="font-semibold text-primary hover:underline"
              onClick={() => setMode(mode === "login" ? "signup" : "login")}
            >
              {mode === "login" ? "Criar conta" : "Entrar"}
            </button>
          </p>

          <p className="mt-8 text-center text-xs text-muted-foreground">
            © MaisTODOS · Soluções financeiras inteligentes
          </p>
        </Card>
      </div>

      <div className="bg-gradient-hero relative hidden overflow-hidden lg:block">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "radial-gradient(circle at 30% 30%, oklch(0.9 0.28 130 / 0.6), transparent 40%), radial-gradient(circle at 70% 70%, oklch(0.7 0.3 300 / 0.6), transparent 40%)",
          }}
        />
        <div className="relative flex h-full flex-col justify-center p-16 text-primary-foreground">
          <Sparkles className="text-lime h-10 w-10" />
          <h2 className="mt-6 text-4xl font-bold leading-tight">
            Todo o conhecimento da MaisTODOS em um só lugar.
          </h2>
          <p className="mt-4 max-w-md text-primary-foreground/80">
            Cursos, processos, fluxogramas e a MaisIA para te guiar em qualquer atendimento.
          </p>
        </div>
      </div>
    </div>
  );
}
