/**
 * Aviso ÚNICO de dado fictício dos módulos de Atendimento.
 * O texto era copiado literalmente em quatro rotas: agora mora aqui.
 */
export function AvisoDadoFicticio({ fonte }: { fonte?: string }) {
  return (
    <p className="text-xs text-muted-foreground">
      {fonte ? `Fonte: ${fonte}. ` : ""}
      Dados fictícios nesta onda. A integração real é Fase 2, sempre via proxy server-side, com
      CPF, e-mail e telefone mascarados.
    </p>
  );
}
