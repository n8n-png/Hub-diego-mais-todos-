import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  ArrowRight,
  BookOpen,
  Database,
  FileText,
  Layers,
  Loader2,
  RefreshCw,
  Sparkle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { syncNotion } from "@/lib/kb.functions";

/**
 * Aba "Fontes" da Central de Conhecimento IA.
 * Documentos e Notion são fontes reais do RAG. A Base da plataforma segue
 * como mock nesta onda.
 */

const teamspaces = ["Suporte", "Cancelamentos", "Financeiro", "Processos", "FAQ"];

const basePlataforma = [
  { label: "Base de Conhecimento", itens: 48, icone: BookOpen },
  { label: "Processos", itens: 21, icone: Layers },
  { label: "Scripts", itens: 17, icone: FileText },
  { label: "FAQ", itens: 15, icone: Sparkle },
];

export function FontesConhecimento({
  totalDocumentos,
  totalTreinados,
  onTreinar,
  podeOperar,
}: {
  totalDocumentos: number;
  totalTreinados: number;
  onTreinar: () => void;
  /** Pode executar escrita na base, vindo de src/data/permissoes.ts. */
  podeOperar: boolean;
}) {
  // Sincronizar e treinar é operação; a leitura das fontes é conteúdo aberto.
  const isAdmin = podeOperar;
  const qc = useQueryClient();
  const rodarSync = useServerFn(syncNotion);
  const [mostrarEspacos, setMostrarEspacos] = useState(false);

  const notion = useQuery({
    queryKey: ["kb-notion-stats"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_documents")
        .select("id, source_updated_at, indexed_at")
        .eq("doc_type", "notion")
        .order("source_updated_at", { ascending: false });
      if (error) throw error;
      return {
        total: data.length,
        indexados: data.filter((d) => d.indexed_at).length,
        ultima: data[0]?.source_updated_at ?? null,
      };
    },
  });

  const sync = useMutation({
    mutationFn: async () => await rodarSync(),
    onSuccess: (r) => {
      void qc.invalidateQueries({ queryKey: ["kb-documents"] });
      void qc.invalidateQueries({ queryKey: ["kb-notion-stats"] });
      const ok = r.workspaces.filter((w) => !w.erro).map((w) => w.workspace);
      const falhos = r.workspaces.filter((w) => w.erro);
      const total = `Notion sincronizado: ${r.paginas_atualizadas} páginas atualizadas, ${r.trechos_indexados} trechos indexados, ${r.paginas_puladas} sem mudança.`;

      if (falhos.length === 0) {
        toast.success(total, {
          description: ok.length > 1 ? `Workspaces: ${ok.join(", ")}.` : undefined,
        });
        return;
      }

      toast.warning(total, {
        description: `${ok.length > 0 ? `Funcionaram: ${ok.join(", ")}. ` : ""}Falharam: ${falhos
          .map((w) => `${w.workspace} (${w.erro})`)
          .join(" · ")}`,
      });
    },
    onError: (e: Error) => toast.error(e.message || "Não foi possível sincronizar o Notion."),
  });

  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileText className="h-5 w-5 text-primary" /> Documentos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Badge className="border-0 bg-success/10 text-success">Ativo</Badge>
            <p className="text-muted-foreground">
              Fonte oficial em uso hoje. É o material que o assistente consulta para responder, com
              citação da fonte.
            </p>
            <div className="rounded-lg bg-muted/60 p-3">
              <div className="text-2xl font-bold">{totalDocumentos}</div>
              <div className="text-xs text-muted-foreground">
                documentos cadastrados · {totalTreinados} treinados
              </div>
            </div>
            <Button variant="outline" className="w-full" onClick={onTreinar}>
              Enviar e treinar documentos <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Database className="h-5 w-5 text-primary" /> Notion
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {(notion.data?.total ?? 0) > 0 ? (
              <Badge className="border-0 bg-success/10 text-success">Sincronizado</Badge>
            ) : (
              <Badge variant="secondary">Nenhuma página sincronizada</Badge>
            )}
            <p className="text-muted-foreground">
              A integração aceita vários workspaces, cada um com seu próprio token, e sincroniza
              todos em uma única rodada. O assistente lê apenas as páginas compartilhadas com a
              integração de cada workspace.
            </p>
            <div className="rounded-lg bg-muted/60 p-3">
              <div className="text-2xl font-bold">{notion.data?.total ?? 0}</div>
              <div className="text-xs text-muted-foreground">
                páginas na base · {notion.data?.indexados ?? 0} indexadas
                {notion.data?.ultima
                  ? ` · última edição sincronizada em ${new Date(notion.data.ultima).toLocaleDateString("pt-BR")}`
                  : ""}
              </div>
            </div>
            {isAdmin && (
              <Button className="w-full" onClick={() => sync.mutate()} disabled={sync.isPending}>
                {sync.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sincronizando
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" /> Sincronizar agora
                  </>
                )}
              </Button>
            )}
            <Button
              variant="outline"
              className="w-full"
              onClick={() => setMostrarEspacos((v) => !v)}
            >
              {mostrarEspacos ? "Ocultar detalhes" : "Como o acesso funciona"}
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Layers className="h-5 w-5 text-primary" /> Base da plataforma
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Badge variant="secondary">Indexação automática na Fase 2</Badge>
            <p className="text-muted-foreground">
              Conteúdos internos do painel que o assistente passará a considerar, além dos
              documentos.
            </p>
            <div className="space-y-1.5">
              {basePlataforma.map((f) => (
                <div
                  key={f.label}
                  className="flex items-center gap-2 rounded-lg bg-muted/60 px-3 py-2"
                >
                  <f.icone className="h-4 w-4 text-primary" />
                  <span className="flex-1">{f.label}</span>
                  <Badge variant="outline">{f.itens} itens</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {mostrarEspacos && (
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-lg">O que entra do Notion</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <p className="rounded-lg border border-border bg-muted/60 p-3 text-muted-foreground">
              O controle real do que entra é o compartilhamento no Notion: a sincronização lê apenas
              as páginas explicitamente compartilhadas com a integração de cada workspace. Para
              incluir ou remover conteúdo, ajuste o compartilhamento na própria página e sincronize
              de novo. Os tokens ficam apenas no backend, um por workspace, e nunca aparecem na
              tela.
            </p>
            <div>
              <h3 className="mb-2 text-sm font-semibold">
                Espaços que costumamos compartilhar, apenas informativo
              </h3>
              <div className="flex flex-wrap gap-2">
                {teamspaces.map((nome) => (
                  <Badge key={nome} variant="outline">
                    {nome}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
