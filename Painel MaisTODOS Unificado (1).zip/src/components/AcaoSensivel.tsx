import { useState, type ReactNode } from "react";
import { AlertTriangle, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { registrarAuditoria } from "@/lib/atendimento-auditoria";
import { cn } from "@/lib/utils";

const PALAVRA_CHAVE = "CONFIRMAR";

/**
 * Componente único de ação sensível, usado por TODOS os módulos de Atendimento.
 *
 * Padrão obrigatório em três etapas:
 * 1. pré-visualização do payload exatamente como será enviado,
 * 2. confirmação humana, digitando CONFIRMAR para habilitar o botão,
 * 3. registro em auditoria, com módulo, ação, alvo, payload e resultado.
 */
export function AcaoSensivel({
  modulo,
  acao,
  alvo,
  payload,
  titulo,
  descricao,
  rotuloConfirmar = "Executar ação",
  destrutiva = false,
  pedirObservacao = true,
  observacaoObrigatoria = false,
  onConfirmar,
  children,
  disabled = false,
}: {
  modulo: string;
  acao: string;
  alvo?: string | null;
  payload: unknown;
  titulo: string;
  descricao: string;
  rotuloConfirmar?: string;
  destrutiva?: boolean;
  pedirObservacao?: boolean;
  /** Quando verdadeiro, o botão só libera com uma justificativa preenchida. */
  observacaoObrigatoria?: boolean;
  /** Execução real da ação. Lance um erro para registrar falha na auditoria. */
  onConfirmar: () => Promise<void> | void;
  /** Gatilho que abre o diálogo. */
  children: ReactNode;
  disabled?: boolean;
}) {
  const [aberto, setAberto] = useState(false);
  const [texto, setTexto] = useState("");
  const [observacao, setObservacao] = useState("");
  const [executando, setExecutando] = useState(false);

  const justificativaOk = !observacaoObrigatoria || observacao.trim().length >= 5;
  const habilitado = texto.trim().toUpperCase() === PALAVRA_CHAVE && justificativaOk && !executando;

  function fechar(valor: boolean) {
    setAberto(valor);
    if (!valor) {
      setTexto("");
      setObservacao("");
    }
  }

  async function executar() {
    if (!habilitado) return;
    setExecutando(true);
    try {
      await onConfirmar();
      await registrarAuditoria({
        modulo,
        acao,
        alvo,
        payload,
        resultado: "sucesso",
        observacao: observacao.trim() || null,
      });
      toast.success("Ação concluída e registrada na auditoria.");
      fechar(false);
    } catch (erro) {
      const mensagem = erro instanceof Error ? erro.message : "Falha inesperada.";
      await registrarAuditoria({
        modulo,
        acao,
        alvo,
        payload,
        resultado: "falha",
        observacao: [observacao.trim(), mensagem].filter(Boolean).join(" · ") || null,
      });
      toast.error(`Não foi possível concluir: ${mensagem}`);
    } finally {
      setExecutando(false);
    }
  }

  return (
    <Dialog open={aberto} onOpenChange={fechar}>
      <DialogTrigger asChild disabled={disabled}>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            {titulo}
          </DialogTitle>
          <DialogDescription>{descricao}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-xl border border-border bg-accent px-3 py-2 text-xs text-accent-foreground">
            <div className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <p>
                Esta é uma ação sensível: ela será registrada na auditoria com seu nome, o horário e
                os dados abaixo.
              </p>
            </div>
          </div>

          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Pré-visualização do envio
            </div>
            <pre className="max-h-56 overflow-auto rounded-xl border border-border bg-secondary p-3 text-xs leading-relaxed text-secondary-foreground">
              {JSON.stringify({ modulo, acao, alvo: alvo ?? null, payload }, null, 2)}
            </pre>
          </div>

          {pedirObservacao && (
            <div className="space-y-1.5">
              <Label htmlFor="acao-observacao">
                {observacaoObrigatoria
                  ? "Justificativa para a auditoria (obrigatória)"
                  : "Observação para a auditoria (opcional)"}
              </Label>
              <Textarea
                id="acao-observacao"
                value={observacao}
                onChange={(e) => setObservacao(e.target.value)}
                placeholder="Motivo do atendimento, número do protocolo, quem solicitou…"
                maxLength={500}
                rows={2}
              />
              {observacaoObrigatoria && !justificativaOk && (
                <p className="text-xs text-destructive">
                  Escreva a justificativa, com pelo menos 5 caracteres, para liberar a confirmação.
                </p>
              )}
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="acao-confirmar">
              Para liberar o botão, digite <span className="font-bold">{PALAVRA_CHAVE}</span>
            </Label>
            <Input
              id="acao-confirmar"
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              placeholder={PALAVRA_CHAVE}
              autoComplete="off"
              spellCheck={false}
              maxLength={20}
              className={cn(habilitado && "border-success ring-1 ring-success/40")}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => fechar(false)} disabled={executando}>
            Cancelar
          </Button>
          <Button
            onClick={() => void executar()}
            disabled={!habilitado}
            variant={destrutiva ? "destructive" : "default"}
          >
            {executando && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {rotuloConfirmar}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
