import { Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Construction } from "lucide-react";
import { EstadoVazio } from "@/components/EstadoVazio";

export function AreaIndisponivel({ slug }: { slug: string }) {
  return (
    <AppLayout>
      <Card className="mx-auto max-w-lg shadow-soft">
        <CardContent className="flex flex-col items-center p-10 text-center">
          <Construction className="h-10 w-10 text-primary" />
          <h1 className="mt-4 text-xl font-semibold">Área em construção</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            A área <strong>{slug}</strong> ainda não possui conteúdo publicado. A arquitetura já
            está pronta para receber ferramentas, financeiras, fluxos e materiais.
          </p>
          <Button asChild className="mt-6">
            <Link to="/operacao">Voltar para Operação</Link>
          </Button>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

/** Mantido por compatibilidade: hoje é só um atalho para o estado vazio único. */
export function VazioSecao({ titulo, descricao }: { titulo: string; descricao: string }) {
  return <EstadoVazio titulo={titulo} descricao={descricao} />;
}
