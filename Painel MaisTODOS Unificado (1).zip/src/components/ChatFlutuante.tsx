import { useCallback, useEffect, useRef, useState } from "react";
import { Headset, Send, Loader2, Minus, X, User, FileText, Compass } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { useNavigate } from "@tanstack/react-router";
import { encontrarTopicos, type TopicoNavegacao } from "@/data/navegacao-assistente";
import { askKb, type AskResult } from "@/lib/kb.functions";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Msg = {
  role: "user" | "assistant";
  content: string;
  sources?: AskResult["sources"];
  atalhos?: TopicoNavegacao[];
};

const POS_KEY = "maistodos.chat.pos";
const BTN = 60;

const sugestoes = [
  "Qual o prazo para estorno de PIX?",
  "Como atualizar o contato de um filiado?",
  "Como funciona a liberação de cashback?",
];

type Pos = { x: number; y: number };

const EVENTO_ABRIR = "maistodos:abrir-chat";

/**
 * Abre o chat flutuante de qualquer lugar do painel.
 * Com pergunta, o chat abre e já envia a dúvida ao assistente.
 */
export function abrirChatMaisTodos(pergunta?: string) {
  window.dispatchEvent(
    new CustomEvent<{ pergunta?: string }>(EVENTO_ABRIR, { detail: { pergunta } }),
  );
}

function clamp(p: Pos): Pos {
  const maxX = Math.max(8, window.innerWidth - BTN - 8);
  const maxY = Math.max(8, window.innerHeight - BTN - 8);
  return { x: Math.min(Math.max(8, p.x), maxX), y: Math.min(Math.max(8, p.y), maxY) };
}

/**
 * Chat flutuante global do painel: botão arrastável com posição salva
 * e janela de conversa ligada à base de conhecimento oficial (RAG real).
 */
export function ChatFlutuante() {
  const ask = useServerFn(askKb);
  const navigate = useNavigate();
  const [pos, setPos] = useState<Pos | null>(null);
  const [aberto, setAberto] = useState(false);
  const [minimizado, setMinimizado] = useState(false);
  const [input, setInput] = useState("");
  const [pensando, setPensando] = useState(false);
  const [pendente, setPendente] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Olá, eu sou a Maisa, assistente do Hub MaisTODOS. Respondo com base nos documentos oficiais e nos guias da operação. Como posso ajudar agora?",
    },
  ]);

  const dragRef = useRef({ moving: false, moved: false, dx: 0, dy: 0 });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let inicial: Pos = { x: window.innerWidth - BTN - 24, y: window.innerHeight - BTN - 24 };
    try {
      const raw = window.localStorage.getItem(POS_KEY);
      if (raw) {
        const p = JSON.parse(raw) as Pos;
        if (typeof p.x === "number" && typeof p.y === "number") inicial = p;
      }
    } catch {
      /* posição inválida: usa o canto padrão */
    }
    setPos(clamp(inicial));
  }, []);

  useEffect(() => {
    if (aberto && !minimizado) {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    }
  }, [msgs, pensando, aberto, minimizado]);

  useEffect(() => {
    function onAbrir(e: Event) {
      setAberto(true);
      setMinimizado(false);
      const pergunta = (e as CustomEvent<{ pergunta?: string }>).detail?.pergunta?.trim();
      if (pergunta) {
        setInput(pergunta);
        setPendente(pergunta);
      }
    }
    window.addEventListener(EVENTO_ABRIR, onAbrir);
    return () => window.removeEventListener(EVENTO_ABRIR, onAbrir);
  }, []);

  useEffect(() => {
    if (aberto && !minimizado && !pensando) inputRef.current?.focus();
  }, [aberto, minimizado, pensando]);

  useEffect(() => {
    function onMove(e: PointerEvent) {
      if (!dragRef.current.moving) return;
      dragRef.current.moved = true;
      setPos(clamp({ x: e.clientX - dragRef.current.dx, y: e.clientY - dragRef.current.dy }));
    }
    function onUp() {
      if (!dragRef.current.moving) return;
      dragRef.current.moving = false;
      setPos((p) => {
        if (p) {
          try {
            window.localStorage.setItem(POS_KEY, JSON.stringify(p));
          } catch {
            /* armazenamento indisponível */
          }
        }
        return p;
      });
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, []);

  const enviar = useCallback(
    async (texto: string) => {
      if (!texto.trim() || pensando) return;
      const history = msgs
        .slice(1)
        .slice(-8)
        .map((m) => ({ role: m.role, content: m.content }));
      setMsgs((m) => [...m, { role: "user", content: texto }]);
      setInput("");
      setPensando(true);
      try {
        const res = await ask({ data: { question: texto, history } });
        setMsgs((m) => [
          ...m,
          {
            role: "assistant",
            content: res.answer,
            sources: res.sources,
            atalhos: encontrarTopicos(texto, 3),
          },
        ]);
      } catch (e) {
        toast.error((e as Error).message || "Não foi possível consultar a base oficial.");
      } finally {
        setPensando(false);
      }
    },
    [ask, msgs, pensando],
  );

  useEffect(() => {
    if (!pendente || pensando) return;
    const pergunta = pendente;
    setPendente(null);
    void enviar(pergunta);
  }, [pendente, pensando, enviar]);

  if (!pos) return null;

  return (
    <>
      {(!aberto || minimizado) && (
        <button
          type="button"
          aria-label="Abrir a Maisa, assistente do Hub"
          style={{ left: pos.x, top: pos.y, width: BTN, height: BTN }}
          onPointerDown={(e) => {
            dragRef.current = {
              moving: true,
              moved: false,
              dx: e.clientX - pos.x,
              dy: e.clientY - pos.y,
            };
          }}
          onClick={() => {
            if (dragRef.current.moved) return;
            setAberto(true);
            setMinimizado(false);
          }}
          className="fixed z-50 grid touch-none place-items-center rounded-full bg-gradient-primary text-primary-foreground shadow-glow transition-transform hover:scale-105"
        >
          <Headset className="h-6 w-6" />
          <span className="absolute right-1.5 top-1.5 h-3 w-3 rounded-full border-2 border-card bg-lime" />
        </button>
      )}

      {aberto && !minimizado && (
        <div className="fixed bottom-4 right-4 z-50 flex h-[560px] w-[min(24rem,calc(100vw-2rem))] max-h-[calc(100vh-2rem)] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-glow">
          <header className="flex items-center gap-3 bg-gradient-primary px-4 py-3 text-primary-foreground">
            <span className="relative grid h-9 w-9 place-items-center rounded-full bg-primary-foreground/15">
              <Headset className="h-4 w-4" />
              <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-primary bg-lime" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold">Maisa · Assistente do Hub</div>
              <div className="text-xs uppercase tracking-widest text-primary-foreground/90">
                Online · documentos, base da plataforma e, em breve, Notion
              </div>
            </div>
            <button
              type="button"
              aria-label="Minimizar conversa"
              onClick={() => setMinimizado(true)}
              className="rounded-lg p-1.5 transition-colors hover:bg-primary-foreground/15"
            >
              <Minus className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Fechar conversa"
              onClick={() => setAberto(false)}
              className="rounded-lg p-1.5 transition-colors hover:bg-primary-foreground/15"
            >
              <X className="h-4 w-4" />
            </button>
          </header>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <div key={i} className={cn("flex gap-2", m.role === "user" && "flex-row-reverse")}>
                <span
                  className={cn(
                    "grid h-7 w-7 shrink-0 place-items-center rounded-full",
                    m.role === "assistant" ? "bg-accent text-primary" : "bg-muted",
                  )}
                >
                  {m.role === "assistant" ? (
                    <Headset className="h-3.5 w-3.5" />
                  ) : (
                    <User className="h-3.5 w-3.5" />
                  )}
                </span>
                <div className="max-w-[82%] space-y-2">
                  <div
                    className={cn(
                      "rounded-2xl px-3 py-2 text-sm",
                      m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                    )}
                  >
                    <div className="prose prose-sm max-w-none [&_*]:text-inherit">
                      <ReactMarkdown>{m.content}</ReactMarkdown>
                    </div>
                  </div>
                  {m.sources && m.sources.length > 0 && (
                    <div className="space-y-1 rounded-xl border border-border bg-background p-2">
                      <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                        Fonte
                      </div>
                      {m.sources.map((s) => (
                        <div
                          key={s.document_id}
                          className="flex items-start gap-1.5 text-[11px] text-muted-foreground"
                        >
                          <FileText className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
                          <span>
                            <span className="font-medium text-foreground">{s.title}</span> · v
                            {s.version} · atualizado em{" "}
                            {new Date(s.updated_at).toLocaleDateString("pt-BR")}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                  {m.atalhos && m.atalhos.length > 0 && (
                    <div className="space-y-2 rounded-xl border border-border bg-background p-2">
                      <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                        <Compass className="h-3 w-3 text-primary" /> Onde resolver na plataforma
                      </div>
                      {m.atalhos.map((a) => (
                        <div key={a.rota + a.titulo} className="flex items-center gap-2">
                          <span className="flex-1 text-[11px] text-muted-foreground">
                            {a.caminho}
                          </span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-[11px]"
                            onClick={() => {
                              setMinimizado(true);
                              void navigate({ to: a.rota });
                            }}
                          >
                            Abrir
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {pensando && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Consultando a base oficial…
              </div>
            )}
          </div>

          <div className="border-t border-border p-3">
            {msgs.length <= 1 && (
              <div className="mb-2 flex flex-wrap gap-1.5">
                {sugestoes.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => void enviar(s)}
                    className="rounded-full border border-border bg-muted/60 px-2.5 py-1 text-[11px] transition-colors hover:bg-accent"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            <p className="mb-2 text-[10px] leading-relaxed text-muted-foreground">
              Respondo com base nos documentos oficiais e na base da plataforma. Em breve, também no
              Notion. Também mostro o caminho e te levo até a tela certa.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void enviar(input);
              }}
              className="flex gap-2"
            >
              <Input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Escreva sua dúvida…"
                className="h-10"
              />
              <Button
                type="submit"
                size="icon"
                className="h-10 w-10 bg-gradient-primary"
                disabled={pensando}
              >
                {pensando ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
