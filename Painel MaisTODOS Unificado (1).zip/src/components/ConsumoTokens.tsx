import { useQuery } from "@tanstack/react-query";
import { Coins, TrendingDown, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";

/**
 * Consumo real de tokens da IA, lido de ai_usage (gravado server-side a partir
 * do campo usage devolvido pelo gateway). Visível apenas para admin.
 */

/**
 * ESTIMATIVA de preço, em dólar por 1 milhão de tokens. Ajuste aqui, é o único
 * lugar. O valor cobrado de verdade é em créditos da workspace no gateway da
 * Lovable, então estes números servem só como referência de ordem de grandeza.
 */
export const PRECO_ESTIMADO_USD_POR_MILHAO = {
  embedding: 0.02,
  chat_entrada: 0.3,
  chat_saida: 2.5,
};

const rotulos: Record<string, string> = {
  ask: "Perguntas ao assistente",
  index: "Treino de documentos",
  notion: "Sincronização do Notion",
  copilot: "Copiloto de rascunho",
};

type Linha = {
  created_at: string;
  kind: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
};

function ehEmbedding(model: string) {
  return model.includes("embedding");
}

function custoEstimado(linhas: Linha[]) {
  let usd = 0;
  for (const l of linhas) {
    if (ehEmbedding(l.model)) {
      usd += (l.total_tokens / 1_000_000) * PRECO_ESTIMADO_USD_POR_MILHAO.embedding;
    } else {
      usd +=
        (l.input_tokens / 1_000_000) * PRECO_ESTIMADO_USD_POR_MILHAO.chat_entrada +
        (l.output_tokens / 1_000_000) * PRECO_ESTIMADO_USD_POR_MILHAO.chat_saida;
    }
  }
  return usd;
}

const numero = (n: number) => n.toLocaleString("pt-BR");

export function ConsumoTokens() {
  const { data, isLoading } = useQuery({
    queryKey: ["ai-usage"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_usage")
        .select("created_at, kind, model, input_tokens, output_tokens, total_tokens")
        .order("created_at", { ascending: false })
        .limit(5000);
      if (error) throw error;
      return data as Linha[];
    },
  });

  const linhas = data ?? [];
  const entrada = linhas.reduce((s, l) => s + l.input_tokens, 0);
  const saida = linhas.reduce((s, l) => s + l.output_tokens, 0);
  const total = linhas.reduce((s, l) => s + l.total_tokens, 0);
  const usd = custoEstimado(linhas);

  const porTipo = Object.keys(rotulos).map((kind) => {
    const doTipo = linhas.filter((l) => l.kind === kind);
    return {
      kind,
      chamadas: doTipo.length,
      tokens: doTipo.reduce((s, l) => s + l.total_tokens, 0),
    };
  });

  const dias: { dia: string; tokens: number; chamadas: number }[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const chave = d.toISOString().slice(0, 10);
    const doDia = linhas.filter((l) => l.created_at.slice(0, 10) === chave);
    dias.push({
      dia: chave,
      tokens: doDia.reduce((s, l) => s + l.total_tokens, 0),
      chamadas: doDia.length,
    });
  }

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Coins className="h-5 w-5 text-primary" /> Consumo de tokens
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {isLoading && <p className="text-sm text-muted-foreground">Carregando o consumo.</p>}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-border bg-muted/60 p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <TrendingDown className="h-4 w-4 text-primary" /> Tokens de entrada
            </div>
            <div className="mt-1 text-2xl font-bold">{numero(entrada)}</div>
          </div>
          <div className="rounded-xl border border-border bg-muted/60 p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-primary" /> Tokens de saída
            </div>
            <div className="mt-1 text-2xl font-bold">{numero(saida)}</div>
          </div>
          <div className="rounded-xl border border-border bg-muted/60 p-4">
            <div className="text-xs text-muted-foreground">Total de tokens</div>
            <div className="mt-1 text-2xl font-bold">{numero(total)}</div>
          </div>
          <div className="rounded-xl border border-border bg-muted/60 p-4">
            <div className="text-xs text-muted-foreground">Custo estimado</div>
            <div className="mt-1 text-2xl font-bold">
              {usd.toLocaleString("pt-BR", { style: "currency", currency: "USD" })}
            </div>
            <Badge variant="secondary" className="mt-1">
              Estimativa
            </Badge>
          </div>
        </div>

        <div>
          <h3 className="mb-2 text-sm font-semibold">Quebra por tipo de uso</h3>
          <div className="grid gap-2 md:grid-cols-2">
            {porTipo.map((t) => (
              <div
                key={t.kind}
                className="flex items-center gap-2 rounded-lg bg-muted/60 px-3 py-2 text-sm"
              >
                <span className="flex-1">{rotulos[t.kind]}</span>
                <Badge variant="outline">{t.chamadas} chamadas</Badge>
                <span className="font-semibold">{numero(t.tokens)} tokens</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-2 text-sm font-semibold">Últimos 14 dias</h3>
          <div className="overflow-hidden rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-xs text-muted-foreground">
                <tr>
                  <th className="p-2 text-left font-medium">Dia</th>
                  <th className="p-2 text-right font-medium">Chamadas</th>
                  <th className="p-2 text-right font-medium">Tokens</th>
                </tr>
              </thead>
              <tbody>
                {dias.map((d) => (
                  <tr key={d.dia} className="border-t border-border">
                    <td className="p-2">
                      {new Date(`${d.dia}T12:00:00`).toLocaleDateString("pt-BR")}
                    </td>
                    <td className="p-2 text-right">{d.chamadas}</td>
                    <td className="p-2 text-right font-medium">{numero(d.tokens)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <p className="rounded-lg border border-border bg-muted/60 p-3 text-xs text-muted-foreground">
          O custo acima é uma estimativa, calculada com preços de referência por 1 milhão de tokens
          definidos no código. A cobrança real acontece em créditos da workspace no gateway de IA da
          Lovable, portanto use este painel apenas para acompanhar a ordem de grandeza do consumo.
        </p>
      </CardContent>
    </Card>
  );
}
