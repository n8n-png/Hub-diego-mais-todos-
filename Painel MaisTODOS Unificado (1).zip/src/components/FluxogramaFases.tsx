import { ArrowDown, GitBranch, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { FaseLogistica, PassoLogistica } from "@/data/logistica";

const faixa: Record<FaseLogistica["tom"], string> = {
  roxo: "bg-primary text-primary-foreground",
  azul: "bg-primary/80 text-primary-foreground",
  laranja: "bg-primary/60 text-primary-foreground",
  ambar: "bg-accent text-accent-foreground",
  verde: "bg-lime text-lime-foreground",
};

const borda: Record<FaseLogistica["tom"], string> = {
  roxo: "border-l-primary",
  azul: "border-l-primary/80",
  laranja: "border-l-primary/60",
  ambar: "border-l-accent",
  verde: "border-l-lime",
};

function Seta({ rotulo }: { rotulo?: string }) {
  return (
    <div className="flex flex-col items-center gap-1 py-1" aria-hidden={!rotulo}>
      <ArrowDown className="h-4 w-4 text-muted-foreground" />
      {rotulo && <span className="text-[11px] font-medium text-muted-foreground">{rotulo}</span>}
    </div>
  );
}

function NoPasso({ passo, tom }: { passo: PassoLogistica; tom: FaseLogistica["tom"] }) {
  return (
    <article
      className={`rounded-xl border border-border border-l-4 bg-card p-4 shadow-soft ${borda[tom]} ${
        passo.decisao ? "border-dashed" : ""
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-2">
        <h4 className="flex items-start gap-2 font-semibold leading-snug">
          {passo.decisao && <GitBranch className="mt-0.5 h-4 w-4 shrink-0 text-primary" />}
          <span>
            {passo.n}. {passo.titulo}
          </span>
        </h4>
        <Badge variant="secondary" className="shrink-0">
          {passo.responsavel}
        </Badge>
      </div>

      {passo.caminho && (
        <p className="mt-2 rounded-lg bg-muted px-3 py-2 text-xs leading-relaxed text-foreground/80">
          {passo.caminho}
        </p>
      )}

      <p className="mt-2 text-sm text-muted-foreground">{passo.descricao}</p>

      {passo.obs && (
        <p className="mt-2 flex gap-2 text-xs text-muted-foreground">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <span>{passo.obs}</span>
        </p>
      )}
    </article>
  );
}

/** Fluxograma nativo do Hub: fases em faixa, etapas em cards e setas de ligação. */
export function FluxogramaFases({
  fases,
  passos,
}: {
  fases: FaseLogistica[];
  passos: PassoLogistica[];
}) {
  return (
    <div className="space-y-8">
      {fases.map((fase, iFase) => {
        const etapas = passos.filter((p) => p.fase === fase.nome);
        if (etapas.length === 0) return null;

        return (
          <section key={fase.nome} className="space-y-3">
            <h3
              className={`rounded-lg px-4 py-2 text-sm font-semibold tracking-tight ${faixa[fase.tom]}`}
            >
              Fase {iFase + 1} · {fase.nome}
            </h3>

            <div className="space-y-1 md:pl-4">
              {etapas.map((p, i) => (
                <div key={p.n}>
                  <NoPasso passo={p} tom={fase.tom} />
                  {i < etapas.length - 1 && <Seta rotulo={p.decisao ? p.saida : undefined} />}
                </div>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
