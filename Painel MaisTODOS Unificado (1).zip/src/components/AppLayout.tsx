import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  GraduationCap,
  BookOpen,
  Download,
  Settings,
  Search,
  Menu,
  BarChart3,
  BrainCircuit,
  ShieldCheck,
  User,
  LogOut,
  CreditCard,
  Landmark,
  Banknote,
  Package,
  Smartphone,
  Gift,
  Wrench,
  Truck,
  Users,
  Library,
  Megaphone,
  FileText,
  Compass,
  Receipt,
  Layers,
  type LucideIcon,
} from "lucide-react";
import logoAsset from "@/assets/maistodos-logo.png.asset.json";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { initials, useProfile } from "@/hooks/use-profile";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Fragment, useState, type ReactNode } from "react";
import {
  areas as areasOperacao,
  areaSections,
  gruposSecao,
  type SecaoGrupo,
} from "@/data/operacao";
import { useRoles } from "@/hooks/use-roles";
import { useAreaAccess } from "@/hooks/use-area-access";
import { podeOperar, type ModuloOperacional } from "@/data/permissoes";

import { atendimentoModulos } from "@/data/atendimento-modulos";
import { ChatFlutuante } from "@/components/ChatFlutuante";

type NavItem = { to: string; label: string; icon: LucideIcon };

/** Ícones lucide por área da Operação, substituindo emojis na navegação. */
const iconesArea: Record<string, LucideIcon> = {
  "credito-pf": CreditCard,
  "conta-digital": Landmark,
  pagamentos: Banknote,
  logistica: Package,
  app: Smartphone,
  cashback: Gift,
};

/** Ícones lucide por seção da área. */
const iconesSecao: Record<string, LucideIcon> = {
  ferramentas: Wrench,
  financeiras: Landmark,
  fluxo: BarChart3,
  fluxos: Truck,
  comercial: Users,
  materiais: Library,
  comunicados: Megaphone,
  processos: FileText,
  onboarding: Compass,
  reprovacoes: Receipt,
  onboardingApp: Compass,
};

/**
 * Itens de navegação que são OPERAÇÃO e por isso dependem de papel.
 * O que não está aqui é conteúdo, aberto a qualquer pessoa autenticada.
 */
const navModulo: Record<string, ModuloOperacional> = {
  "/acessos": "acessos",
  "/gestor": "gestor",
};

function IconeArea({ slug, className }: { slug: string; className?: string }) {
  const Icon = iconesArea[slug] ?? Layers;
  return <Icon className={className} />;
}

function IconeSecao({ slug, className }: { slug: string; className?: string }) {
  const Icon = iconesSecao[slug] ?? FileText;
  return <Icon className={className} />;
}

const nav: { section: string; items: NavItem[] }[] = [
  {
    section: "Principal",
    items: [
      { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { to: "/universidade", label: "Universidade", icon: GraduationCap },
    ],
  },
  {
    section: "Inteligência",
    items: [{ to: "/central-ia", label: "Central de Conhecimento IA", icon: BrainCircuit }],
  },
  {
    section: "Administração",
    items: [{ to: "/acessos", label: "Gestão de acessos", icon: ShieldCheck }],
  },
  {
    section: "Você",
    items: [
      { to: "/base", label: "Base de Conhecimento", icon: BookOpen },

      { to: "/downloads", label: "Downloads", icon: Download },
      { to: "/gestor", label: "Painel do Gestor", icon: BarChart3 },
      { to: "/perfil", label: "Meu Perfil", icon: User },
      { to: "/configuracoes", label: "Configurações", icon: Settings },
    ],
  },
];

function SidebarConteudo({ onNavegar }: { onNavegar?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { roles } = useRoles();
  const { areas } = useAreaAccess();
  const opera = (modulo: ModuloOperacional) => podeOperar(modulo, roles, areas);
  // Accordion da Operação: apenas uma área expandida por vez.
  const [areaAberta, setAreaAberta] = useState<string | null>(() => {
    const m = /^\/operacao\/([^/]+)/.exec(pathname);
    if (m) return m[1];
    if (pathname.startsWith("/atendimento")) return "app";
    return null;
  });

  // Conteúdo aparece para todos, inclusive a leitura da Central de Conhecimento IA.
  // Só os itens declarados como operação em src/data/permissoes.ts dependem de papel.
  const grupos = nav
    .map((g) => ({
      ...g,
      items: g.items.filter((i) => {
        const modulo = navModulo[i.to];
        return !modulo || opera(modulo);
      }),
    }))
    .filter((g) => g.items.length > 0);

  return (
    <>
      <div className="flex items-center gap-3 px-5 py-5">
        <img src={logoAsset.url} alt="MaisTODOS" className="h-10 w-10 rounded-xl" />
        <div className="leading-tight">
          <div className="text-xs uppercase tracking-widest text-sidebar-primary">Hub</div>
          <div className="text-sm font-semibold">MaisTODOS</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 pb-6">
        {grupos.map((group) => (
          <Fragment key={group.section}>
            <div className="mb-5">
              <div className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/50">
                {group.section}
              </div>
              <ul className="space-y-1">
                {group.items.map((item) => {
                  const active =
                    pathname === item.to ||
                    (item.to !== "/dashboard" && pathname.startsWith(item.to));
                  const Icon = item.icon;
                  return (
                    <li key={item.to}>
                      <Link
                        to={item.to}
                        onClick={onNavegar}
                        className={cn(
                          "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                          active
                            ? "bg-sidebar-accent text-sidebar-accent-foreground"
                            : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                        )}
                      >
                        <Icon className="h-4 w-4" />
                        <span>{item.label}</span>
                        {active && (
                          <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>

            {group.section === "Principal" && (
              <div className="mb-5">
                <div className="mb-2 flex items-center justify-between px-3 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/50">
                  <span>Operação</span>
                  <Link
                    to="/operacao"
                    onClick={onNavegar}
                    className="text-sidebar-primary hover:underline"
                  >
                    ver tudo
                  </Link>
                </div>
                <ul className="space-y-1">
                  {areasOperacao.map((a) => {
                    const to = `/operacao/${a.slug}`;
                    const active = pathname.startsWith(to);
                    const aberta = areaAberta === a.slug;
                    const mostrarModulos = a.slug === "app" && aberta;
                    const mostrarSecoes = a.slug !== "app" && a.disponivel && aberta;
                    return (
                      <li key={a.slug}>
                        {a.disponivel ? (
                          <Link
                            to={to}
                            onClick={() => {
                              setAreaAberta((atual) => (atual === a.slug ? null : a.slug));
                              onNavegar?.();
                            }}
                            className={cn(
                              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                              active
                                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                                : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                            )}
                          >
                            <IconeArea slug={a.slug} className="h-4 w-4 shrink-0" />
                            <span>{a.nome}</span>
                            {active && (
                              <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />
                            )}
                          </Link>
                        ) : (
                          <div className="flex cursor-not-allowed items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/35">
                            <IconeArea slug={a.slug} className="h-4 w-4 shrink-0 opacity-60" />
                            <span>{a.nome}</span>
                            <span className="ml-auto text-[9px] uppercase tracking-wider">
                              em breve
                            </span>
                          </div>
                        )}
                        {mostrarModulos && (
                          <ul className="mt-1 space-y-1 border-l border-sidebar-foreground/15 pl-3">
                            <li className="px-3 pt-1 text-[9px] font-semibold uppercase tracking-widest text-sidebar-foreground/45">
                              {gruposSecao.rotinas.nome}
                            </li>
                            {atendimentoModulos
                              .filter((m) => opera(m.modulo))
                              .map((m) => {
                                const ativo = pathname.startsWith(m.to);
                                const Icon = m.icon;
                                return (
                                  <li key={m.to}>
                                    <Link
                                      to={m.to}
                                      onClick={onNavegar}
                                      className={cn(
                                        "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                                        ativo
                                          ? "bg-sidebar-accent text-sidebar-accent-foreground"
                                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                                      )}
                                    >
                                      <Icon className="h-3.5 w-3.5" />
                                      <span className="min-w-0 truncate">{m.nome}</span>
                                    </Link>
                                  </li>
                                );
                              })}
                            {(a.secoes ?? [])
                              .filter((s) => s.grupo === "guia")
                              .map((s, i) => {
                                const subTo = `${to}/${s.slug}`;
                                const ativo =
                                  pathname === subTo || pathname.startsWith(`${subTo}/`);
                                return (
                                  <Fragment key={s.slug}>
                                    {i === 0 && (
                                      <li className="px-3 pt-2 text-[9px] font-semibold uppercase tracking-widest text-sidebar-foreground/45">
                                        {gruposSecao.guia.nome}
                                      </li>
                                    )}
                                    <li>
                                      <Link
                                        to={subTo}
                                        onClick={onNavegar}
                                        className={cn(
                                          "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                                          ativo
                                            ? "bg-sidebar-accent text-sidebar-accent-foreground"
                                            : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                                        )}
                                      >
                                        <IconeSecao
                                          slug={s.slug}
                                          className="h-3.5 w-3.5 shrink-0"
                                        />
                                        <span className="min-w-0 truncate">{s.nome}</span>
                                      </Link>
                                    </li>
                                  </Fragment>
                                );
                              })}
                          </ul>
                        )}
                        {mostrarSecoes && (
                          <ul className="mt-1 space-y-1 border-l border-sidebar-foreground/15 pl-3">
                            {(["rotinas", "guia"] as SecaoGrupo[]).flatMap((grupo) => {
                              const doGrupo = (a.secoes ?? areaSections).filter(
                                (s) => s.grupo === grupo,
                              );
                              if (doGrupo.length === 0) return [];
                              return [
                                <li
                                  key={`t-${grupo}`}
                                  className="px-3 pt-2 text-[9px] font-semibold uppercase tracking-widest text-sidebar-foreground/45"
                                >
                                  {gruposSecao[grupo].nome}
                                </li>,
                                ...doGrupo.map((s) => {
                                  const subTo = `${to}/${s.slug}`;
                                  const ativo =
                                    pathname === subTo || pathname.startsWith(`${subTo}/`);
                                  return (
                                    <li key={s.slug}>
                                      <Link
                                        to={subTo}
                                        onClick={onNavegar}
                                        className={cn(
                                          "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                                          ativo
                                            ? "bg-sidebar-accent text-sidebar-accent-foreground"
                                            : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                                        )}
                                      >
                                        <IconeSecao
                                          slug={s.slug}
                                          className="h-3.5 w-3.5 shrink-0"
                                        />
                                        <span className="min-w-0 truncate">{s.nome}</span>
                                      </Link>
                                    </li>
                                  );
                                }),
                              ];
                            })}
                          </ul>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
          </Fragment>
        ))}
      </nav>
    </>
  );
}

export function AppLayout({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { profile, avatarSrc } = useProfile();

  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [busca, setBusca] = useState("");
  const [menuAberto, setMenuAberto] = useState(false);
  const naBase = pathname === "/base" || pathname.startsWith("/base/");

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="flex min-h-screen bg-muted/40">
      {/* Sidebar (desktop) */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <SidebarConteudo />
      </aside>

      {/* Main */}
      <div className="flex min-h-screen flex-1 flex-col lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur md:px-8">
          <Sheet open={menuAberto} onOpenChange={setMenuAberto}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="shrink-0 lg:hidden"
                aria-label="Abrir menu de navegação"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="left"
              className="flex w-[86vw] max-w-80 flex-col gap-0 overflow-y-auto bg-sidebar p-0 text-sidebar-foreground"
            >
              <SheetTitle className="sr-only">Navegação</SheetTitle>
              <SidebarConteudo onNavegar={() => setMenuAberto(false)} />
            </SheetContent>
          </Sheet>

          <div className="flex min-w-0 flex-1 items-center gap-2">
            {!naBase && (
              <form
                className="relative w-full max-w-md"
                onSubmit={(e) => {
                  e.preventDefault();
                  const q = busca.trim();
                  if (!q) return;
                  navigate({ to: "/base", search: { q } });
                }}
              >
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  placeholder="Pesquisar procedimento, artigo, script…"
                  aria-label="Pesquisar na base de conhecimento"
                  className="pl-9 h-10 bg-muted/60 border-transparent focus-visible:bg-background"
                />
              </form>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Abrir menu da conta"
                className="shrink-0 rounded-full outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Avatar className="h-9 w-9">
                  {avatarSrc && <AvatarImage src={avatarSrc} alt="Foto de perfil" />}
                  <AvatarFallback className="bg-gradient-primary text-primary-foreground text-sm font-semibold">
                    {initials(profile?.full_name, profile?.email)}
                  </AvatarFallback>
                </Avatar>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="truncate">
                <div className="font-semibold">{profile?.full_name ?? "Colaborador"}</div>
                <div className="truncate text-xs font-normal text-muted-foreground">
                  {profile?.email}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/perfil">
                  <User className="mr-2 h-4 w-4" /> Meu Perfil
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/configuracoes">
                  <Settings className="mr-2 h-4 w-4" /> Configurações
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => void handleSignOut()}>
                <LogOut className="mr-2 h-4 w-4" /> Sair
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        <main className="flex-1 p-4 md:p-8 animate-fade-in">{children}</main>
        <ChatFlutuante />
      </div>
    </div>
  );
}
