import { Badge } from "@/components/ui/badge";
import type { EstadoVisual } from "@/data/atendimento";

/**
 * Badge ÚNICO de status do Atendimento.
 * Consome os mapas de src/data/atendimento.ts, todos no mesmo formato
 * { label, classe }, para nenhum mapa de status viver dentro de rota.
 */
export function BadgeStatus({ estado }: { estado: EstadoVisual }) {
  return (
    <Badge variant="outline" className={estado.classe}>
      {estado.label}
    </Badge>
  );
}
