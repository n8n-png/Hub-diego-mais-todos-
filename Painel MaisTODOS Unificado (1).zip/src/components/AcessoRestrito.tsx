import { ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

/**
 * Padrão ÚNICO de bloqueio por papel do Hub.
 * Toda tela e todo guarda de rota operacional usa este componente, para a
 * mensagem de acesso restrito não divergir pelo app.
 */
export function AcessoRestrito({
  mensagem,
  titulo = "Acesso restrito",
}: {
  mensagem: string;
  titulo?: string;
}) {
  return (
    <Card className="mx-auto max-w-lg shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldAlert className="h-5 w-5 text-primary" /> {titulo}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        <p>{mensagem}</p>
        <p className="mt-2">
          Fale com um administrador da plataforma para receber o papel adequado. Todo o conteúdo de
          estudo do Hub continua aberto para você.
        </p>
      </CardContent>
    </Card>
  );
}
