import { Inbox, type LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { TableCell, TableRow } from "@/components/ui/table";

/**
 * Estado vazio ÚNICO do Hub.
 * Fora de tabela, renderiza um card no padrão da marca. Dentro de tabela,
 * informe `colSpan` e o componente devolve a linha com a célula mesclada,
 * para não existirem cinco formatos de vazio pelo app.
 */
export function EstadoVazio({
  titulo,
  descricao,
  icon: Icon = Inbox,
  colSpan,
}: {
  titulo: string;
  descricao?: string;
  icon?: LucideIcon;
  colSpan?: number;
}) {
  const conteudo = (
    <>
      <Icon className="h-8 w-8 text-primary" aria-hidden="true" />
      <h2 className="mt-3 text-sm font-semibold text-foreground">{titulo}</h2>
      {descricao && (
        <p className="mt-1 max-w-md text-sm text-muted-foreground">{descricao}</p>
      )}
    </>
  );

  if (colSpan) {
    return (
      <TableRow>
        <TableCell colSpan={colSpan} className="py-10">
          <div className="flex flex-col items-center text-center">{conteudo}</div>
        </TableCell>
      </TableRow>
    );
  }

  return (
    <Card className="border-dashed">
      <CardContent className="flex flex-col items-center p-10 text-center">{conteudo}</CardContent>
    </Card>
  );
}
