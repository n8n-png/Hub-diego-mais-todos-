import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { type OperacaoArea } from "@/data/operacao";

export type Crumb = { label: string; to?: string };

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav
      aria-label="Trilha de navegação"
      className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground"
    >
      {items.map((c, i) => (
        <span key={`${c.label}-${i}`} className="flex items-center gap-1">
          {i > 0 && <ChevronRight className="h-3 w-3 opacity-60" />}
          {c.to ? (
            <Link
              to={c.to}
              className="rounded px-1 py-0.5 transition-colors hover:bg-muted hover:text-foreground"
            >
              {c.label}
            </Link>
          ) : (
            <span className="px-1 py-0.5 font-medium text-foreground">{c.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

/**
 * Casca padrão de uma área da Operação: menu lateral contextual + trilha.
 * Reutilizável por qualquer área (Crédito PF, Conta Digital, ...).
 */
export function OperacaoShell({
  area,
  crumbs,
  children,
}: {
  area: OperacaoArea;
  crumbs: Crumb[];
  children: ReactNode;
}) {
  return (
    <AppLayout>
      <div className="space-y-5">
        <Breadcrumbs items={[{ label: "Operação", to: "/operacao" }, ...crumbs]} />
        <div className="min-w-0 animate-fade-in">{children}</div>
      </div>
    </AppLayout>
  );
}
