import { useState } from "react";
import { Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  buscarFiliadoMock,
  cpfCompleto,
  filiadosMock,
  mascararCpf,
  somenteDigitos,
  type Filiado,
} from "@/data/atendimento";

/**
 * Card de busca por CPF, reaproveitado pelos módulos de Atendimento.
 * Mesma UX do Gerenciamento de Filiados: máscara no input, Enter busca e
 * chips com os CPFs da base fictícia.
 *
 * MOCK: a consulta real ao cadastro é Fase 2, sempre via proxy server-side.
 */
export function BuscaFiliadoCpf({
  titulo = "Buscar filiado por CPF",
  onEncontrado,
}: {
  titulo?: string;
  onEncontrado: (filiado: Filiado | null, cpf: string) => void;
}) {
  const [busca, setBusca] = useState("");
  const [erro, setErro] = useState<string | null>(null);

  function buscar(valor = busca) {
    setErro(null);
    if (!cpfCompleto(valor)) {
      onEncontrado(null, "");
      setErro("Informe os 11 dígitos do CPF. A máscara é opcional.");
      return;
    }
    const encontrado = buscarFiliadoMock(valor);
    onEncontrado(encontrado, encontrado ? somenteDigitos(valor) : "");
    if (!encontrado) {
      setErro("Nenhum filiado localizado com este CPF na base de teste.");
    }
  }

  return (
    <Card className="shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">{titulo}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1 space-y-1.5">
            <Label htmlFor="cpf-busca">CPF, com ou sem máscara</Label>
            <Input
              id="cpf-busca"
              value={busca}
              inputMode="numeric"
              autoComplete="off"
              placeholder="000.000.000-00"
              onChange={(e) => setBusca(mascararCpf(e.target.value))}
              onKeyDown={(e) => {
                if (e.key === "Enter") buscar();
              }}
            />
          </div>
          <Button onClick={() => buscar()} className="sm:w-40">
            <Search className="mr-2 h-4 w-4" /> Buscar
          </Button>
        </div>

        {erro && <p className="text-sm text-destructive">{erro}</p>}

        <div className="rounded-xl border border-dashed border-border-strong bg-secondary p-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Base fictícia de teste
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {filiadosMock.map((f) => (
              <button
                key={f.cpf}
                type="button"
                onClick={() => {
                  setBusca(mascararCpf(f.cpf));
                  setErro(null);
                  onEncontrado(f, f.cpf);
                }}
                className="rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-medium transition-colors hover:border-primary hover:text-primary"
              >
                {mascararCpf(f.cpf)} · {f.nome.split(" ")[0]}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Dados fictícios, apenas para validar o fluxo. A consulta real entra na Fase 2, via proxy
            server-side.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
