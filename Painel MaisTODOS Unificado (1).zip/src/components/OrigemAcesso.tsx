import { rotulosAreaAcesso, type AreaAcesso } from "@/data/areas-acesso";
import { modulosOperacionais, type ModuloOperacional } from "@/data/permissoes";
import type { AppRole } from "@/hooks/use-roles";

/**
 * Mostra, pessoa por pessoa, de onde vem a autorização de cada módulo operacional.
 * Existem dois caminhos, ambos intencionais: o papel e a liberação por área em
 * user_area_access. Quem administra precisa ver os dois, senão a liberação por
 * área fica invisível na revisão de acesso.
 */
export type OrigemModulo = {
  id: ModuloOperacional;
  nome: string;
  origem: "admin" | "papel" | "area";
  detalhe: string;
};

export function origensDeAcesso(
  papeis: readonly AppRole[],
  areas: readonly AreaAcesso[],
): OrigemModulo[] {
  const conjuntoAreas = new Set(areas);
  const resultado: OrigemModulo[] = [];

  for (const m of modulosOperacionais) {
    if (papeis.includes("admin")) {
      resultado.push({
        id: m.id,
        nome: m.nome,
        origem: "admin",
        detalhe: "papel de administrador",
      });
      continue;
    }
    const porPapel = m.papeis.filter((p) => papeis.includes(p));
    if (porPapel.length > 0) {
      resultado.push({
        id: m.id,
        nome: m.nome,
        origem: "papel",
        detalhe: `papel ${porPapel.join(", ")}`,
      });
      continue;
    }
    if (m.areaOperacional && conjuntoAreas.has(m.areaOperacional)) {
      resultado.push({
        id: m.id,
        nome: m.nome,
        origem: "area",
        detalhe: `liberação por área ${rotulosAreaAcesso[m.areaOperacional]}`,
      });
    }
  }

  return resultado;
}

export function OrigemAcesso({
  papeis,
  areas,
}: {
  papeis: readonly AppRole[];
  areas: readonly AreaAcesso[];
}) {
  const origens = origensDeAcesso(papeis, areas);

  return (
    <div className="space-y-2 rounded-xl border border-border bg-muted/30 px-3 py-2.5">
      <div className="text-xs font-semibold uppercase tracking-widest text-primary">
        Origem do acesso
      </div>
      {origens.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          Esta pessoa não opera nenhum módulo. Ela continua com todo o conteúdo de estudo liberado,
          porque conteúdo é aberto a quem está autenticado.
        </p>
      ) : (
        <ul className="space-y-1 text-xs">
          {origens.map((o) => (
            <li key={o.id} className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{o.nome}</span>
              <span
                className={
                  o.origem === "area"
                    ? "rounded-full bg-primary/10 px-2 py-0.5 font-medium text-primary"
                    : "rounded-full bg-secondary px-2 py-0.5 font-medium text-secondary-foreground"
                }
              >
                {o.origem === "area" ? "por liberação de área" : "por papel"}
              </span>
              <span className="text-muted-foreground">{o.detalhe}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
