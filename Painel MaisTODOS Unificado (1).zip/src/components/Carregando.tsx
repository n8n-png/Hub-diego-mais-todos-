import { Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

/**
 * Carregamento ÚNICO do Hub.
 * Por padrão mostra blocos no lugar do conteúdo que vem a seguir. Com
 * `inline`, mostra uma linha discreta com a mensagem, para uso dentro de
 * cartões e listas. Nunca misture os dois na mesma tela.
 */
export function Carregando({
  mensagem = "Carregando…",
  blocos = 3,
  inline = false,
  className,
}: {
  mensagem?: string;
  blocos?: number;
  inline?: boolean;
  className?: string;
}) {
  if (inline) {
    return (
      <div
        role="status"
        aria-live="polite"
        className={
          className ?? "flex items-center gap-2 py-6 text-sm text-muted-foreground"
        }
      >
        <Loader2 className="h-4 w-4 animate-spin text-primary" aria-hidden="true" />
        <span>{mensagem}</span>
      </div>
    );
  }

  return (
    <div role="status" aria-live="polite" className={className ?? "space-y-3"}>
      <span className="sr-only">{mensagem}</span>
      {Array.from({ length: blocos }).map((_, i) => (
        <Skeleton key={i} className="h-24 w-full rounded-2xl" />
      ))}
    </div>
  );
}
