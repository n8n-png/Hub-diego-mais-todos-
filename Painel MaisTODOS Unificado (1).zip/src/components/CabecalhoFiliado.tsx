import type { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { CardHeader, CardTitle } from "@/components/ui/card";
import { cpfProtegido, type Filiado } from "@/data/atendimento";

/**
 * Cabeçalho ÚNICO de card de filiado nos módulos de Atendimento:
 * título do bloco, nome, CPF protegido e um selo à direita, que pode ser
 * contagem de registros ou origem do dado.
 */
export function CabecalhoFiliado({
  filiado,
  titulo,
  icon: Icon,
  complemento,
  selo,
}: {
  filiado: Filiado;
  titulo: string;
  icon?: LucideIcon;
  complemento?: string;
  selo?: string;
}) {
  return (
    <CardHeader className="pb-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            {Icon && <Icon className="h-4 w-4 text-primary" aria-hidden="true" />}
            {titulo}
          </CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            {filiado.nome} · CPF {cpfProtegido(filiado.cpf)}
            {complemento ? ` · ${complemento}` : ""}
          </p>
        </div>
        {selo && (
          <Badge variant="outline" className="border-border bg-accent text-accent-foreground">
            {selo}
          </Badge>
        )}
      </div>
    </CardHeader>
  );
}
