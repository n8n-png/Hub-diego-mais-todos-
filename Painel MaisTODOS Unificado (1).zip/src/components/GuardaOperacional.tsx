import type { ReactNode } from "react";
import { AcessoRestrito } from "@/components/AcessoRestrito";
import { Carregando } from "@/components/Carregando";
import { useRoles } from "@/hooks/use-roles";
import { useAreaAccess } from "@/hooks/use-area-access";
import { getModulo, podeOperar, type ModuloOperacional } from "@/data/permissoes";

/** Decisão de operação em um hook, lendo sempre src/data/permissoes.ts. */
export function usePodeOperar(modulo: ModuloOperacional) {
  const { roles, loading: carregandoPapeis } = useRoles();
  const { areas, loading: carregandoAreas } = useAreaAccess();
  return {
    liberado: podeOperar(modulo, roles, areas),
    loading: carregandoPapeis || carregandoAreas,
  };
}

/**
 * Guarda de rota de módulo OPERACIONAL.
 * Acessar a URL direto sem o papel mostra a tela de acesso restrito, nunca a tela do módulo.
 */
export function GuardaOperacional({
  modulo,
  children,
}: {
  modulo: ModuloOperacional;
  children: ReactNode;
}) {
  const { liberado, loading } = usePodeOperar(modulo);
  const def = getModulo(modulo);

  if (loading) {
    return (
      <Carregando mensagem="Verificando seu acesso…" blocos={2} />
    );
  }

  if (!liberado) {
    return (
      <AcessoRestrito
        mensagem={`${def.nome} é um módulo de operação: ${def.descricao} Por isso o acesso depende do papel certo.`}
      />
    );
  }

  return <>{children}</>;
}
