import { Construction } from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Breadcrumbs } from "@/components/OperacaoShell";
import { GuardaOperacional } from "@/components/GuardaOperacional";
import type { ModuloOperacional } from "@/data/permissoes";

/**
 * Casca da área de Atendimento. Os módulos aqui são OPERAÇÃO, então o acesso
 * depende do papel, lido de src/data/permissoes.ts pelo guarda único de rota.
 * Sem o papel, mesmo por URL direta, aparece a tela de acesso restrito padrão.
 */
export function AtendimentoShell({
  titulo,
  descricao,
  modulo,
  children,
}: {
  titulo: string;
  descricao: string;
  modulo: ModuloOperacional;
  children: ReactNode;
}) {
  return (
    <AppLayout>
      <GuardaOperacional modulo={modulo}>
        <div className="space-y-6">
          <Breadcrumbs
            items={[
              { label: "Operação", to: "/operacao" },
              { label: "App", to: "/operacao/app" },
              { label: titulo },
            ]}
          />
          <header>
            <div className="text-xs font-semibold uppercase tracking-widest text-primary">
              Atendimento · App
            </div>
            <h1 className="mt-1 text-3xl font-bold tracking-tight">{titulo}</h1>
            <p className="mt-1 text-muted-foreground">{descricao}</p>
          </header>
          {children}
        </div>
      </GuardaOperacional>
    </AppLayout>
  );
}

/** Placeholder on-brand para os módulos que entram nas próximas ondas. */
export function AtendimentoEmConstrucao({
  modulo,
  proximoPasso,
}: {
  modulo: string;
  proximoPasso: string;
}) {
  return (
    <Card className="border-dashed shadow-soft">
      <CardContent className="flex flex-col items-center p-12 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent">
          <Construction className="h-7 w-7 text-primary" />
        </span>
        <h2 className="mt-4 text-lg font-semibold">{modulo} em construção</h2>
        <p className="mt-2 max-w-md text-sm text-muted-foreground">
          A estrutura, o acesso por papel e o padrão de ação sensível já estão prontos.{" "}
          {proximoPasso}
        </p>
        <p className="mt-4 max-w-md text-xs text-muted-foreground">
          Integrações reais são Fase 2: sempre via proxy server-side, com CPF, e-mail e telefone
          mascarados, conforme LGPD.
        </p>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/atendimento/filiados">Ir para Gerenciamento de Filiados</Link>
        </Button>
      </CardContent>
    </Card>
  );
}
