import { Fragment } from "react";
import { Check, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { rotulosAreaAcesso } from "@/data/areas-acesso";
import {
  modulosOperacionais,
  papeisMatriz,
  papelOperaModulo,
  type DefinicaoModulo,
} from "@/data/permissoes";

/**
 * Matriz de quem pode o quê, gerada a partir de src/data/permissoes.ts.
 * Serve para o administrador entender o que está concedendo antes de conceder.
 */
export function MatrizPermissoes() {
  const grupos = Array.from(new Set(modulosOperacionais.map((m) => m.grupo)));

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="text-lg">Quem pode o quê</CardTitle>
        <p className="text-sm text-muted-foreground">
          Conteúdo é aberto a todas as pessoas autenticadas do domínio corporativo, por decisão de
          produto: Universidade, Base de Conhecimento e o guia de operação de todas as áreas. A
          matriz abaixo vale só para operação, ou seja, para quem executa a ação.
        </p>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
              <th className="py-2 pr-4 text-left font-semibold">Módulo de operação</th>
              {papeisMatriz.map((p) => (
                <th key={p.papel} className="px-2 py-2 text-center font-semibold">
                  {p.rotulo}
                </th>
              ))}
              <th className="px-2 py-2 text-center font-semibold">Liberação por área</th>
            </tr>
          </thead>
          <tbody>
            {grupos.map((grupo) => (
              <Fragment key={grupo}>
                <tr>
                  <td
                    colSpan={papeisMatriz.length + 2}
                    className="pt-4 pb-1 text-xs font-semibold uppercase tracking-widest text-primary"
                  >
                    {grupo}
                  </td>
                </tr>
                {modulosOperacionais
                  .filter((m) => m.grupo === grupo)
                  .map((m: DefinicaoModulo) => (
                    <tr key={m.id} className="border-b border-border/60">
                      <td className="py-2 pr-4">
                        <div className="font-medium">{m.nome}</div>
                        <div className="text-xs text-muted-foreground">{m.descricao}</div>
                      </td>
                      {papeisMatriz.map((p) => {
                        const pode = papelOperaModulo(m.id, p.papel);
                        return (
                          <td key={p.papel} className="px-2 py-2 text-center">
                            {pode ? (
                              <Check
                                className="mx-auto h-4 w-4 text-lime-foreground"
                                aria-label="Pode operar"
                              />
                            ) : (
                              <Minus
                                className="mx-auto h-4 w-4 text-muted-foreground/50"
                                aria-label="Não pode operar"
                              />
                            )}
                          </td>
                        );
                      })}
                      <td className="px-2 py-2 text-center text-xs">
                        {m.areaOperacional ? (
                          <span className="rounded-full bg-primary/10 px-2 py-0.5 font-medium text-primary">
                            {rotulosAreaAcesso[m.areaOperacional]}
                          </span>
                        ) : (
                          <span className="text-muted-foreground/70">não se aplica</span>
                        )}
                      </td>
                    </tr>
                  ))}
              </Fragment>
            ))}
          </tbody>
        </table>
        <p className="mt-4 text-xs text-muted-foreground">
          Os módulos de Atendimento e o Painel N2 também podem ser liberados pessoa por pessoa,
          pelos controles de módulo abaixo, e essa liberação basta para operar. A trava vale no
          servidor, não apenas na tela.
        </p>
      </CardContent>
    </Card>
  );
}
