import type { ReactNode } from "react";
import {
  Table,
  TableBody,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { EstadoVazio } from "@/components/EstadoVazio";

export type ColunaAtendimento = {
  rotulo: string;
  alinhamento?: "left" | "right";
  className?: string;
};

/**
 * Tabela ÚNICA dos módulos de Atendimento: bloco de rolagem horizontal com
 * borda arredondada, cabeçalho e linha de vazio no mesmo padrão.
 * Usada por Cashback, Estornos e Carteirinhas.
 */
export function TabelaAtendimento({
  colunas,
  vazio,
  vazioVisivel,
  rodape,
  children,
}: {
  colunas: ColunaAtendimento[];
  vazio: { titulo: string; descricao?: string };
  vazioVisivel: boolean;
  rodape?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            {colunas.map((c) => (
              <TableHead
                key={c.rotulo}
                className={[c.alinhamento === "right" ? "text-right" : "", c.className ?? ""]
                  .filter(Boolean)
                  .join(" ")}
              >
                {c.rotulo}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {vazioVisivel ? (
            <EstadoVazio
              colSpan={colunas.length}
              titulo={vazio.titulo}
              descricao={vazio.descricao}
            />
          ) : (
            children
          )}
        </TableBody>
        {rodape && !vazioVisivel && <TableFooter>{rodape}</TableFooter>}
      </Table>
    </div>
  );
}
