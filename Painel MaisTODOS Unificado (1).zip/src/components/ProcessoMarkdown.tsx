import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ZoomIn } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";

const PREFIXO = "kbimg:";
const BUCKET = "kb-imagens";

/** Imagem do processo guardada no armazenamento privado, aberta por URL assinada. */
function ImagemProcesso({
  path,
  alt,
  onZoom,
}: {
  path: string;
  alt: string;
  onZoom: (url: string) => void;
}) {
  const assinada = useQuery({
    queryKey: ["kb-imagem", path],
    queryFn: async () => {
      const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
    staleTime: 50 * 60 * 1000,
  });

  if (assinada.isLoading) return <Skeleton className="my-4 h-56 w-full rounded-xl" />;
  if (assinada.isError || !assinada.data) {
    return (
      <span className="my-4 block rounded-xl border border-border bg-muted p-4 text-sm text-muted-foreground">
        Imagem do procedimento indisponível agora.
      </span>
    );
  }

  return (
    <button
      type="button"
      onClick={() => onZoom(assinada.data)}
      className="group relative my-4 block w-full overflow-hidden rounded-xl border border-border bg-card"
      aria-label="Ampliar imagem do procedimento"
    >
      <img src={assinada.data} alt={alt} loading="lazy" className="h-auto w-full" />
      <span className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-lg bg-background/90 opacity-0 transition-opacity group-hover:opacity-100">
        <ZoomIn className="h-4 w-4 text-primary" />
      </span>
    </button>
  );
}

/** Renderiza o passo a passo do processo com títulos, listas, tabelas e imagens do Notion. */
export function ProcessoMarkdown({ content }: { content: string }) {
  const [zoom, setZoom] = useState<string | null>(null);

  return (
    <>
      <div className="text-sm leading-relaxed text-foreground">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          urlTransform={(url) => url}
          components={{
            h1: ({ children }) => (
              <h2 className="mb-3 mt-6 text-xl font-bold tracking-tight first:mt-0">{children}</h2>
            ),
            h2: ({ children }) => <h3 className="mb-2 mt-6 text-lg font-semibold">{children}</h3>,
            h3: ({ children }) => <h4 className="mb-2 mt-5 font-semibold">{children}</h4>,
            p: ({ children }) => <p className="my-3 whitespace-pre-wrap">{children}</p>,
            ul: ({ children }) => <ul className="my-3 list-disc space-y-1 pl-5">{children}</ul>,
            ol: ({ children }) => <ol className="my-3 list-decimal space-y-2 pl-5">{children}</ol>,
            li: ({ children }) => <li className="pl-1">{children}</li>,
            strong: ({ children }) => (
              <strong className="font-semibold text-foreground">{children}</strong>
            ),
            a: ({ href, children }) => (
              <a
                href={href}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-primary underline underline-offset-2"
              >
                {children}
              </a>
            ),
            blockquote: ({ children }) => (
              <blockquote className="my-3 border-l-2 border-primary/40 bg-accent/40 py-2 pl-4 text-muted-foreground">
                {children}
              </blockquote>
            ),
            code: ({ children }) => (
              <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[0.85em]">
                {children}
              </code>
            ),
            pre: ({ children }) => (
              <pre className="my-3 overflow-x-auto rounded-xl bg-muted p-4 text-xs">{children}</pre>
            ),
            hr: () => <hr className="my-6 border-border" />,
            table: ({ children }) => (
              <div className="my-4 overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-left text-sm">{children}</table>
              </div>
            ),
            th: ({ children }) => (
              <th className="border-b border-border bg-muted px-3 py-2 font-semibold">
                {children}
              </th>
            ),
            td: ({ children }) => (
              <td className="border-b border-border px-3 py-2 align-top">{children}</td>
            ),
            img: ({ src, alt }) => {
              const url = typeof src === "string" ? src : "";
              if (url.startsWith(PREFIXO)) {
                return (
                  <ImagemProcesso
                    path={url.slice(PREFIXO.length)}
                    alt={alt ?? "Imagem do processo"}
                    onZoom={setZoom}
                  />
                );
              }
              return url ? (
                <img
                  src={url}
                  alt={alt ?? ""}
                  loading="lazy"
                  className="my-4 w-full rounded-xl border border-border"
                />
              ) : null;
            },
          }}
        >
          {content}
        </ReactMarkdown>
      </div>

      <Dialog open={Boolean(zoom)} onOpenChange={(o) => !o && setZoom(null)}>
        <DialogContent className="max-w-5xl border-none bg-transparent p-0 shadow-none">
          {zoom && (
            <img src={zoom} alt="Imagem ampliada do procedimento" className="w-full rounded-xl" />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
