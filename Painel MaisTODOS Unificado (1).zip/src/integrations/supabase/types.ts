export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_queries: {
        Row: {
          answer: string | null
          created_at: string
          found: boolean
          id: string
          question: string
          used_document_ids: string[]
          user_id: string
        }
        Insert: {
          answer?: string | null
          created_at?: string
          found?: boolean
          id?: string
          question: string
          used_document_ids?: string[]
          user_id: string
        }
        Update: {
          answer?: string | null
          created_at?: string
          found?: boolean
          id?: string
          question?: string
          used_document_ids?: string[]
          user_id?: string
        }
        Relationships: []
      }
      ai_usage: {
        Row: {
          created_at: string
          id: string
          input_tokens: number
          kind: string
          model: string
          output_tokens: number
          ref: string | null
          total_tokens: number
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          input_tokens?: number
          kind: string
          model: string
          output_tokens?: number
          ref?: string | null
          total_tokens?: number
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          input_tokens?: number
          kind?: string
          model?: string
          output_tokens?: number
          ref?: string | null
          total_tokens?: number
          user_id?: string | null
        }
        Relationships: []
      }
      atendimento_auditoria: {
        Row: {
          acao: string
          alvo: string | null
          created_at: string
          id: string
          modulo: string
          observacao: string | null
          payload: Json
          resultado: string
          user_id: string
          user_name: string | null
        }
        Insert: {
          acao: string
          alvo?: string | null
          created_at?: string
          id?: string
          modulo: string
          observacao?: string | null
          payload?: Json
          resultado?: string
          user_id: string
          user_name?: string | null
        }
        Update: {
          acao?: string
          alvo?: string | null
          created_at?: string
          id?: string
          modulo?: string
          observacao?: string | null
          payload?: Json
          resultado?: string
          user_id?: string
          user_name?: string | null
        }
        Relationships: []
      }
      kb_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      kb_chunks: {
        Row: {
          chunk_index: number
          content: string
          created_at: string
          document_id: string
          embedding: string | null
          id: string
        }
        Insert: {
          chunk_index: number
          content: string
          created_at?: string
          document_id: string
          embedding?: string | null
          id?: string
        }
        Update: {
          chunk_index?: number
          content?: string
          created_at?: string
          document_id?: string
          embedding?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kb_chunks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "kb_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      kb_document_versions: {
        Row: {
          changed_by: string | null
          changed_by_name: string | null
          content: string
          created_at: string
          document_id: string
          id: string
          title: string
          version: number
        }
        Insert: {
          changed_by?: string | null
          changed_by_name?: string | null
          content: string
          created_at?: string
          document_id: string
          id?: string
          title: string
          version: number
        }
        Update: {
          changed_by?: string | null
          changed_by_name?: string | null
          content?: string
          created_at?: string
          document_id?: string
          id?: string
          title?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "kb_document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "kb_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      kb_documents: {
        Row: {
          author_id: string | null
          author_name: string | null
          category_id: string | null
          content: string
          created_at: string
          doc_type: Database["public"]["Enums"]["kb_doc_type"]
          file_name: string | null
          file_path: string | null
          id: string
          indexed_at: string | null
          notion_page_id: string | null
          notion_url: string | null
          source_updated_at: string | null
          status: Database["public"]["Enums"]["kb_status"]
          tags: string[]
          title: string
          updated_at: string
          usage_count: number
          version: number
        }
        Insert: {
          author_id?: string | null
          author_name?: string | null
          category_id?: string | null
          content?: string
          created_at?: string
          doc_type?: Database["public"]["Enums"]["kb_doc_type"]
          file_name?: string | null
          file_path?: string | null
          id?: string
          indexed_at?: string | null
          notion_page_id?: string | null
          notion_url?: string | null
          source_updated_at?: string | null
          status?: Database["public"]["Enums"]["kb_status"]
          tags?: string[]
          title: string
          updated_at?: string
          usage_count?: number
          version?: number
        }
        Update: {
          author_id?: string | null
          author_name?: string | null
          category_id?: string | null
          content?: string
          created_at?: string
          doc_type?: Database["public"]["Enums"]["kb_doc_type"]
          file_name?: string | null
          file_path?: string | null
          id?: string
          indexed_at?: string | null
          notion_page_id?: string | null
          notion_url?: string | null
          source_updated_at?: string | null
          status?: Database["public"]["Enums"]["kb_status"]
          tags?: string[]
          title?: string
          updated_at?: string
          usage_count?: number
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "kb_documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "kb_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_area_access: {
        Row: {
          area_slug: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          area_slug: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          area_slug?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      expurgar_dados_ia_antigos: { Args: never; Returns: Json }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      match_kb_chunks: {
        Args: { match_count?: number; query_embedding: string }
        Returns: {
          category_name: string
          chunk_id: string
          content: string
          doc_type: Database["public"]["Enums"]["kb_doc_type"]
          document_id: string
          similarity: number
          title: string
          updated_at: string
          version: number
        }[]
      }
      search_kb_chunks_text: {
        Args: { match_count?: number; query_text: string }
        Returns: {
          category_name: string
          chunk_id: string
          content: string
          doc_type: Database["public"]["Enums"]["kb_doc_type"]
          document_id: string
          similarity: number
          title: string
          updated_at: string
          version: number
        }[]
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "gestor"
        | "colaborador"
        | "atendimento_n1"
        | "atendimento_n2"
      kb_doc_type:
        | "artigo"
        | "faq"
        | "procedimento"
        | "politica"
        | "script"
        | "macro"
        | "fluxo"
        | "arquivo"
        | "notion"
      kb_status: "ativo" | "arquivado"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "gestor",
        "colaborador",
        "atendimento_n1",
        "atendimento_n2",
      ],
      kb_doc_type: [
        "artigo",
        "faq",
        "procedimento",
        "politica",
        "script",
        "macro",
        "fluxo",
        "arquivo",
        "notion",
      ],
      kb_status: ["ativo", "arquivado"],
    },
  },
} as const
