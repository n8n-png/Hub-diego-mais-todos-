import { useCallback, useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Profile = {
  id: string;
  full_name: string | null;
  email: string | null;
  avatar_url: string | null;
};

export function initials(name?: string | null, email?: string | null) {
  const source = (name ?? email ?? "").trim();
  if (!source) return "U";
  const parts = source.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

async function resolveAvatar(avatarUrl: string | null): Promise<string | null> {
  if (!avatarUrl) return null;
  if (avatarUrl.startsWith("http")) return avatarUrl;
  const { data } = await supabase.storage.from("avatars").createSignedUrl(avatarUrl, 60 * 60);
  return data?.signedUrl ?? null;
}

export function useProfile() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [avatarSrc, setAvatarSrc] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data: userData } = await supabase.auth.getUser();
    const current = userData.user ?? null;
    setUser(current);
    if (!current) {
      setProfile(null);
      setAvatarSrc(null);
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from("profiles")
      .select("id, full_name, email, avatar_url")
      .eq("id", current.id)
      .maybeSingle();
    const p = (data as Profile | null) ?? {
      id: current.id,
      full_name: (current.user_metadata?.["full_name"] as string) ?? null,
      email: current.email ?? null,
      avatar_url: null,
    };
    setProfile(p);
    setAvatarSrc(await resolveAvatar(p.avatar_url));
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return { user, profile, avatarSrc, loading, reload: load };
}
