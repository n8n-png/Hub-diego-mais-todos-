import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "gestor" | "colaborador" | "atendimento_n1" | "atendimento_n2";

export function useRoles() {
  const query = useQuery({
    queryKey: ["user-roles"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) return [] as AppRole[];
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
      return (data ?? []).map((r) => r.role as AppRole);
    },
    staleTime: 60_000,
  });

  const roles = query.data ?? [];
  const isAdmin = roles.includes("admin");

  return {
    roles,
    isAdmin,
    isGestor: isAdmin || roles.includes("gestor"),
    /** Acesso à área de Atendimento: N1, N2 ou administrador. */
    isAtendimento: isAdmin || roles.includes("atendimento_n1") || roles.includes("atendimento_n2"),
    /** Ações restritas de engenharia: somente N2 ou administrador. */
    isAtendimentoN2: isAdmin || roles.includes("atendimento_n2"),
    loading: query.isLoading,
  };
}
