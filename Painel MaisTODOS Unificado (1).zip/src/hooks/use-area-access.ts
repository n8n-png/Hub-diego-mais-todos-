import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useRoles } from "@/hooks/use-roles";

/**
 * Permissão de OPERAR em uma área da Operação, lida de user_area_access.
 *
 * IMPORTANTE, mudança de conceito: esta tabela NÃO controla mais a leitura de
 * conteúdo. Conteúdo, inclusive o guia de operação de todas as áreas e de todos
 * os setores, é aberto a qualquer pessoa autenticada, por decisão de produto.
 * Aqui ficam apenas liberações de execução, por exemplo operar os módulos de
 * Atendimento da área App ("app") e o Painel N2 ("app_n2").
 *
 * Não use este hook para esconder conteúdo. A decisão de operação mora em
 * src/data/permissoes.ts, através de podeOperar.
 */
export function useAreaAccess() {
  const { isAdmin, loading: carregandoPapeis } = useRoles();

  const query = useQuery({
    queryKey: ["user-area-access"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) return [] as string[];
      const { data } = await supabase
        .from("user_area_access")
        .select("area_slug")
        .eq("user_id", uid);
      return (data ?? []).map((r) => r.area_slug);
    },
    staleTime: 60_000,
  });

  const areas = new Set(query.data ?? []);

  return {
    areas,
    isAdmin,
    /** Pode OPERAR nesta área. Nunca use para liberar leitura de conteúdo. */
    podeOperarArea: (slug: string) => isAdmin || areas.has(slug),
    loading: carregandoPapeis || query.isLoading,
  };
}
