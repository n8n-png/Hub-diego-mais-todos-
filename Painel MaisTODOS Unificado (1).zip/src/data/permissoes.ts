import type { AppRole } from "@/hooks/use-roles";

/**
 * FONTE ÚNICA DE VERDADE do modelo de acesso do Hub MaisTODOS.
 *
 * Conceito em uma frase: conteúdo é didático e aberto a todos os colaboradores
 * autenticados do domínio corporativo; operação é restrita por papel, com trava
 * real no servidor.
 *
 * CAMADA 1, CONTEÚDO, aberto a QUALQUER autenticado, e por isso NÃO entra nesta lista:
 * Universidade, trilhas e progresso, Base de Conhecimento, Processos, Fluxogramas,
 * Scripts, FAQ, Downloads, o chat assistente e TODA a Operação em modo consulta,
 * de todas as áreas: guia da operação, Central de Ferramentas, Financeiras Parceiras,
 * Fluxo da Operação, Time Comercial, Materiais de Apoio, Comunicados, Onboarding,
 * Processos e Reprovações. Um colaborador de qualquer setor pode estudar o guia de
 * qualquer outro setor. Área sem conteúdo é "em breve", o que é diferente de bloqueada.
 * Ler a Central de Conhecimento IA também é conteúdo.
 *
 * CAMADA 2, OPERAÇÃO, declarada abaixo. Só entra aqui o que EXECUTA ação sobre
 * sistema, dado de filiado, papel de pessoa ou base de conhecimento. Toda ação de
 * escrita que use o componente AcaoSensivel é operação.
 *
 * A interface, os guardas de rota e as mensagens de acesso restrito devem ler daqui.
 * A trava que realmente protege é a do servidor: cada função de escrita valida o
 * papel com has_role e as tabelas operacionais mantêm RLS coerente com esta matriz.
 */

export type ModuloOperacional =
  | "atendimento_filiados"
  | "atendimento_cashback"
  | "atendimento_estornos"
  | "atendimento_carteirinhas"
  | "atendimento_n2"
  | "auditoria"
  | "acessos"
  | "gestor"
  | "conhecimento_escrita";

export type DefinicaoModulo = {
  /** Identificador estável do módulo operacional. */
  id: ModuloOperacional;
  /** Nome curto para a interface e para a matriz da tela de acessos. */
  nome: string;
  /** Onde o módulo vive, para agrupar na matriz. */
  grupo: "Atendimento · App" | "Gestão" | "Administração" | "Conhecimento";
  /** O que a pessoa consegue fazer, em linguagem de produto. */
  descricao: string;
  /** Papéis que podem OPERAR o módulo. Admin entra sempre, de forma explícita. */
  papeis: AppRole[];
  /**
   * Liberação alternativa por área da Operação, lida de user_area_access.
   * user_area_access significa permissão de OPERAR naquela área, nunca de ver conteúdo.
   */
  areaOperacional?: "app" | "app_n2";
};

const ATENDIMENTO: AppRole[] = ["admin", "atendimento_n1", "atendimento_n2"];

export const modulosOperacionais: DefinicaoModulo[] = [
  {
    id: "atendimento_filiados",
    nome: "Gerenciamento de Filiados",
    grupo: "Atendimento · App",
    descricao: "Buscar filiado por CPF, atualizar e remover contato.",
    papeis: ATENDIMENTO,
    areaOperacional: "app",
  },
  {
    id: "atendimento_cashback",
    nome: "Cashback",
    grupo: "Atendimento · App",
    descricao: "Consultar lançamentos e liberar cashback em lote.",
    papeis: ATENDIMENTO,
    areaOperacional: "app",
  },
  {
    id: "atendimento_estornos",
    nome: "Estornos",
    grupo: "Atendimento · App",
    descricao: "Abrir e acompanhar estornos com justificativa.",
    papeis: ATENDIMENTO,
    areaOperacional: "app",
  },
  {
    id: "atendimento_carteirinhas",
    nome: "Carteirinhas",
    grupo: "Atendimento · App",
    descricao: "Emitir e consultar carteirinhas nas bases Softnex e Metabase.",
    papeis: ATENDIMENTO,
    areaOperacional: "app",
  },
  {
    id: "atendimento_n2",
    nome: "Painel N2",
    grupo: "Atendimento · App",
    descricao: "Ações restritas de engenharia e suporte de segundo nível.",
    papeis: ["admin", "atendimento_n2"],
    areaOperacional: "app_n2",
  },
  {
    id: "auditoria",
    nome: "Auditoria",
    grupo: "Gestão",
    descricao: "Ler a trilha de ações sensíveis. A gravação continua ativa para todos.",
    papeis: ["admin", "gestor"],
  },
  {
    id: "gestor",
    nome: "Painel do Gestor",
    grupo: "Gestão",
    descricao: "Visão consolidada de treinamento e conhecimento do time.",
    papeis: ["admin", "gestor"],
  },
  {
    id: "acessos",
    nome: "Gestão de acessos",
    grupo: "Administração",
    descricao: "Conceder e remover papéis e permissões de operação.",
    papeis: ["admin"],
  },
  {
    id: "conhecimento_escrita",
    nome: "Publicar e treinar a base",
    grupo: "Conhecimento",
    descricao: "Publicar, editar, arquivar, excluir documento e treinar a base de conhecimento.",
    papeis: ["admin"],
  },
];

export function getModulo(id: ModuloOperacional): DefinicaoModulo {
  const m = modulosOperacionais.find((x) => x.id === id);
  if (!m) throw new Error(`Módulo operacional desconhecido: ${id}`);
  return m;
}

/**
 * Única regra de decisão de operação do produto.
 * `areas` são as permissões de operar por área vindas de user_area_access.
 */
export function podeOperar(
  modulo: ModuloOperacional,
  papeis: readonly AppRole[],
  areas?: ReadonlySet<string>,
): boolean {
  const def = getModulo(modulo);
  if (papeis.includes("admin")) return true;
  if (def.papeis.some((p) => papeis.includes(p))) return true;
  if (def.areaOperacional && areas?.has(def.areaOperacional)) return true;
  return false;
}

/** Papéis, na ordem em que aparecem na matriz da tela de acessos. */
export const papeisMatriz: { papel: AppRole; rotulo: string }[] = [
  { papel: "admin", rotulo: "Admin" },
  { papel: "gestor", rotulo: "Gestor" },
  { papel: "atendimento_n2", rotulo: "Atend. N2" },
  { papel: "atendimento_n1", rotulo: "Atend. N1" },
  { papel: "colaborador", rotulo: "Colaborador" },
];

/** Uma célula da matriz: o papel pode operar o módulo? */
export function papelOperaModulo(modulo: ModuloOperacional, papel: AppRole): boolean {
  return podeOperar(modulo, [papel]);
}
