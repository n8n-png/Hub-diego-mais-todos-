/**
 * Mapa de tópicos do assistente: liga palavras-chave da pergunta do colaborador
 * ao lugar da plataforma onde o assunto é resolvido.
 * Conteúdo estático, sem dado pessoal.
 */
export type TopicoNavegacao = {
  palavras: string[];
  titulo: string;
  caminho: string;
  rota: string;
};

export const topicosNavegacao: TopicoNavegacao[] = [
  {
    palavras: [
      "cancelamento",
      "cancelar",
      "debito em aberto",
      "débito em aberto",
      "encerrar conta",
    ],
    titulo: "Cancelamento de conta",
    caminho: "Processos · Cancelamento de conta",
    rota: "/processos",
  },
  {
    palavras: ["boleto", "2a via", "2ª via", "segunda via", "cobranca", "cobrança"],
    titulo: "Emissão de 2ª via de boleto",
    caminho: "Processos · Emissão de 2ª via de boleto",
    rota: "/processos",
  },
  {
    palavras: ["pix", "contestacao", "contestação", "chargeback"],
    titulo: "PIX, contestações",
    caminho: "Base de Conhecimento · PIX, contestações",
    rota: "/base",
  },
  {
    palavras: ["senha", "resetar", "reset", "portal", "login", "trocar senha"],
    titulo: "Reset de senha do portal",
    caminho: "Base de Conhecimento · Reset de senha do portal",
    rota: "/base",
  },
  {
    palavras: ["cadastro", "novo cliente", "cadastrar"],
    titulo: "Cadastro de cliente",
    caminho: "Base de Conhecimento · Cadastro de cliente",
    rota: "/base",
  },
  {
    palavras: ["cartao", "cartão", "bloqueio", "desbloqueio", "bloquear", "desbloquear"],
    titulo: "Bloqueio e desbloqueio de cartão",
    caminho: "Base de Conhecimento · Bloqueio e desbloqueio de cartão",
    rota: "/base",
  },
  {
    palavras: ["cashback", "saldo de cashback", "liberar cashback", "liberacao de cashback"],
    titulo: "Cashback",
    caminho: "Operação · App · Cashback",
    rota: "/atendimento/cashback",
  },
  {
    palavras: ["estorno", "estornar", "reembolso", "devolucao", "devolução"],
    titulo: "Estornos",
    caminho: "Operação · App · Estornos",
    rota: "/atendimento/estornos",
  },
  {
    palavras: [
      "filiado",
      "contato",
      "e-mail",
      "email",
      "telefone",
      "atualizar dados",
      "atualizar contato",
    ],
    titulo: "Gerenciamento de Filiados",
    caminho: "Operação · App · Gerenciamento de Filiados",
    rota: "/atendimento/filiados",
  },
  {
    palavras: ["carteirinha", "carteirinhas", "softnex"],
    titulo: "Carteirinhas",
    caminho: "Operação · App · Carteirinhas",
    rota: "/atendimento/carteirinhas",
  },
  {
    palavras: ["auditoria", "trilha de auditoria", "registro de acoes", "registro de ações", "log"],
    titulo: "Auditoria",
    caminho: "Operação · App · Auditoria",
    rota: "/atendimento/auditoria",
  },
  {
    palavras: ["painel n2", "n2", "escalonamento", "escalar"],
    titulo: "Painel N2",
    caminho: "Operação · App · Painel N2",
    rota: "/atendimento/n2",
  },
  {
    palavras: [
      "acessos",
      "permissao",
      "permissão",
      "permissoes",
      "permissões",
      "papel",
      "papeis",
      "papéis",
      "liberar acesso",
    ],
    titulo: "Gestão de acessos",
    caminho: "Administração · Acessos",
    rota: "/acessos",
  },
];

function normalizar(texto: string) {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/**
 * Casa por palavra inteira, e não por trecho contido, para termo genérico não
 * cair no tópico errado. Expressão com mais de uma palavra casa em sequência.
 */
function combina(alvo: string[], chave: string) {
  const termos = normalizar(chave).split(/\s+/).filter(Boolean);
  if (termos.length === 0) return false;
  for (let i = 0; i <= alvo.length - termos.length; i += 1) {
    if (termos.every((t, j) => alvo[i + j] === t)) return true;
  }
  return false;
}

/** Retorna até `limite` tópicos cujas palavras-chave aparecem na pergunta. */
export function encontrarTopicos(pergunta: string, limite = 3): TopicoNavegacao[] {
  const alvo = normalizar(pergunta)
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
  const pontuados = topicosNavegacao
    .map((t) => {
      const acertos = t.palavras.filter((p) => combina(alvo, p)).length;
      return { t, acertos };
    })
    .filter((x) => x.acertos > 0)
    .sort((a, b) => b.acertos - a.acertos);
  return pontuados.slice(0, limite).map((x) => x.t);
}
