/**
 * Acesso por módulo da Operação.
 * O administrador é global: enxerga e gerencia todas as áreas automaticamente.
 * Para as demais contas, o admin libera área por área.
 * "app_n2" é a liberação extra de engenharia dentro do App.
 */
export const AREAS_ACESSO = [
  "credito-pf",
  "conta-digital",
  "pagamentos",
  "logistica",
  "app",
  "cashback",
  "app_n2",
] as const;

export type AreaAcesso = (typeof AREAS_ACESSO)[number];

export const rotulosAreaAcesso: Record<AreaAcesso, string> = {
  "credito-pf": "Crédito PF",
  "conta-digital": "Conta Digital",
  pagamentos: "Pagamentos",
  logistica: "Logística",
  app: "App",
  cashback: "Cashback",
  app_n2: "App: Painel N2",
};

/** Áreas da Operação, sem a permissão interna do App. */
export const areasOperacaoAcesso = AREAS_ACESSO.filter((a) => a !== "app_n2");
