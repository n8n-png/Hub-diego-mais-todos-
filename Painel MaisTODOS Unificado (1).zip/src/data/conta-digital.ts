/**
 * Operação · Conta Digital.
 * Conteúdo do mapeamento de retornos do fluxo de Onboarding: as 10 etapas,
 * os providers envolvidos, o que pode falhar em cada etapa e a ação de suporte.
 * Fonte: documentação interna "Fluxo de Onboarding, Mapeamento de Retornos", Abril/2026.
 */

import type { FaseLogistica, PassoLogistica } from "@/data/logistica";

export const atualizacaoOnboarding = "Abril de 2026";

export type ProviderOnboarding = {
  nome: string;
  papel: string;
};

export const providersOnboarding: ProviderOnboarding[] = [
  {
    nome: "Certa · CAF",
    papel:
      "Validação de CNPJ (KYB), biometria facial (KYC) e antifraude, com SDK Unico na captura da selfie.",
  },
  {
    nome: "Bankly",
    papel:
      "Criação do perfil bancário pessoal (PF), do perfil empresarial (PJ) e da conta digital, via API e webhooks.",
  },
  {
    nome: "Interno",
    papel:
      "Cadastro na plataforma, upload de documentos no S3, autenticação no Cognito e orquestração dos steps.",
  },
];

export const fasesOnboarding: FaseLogistica[] = [
  { nome: "Validação de identidade e empresa, etapas 1 a 4", tom: "roxo" },
  { nome: "Configuração da estrutura bancária, etapas 5 a 9", tom: "azul" },
  { nome: "Conclusão, etapa 10", tom: "verde" },
];

export const passosOnboarding: PassoLogistica[] = [
  {
    n: 1,
    fase: "Validação de identidade e empresa, etapas 1 a 4",
    responsavel: "Interno",
    titulo: "Cadastro na plataforma",
    caminho: "onboarding_signup",
    descricao:
      "O usuário cria a conta informando dados da empresa e do responsável. A empresa é registrada no banco de dados e o usuário no Cognito.",
    obs: "Se o cadastro falhar, confirme antes se o CNPJ ou o e-mail já existem na base.",
  },
  {
    n: 2,
    fase: "Validação de identidade e empresa, etapas 1 a 4",
    responsavel: "Certa · CAF",
    titulo: "KYB automático",
    caminho: "onboarding_kyb_automatic",
    descricao:
      "A CAF valida o CNPJ e os sócios em bureaus: dados cadastrais, listas de restrição e sanções, enquadramento de CNAE conforme a política da MaisTODOS e identificação de pessoas politicamente expostas.",
    obs: "O resultado orienta a continuidade ou a reprovação do cadastro conforme as regras de compliance.",
    decisao: true,
    saida: "Aprovado segue, reprovado exige regularização do CNPJ",
  },
  {
    n: 3,
    fase: "Validação de identidade e empresa, etapas 1 a 4",
    responsavel: "Interno",
    titulo: "KYB manual, envio de documentos",
    caminho: "onboarding_kyb_manual",
    descricao:
      "O usuário envia os documentos obrigatórios da empresa. A lista varia conforme o tipo societário e os arquivos ficam armazenados no S3.",
    obs: "O step só avança quando o indicador all_documents_uploaded fica verdadeiro.",
  },
  {
    n: 4,
    fase: "Validação de identidade e empresa, etapas 1 a 4",
    responsavel: "Certa · CAF",
    titulo: "KYC, biometria facial",
    caminho: "onboarding_kyc",
    descricao:
      "O responsável faz a selfie e envia o documento de identidade. A CAF valida prova de vida, correspondência entre documento e selfie e leitura OCR.",
    obs: "Limite de 5 tentativas, MAX_ANTIFRAUD_ATTEMPTS igual a 5. Depois disso, só com intervenção manual.",
    decisao: true,
    saida: "Aprovado segue para a estrutura bancária",
  },
  {
    n: 5,
    fase: "Configuração da estrutura bancária, etapas 5 a 9",
    responsavel: "Bankly",
    titulo: "Verificação de conta existente",
    caminho: "onboarding_verify_bank_account_already_exists",
    descricao:
      "O sistema consulta no Bankly se o CPF do responsável e o CNPJ da empresa já possuem perfil ou conta bancária.",
    obs: "O resultado é uma matriz de combinações entre personal_status e business_status, gravada em banking_webhook_response.",
  },
  {
    n: 6,
    fase: "Configuração da estrutura bancária, etapas 5 a 9",
    responsavel: "Bankly",
    titulo: "Perfil bancário pessoal criado",
    caminho: "receive_notification_personal_bank_profile_created",
    descricao: "Retorno do Bankly, por webhook, sobre a criação do perfil pessoal do responsável.",
    obs: "Reprovação chega como event_type igual a REPROVED, com um código de motivo.",
  },
  {
    n: 7,
    fase: "Configuração da estrutura bancária, etapas 5 a 9",
    responsavel: "Interno e Bankly",
    titulo: "Envio dos dados do perfil empresarial",
    caminho: "send_business_bank_profile_for_creation",
    descricao:
      "A plataforma chama a API do Bankly com os dados da empresa para criar o perfil empresarial.",
    obs: "Os campos obrigatórios mudam conforme o tipo societário, MEI ou LTDA.",
  },
  {
    n: 8,
    fase: "Configuração da estrutura bancária, etapas 5 a 9",
    responsavel: "Bankly",
    titulo: "Perfil bancário empresarial criado",
    caminho: "receive_notification_business_bank_profile_created",
    descricao: "Retorno do Bankly confirmando, ou reprovando, a criação do perfil da empresa.",
  },
  {
    n: 9,
    fase: "Configuração da estrutura bancária, etapas 5 a 9",
    responsavel: "Bankly",
    titulo: "Conta bancária criada",
    caminho: "receive_notification_bank_account_created",
    descricao: "Retorno do Bankly com a criação da conta digital.",
    obs: "Pré-requisito: perfis PF e PJ aprovados e o evento ACCOUNT_HOLDER_WAS_CREATED confirmado.",
  },
  {
    n: 10,
    fase: "Conclusão, etapa 10",
    responsavel: "Interno",
    titulo: "Onboarding finalizado",
    caminho: "onboarding_finished",
    descricao:
      "Com todas as etapas aprovadas, o onboarding é concluído e a conta do cliente é ativada.",
    obs: "Não há falhas próprias aqui. Problema nesta etapa costuma indicar falha anterior não detectada.",
  },
];

export const documentosPorTipo = [
  {
    tipo: "Pjotinha, por exemplo MEI",
    itens: [
      "Cartão CNPJ",
      "Contrato social ou declaração de abertura da empresa",
      "Comprovante de endereço",
    ],
  },
  {
    tipo: "PJotão, por exemplo LTDA",
    itens: [
      "Cartão CNPJ",
      "Contrato social",
      "Comprovante de endereço",
      "Alteração contratual, quando houver",
    ],
  },
  {
    tipo: "Assinatura por procurador",
    itens: ["Todos os documentos do tipo societário", "Procuração do responsável"],
  },
];

export type RetornoEtapa = {
  situacao: string;
  causa: string;
  usuarioVe: string;
  ondeVerificar: string;
  acao: string;
  escalar: string;
};

export type EtapaRetornos = {
  slug: string;
  titulo: string;
  provider: string;
  contexto: string;
  alerta?: string;
  retornos: RetornoEtapa[];
};

export const retornosOnboarding: EtapaRetornos[] = [
  {
    slug: "cadastro",
    titulo: "Etapa 1 · Cadastro",
    provider: "Interno",
    contexto:
      "Criação da empresa e do usuário responsável na plataforma, com registro no banco de dados e no Cognito.",
    retornos: [
      {
        situacao: "has_failed igual a true",
        causa: "Erro na criação da empresa ou do usuário, no Cognito ou no banco de dados",
        usuarioVe: "Não consegue concluir a criação da conta",
        ondeVerificar: "company_step com status failed, mais os logs do Cognito",
        acao: "Confirmar se o CNPJ ou o e-mail já estão cadastrados e orientar nova tentativa",
        escalar: "Sim, se persistir após a nova tentativa",
      },
    ],
  },
  {
    slug: "kyb-automatico",
    titulo: "Etapa 2 · KYB automático",
    provider: "Certa · CAF",
    contexto:
      "Validação automática do CNPJ e dos sócios em bureaus, com checagem de listas de restrição, CNAE e PEP.",
    retornos: [
      {
        situacao: "CAFStatus.REPROVED",
        causa: "CNPJ inapto, irregular ou inativo na Receita Federal",
        usuarioVe: "Step travado, sem mensagem clara",
        ondeVerificar: "antifraud_response",
        acao: "Orientar a regularização do CNPJ na Receita Federal e confirmar se o número informado está correto",
        escalar: "Sim, se o CNPJ estiver regular e a reprovação continuar",
      },
      {
        situacao: "CAFStatus.PROCESSING ou PENDING prolongado",
        causa: "Certa em análise ou indisponível",
        usuarioVe: "Step não avança e nenhum erro aparece",
        ondeVerificar: "antifraud_response, campo status",
        acao: "Aguardar o SLA da Certa",
        escalar: "Sim, se não houver retorno em 24 horas",
      },
    ],
  },
  {
    slug: "kyb-manual",
    titulo: "Etapa 3 · Envio de documentos",
    provider: "Interno, armazenamento S3",
    contexto:
      "Upload dos documentos obrigatórios da empresa, com lista definida pelo tipo societário.",
    retornos: [
      {
        situacao: "all_documents_uploaded permanece false",
        causa: "Faltam documentos obrigatórios",
        usuarioVe: "Step em IN_PROGRESS, sem avançar",
        ondeVerificar: "company, documentos no S3",
        acao: "Listar para o cliente quais documentos faltam conforme o tipo societário e orientar o envio",
        escalar: "Sim, se os documentos estiverem presentes e o step não avançar",
      },
      {
        situacao: "Upload falha em silêncio",
        causa: "Problema no S3, arquivo corrompido ou formato inválido",
        usuarioVe: "Envia o arquivo, mas o sistema não reconhece",
        ondeVerificar: "Bucket S3 e company_step.response_history",
        acao: "Verificar se o arquivo chegou ao S3 e solicitar o reenvio",
        escalar: "Sim, se o S3 estiver acessível e o arquivo for válido",
      },
      {
        situacao: "Documento falso aceito",
        causa: "Não existe verificação de autenticidade no upload, lacuna já documentada",
        usuarioVe: "Nada, é uma falha silenciosa",
        ondeVerificar: "Sem ponto de verificação",
        acao: "Sem ação de suporte disponível, o risco está registrado com Prevenção",
        escalar: "Risco registrado em PE Prevenção",
      },
    ],
  },
  {
    slug: "kyc",
    titulo: "Etapa 4 · Biometria e KYC",
    provider: "Certa · CAF, integração Unico",
    contexto:
      "Selfie com prova de vida, comparação com o documento de identidade e leitura OCR do documento.",
    alerta:
      "O sistema permite no máximo 5 tentativas de biometria, MAX_ANTIFRAUD_ATTEMPTS igual a 5. Depois desse limite, a liberação de novas tentativas exige intervenção manual do time de Prevenção.",
    retornos: [
      {
        situacao: "CAFStatus.REPROVED",
        causa: "Falha na prova de vida, divergência entre documento e selfie ou OCR sem leitura",
        usuarioVe: "Step FAILED, cliente bloqueado na etapa",
        ondeVerificar: "antifraud_response",
        acao: "Orientar boa iluminação, sem óculos, documento legível e sem reflexo. O cliente pode tentar novamente",
        escalar: "Sim, a partir de 3 reprovações consecutivas",
      },
      {
        situacao: "5 tentativas esgotadas",
        causa: "Limite MAX_ANTIFRAUD_ATTEMPTS atingido",
        usuarioVe: "Não consegue mais iniciar a biometria",
        ondeVerificar: "company_step.response_history, contando as entradas",
        acao: "Informar o cliente sem detalhar o motivo técnico",
        escalar: "Sempre, Prevenção avalia e pode liberar novas tentativas",
      },
      {
        situacao: "Certa ou Unico indisponível",
        causa: "Provider fora do ar",
        usuarioVe: "Biometria não inicia ou trava, sem mensagem",
        ondeVerificar: "Página de status da Certa e da Unico",
        acao: "Aguardar o retorno do provider e comunicar o cliente sobre a instabilidade",
        escalar: "Sim, se a indisponibilidade passar de 2 horas",
      },
    ],
  },
  {
    slug: "verificacao-conta",
    titulo: "Etapa 5 · Verificação de conta existente",
    provider: "Bankly",
    contexto:
      "Consulta no Bankly para saber se o CPF do responsável e o CNPJ da empresa já têm perfil ou conta.",
    retornos: [
      {
        situacao: "personal igual a reproved e business igual a not_found",
        causa: "Pessoa física reprovada no Bankly e empresa sem conta existente",
        usuarioVe: "Step FAILED",
        ondeVerificar: "banking_webhook_response",
        acao: "Verificar o status da PF no Bankly, pode ser necessário novo cadastro da pessoa física",
        escalar: "Sim, se a PF estiver aprovada e a falha continuar",
      },
      {
        situacao: "personal igual a approved e business igual a reproved",
        causa: "Pessoa física aprovada, empresa reprovada no Bankly",
        usuarioVe: "Step FAILED",
        ondeVerificar: "banking_webhook_response",
        acao: "Identificar o código de reprovação da PJ e seguir a orientação da tabela de motivos",
        escalar: "Sim, quando o motivo não permitir nova tentativa",
      },
    ],
  },
  {
    slug: "perfis-e-conta",
    titulo: "Etapas 6 a 9 · Perfis e conta no Bankly",
    provider: "Bankly",
    contexto:
      "Criação do perfil pessoal, do perfil empresarial e da conta digital, por API e webhooks do Bankly.",
    retornos: [
      {
        situacao: "Etapa 6, event_type igual a REPROVED",
        causa: "Bankly reprovou o perfil pessoal",
        usuarioVe: "Step FAILED",
        ondeVerificar: "banking_webhook_response",
        acao: "Consultar o código na tabela de motivos. Se permitir nova tentativa, orientar a correção dos dados",
        escalar: "Conforme o motivo",
      },
      {
        situacao: "Etapa 7, error na resposta",
        causa: "Falha na chamada de API para o Bankly",
        usuarioVe: "Step não avança",
        ondeVerificar: "banking_webhook_response e payload enviado",
        acao: "Revisar o payload e os campos obrigatórios do tipo societário, MEI ou LTDA",
        escalar: "Sim, se o payload estiver correto",
      },
      {
        situacao: "Etapa 8, event_type igual a REPROVED",
        causa: "Bankly reprovou o perfil empresarial",
        usuarioVe: "Step FAILED",
        ondeVerificar: "banking_webhook_response",
        acao: "Consultar o código na tabela de motivos",
        escalar: "Conforme o motivo",
      },
      {
        situacao: "Etapa 9, event_type igual a REPROVED",
        causa: "Bankly não criou a conta",
        usuarioVe: "Conta não é ativada",
        ondeVerificar: "banking_webhook_response",
        acao: "Conferir os pré-requisitos: PF e PJ aprovadas e evento ACCOUNT_HOLDER_WAS_CREATED confirmado",
        escalar: "Sim, com pré-requisitos atendidos",
      },
    ],
  },
  {
    slug: "finalizacao",
    titulo: "Etapa 10 · Finalização",
    provider: "Interno",
    contexto: "Conclusão do onboarding e ativação da conta do cliente.",
    retornos: [
      {
        situacao: "Onboarding não conclui",
        causa: "Falha em etapa anterior não detectada",
        usuarioVe: "Conta não fica ativa",
        ondeVerificar: "Histórico de company_step das etapas 1 a 9",
        acao: "Revisar a última etapa com status diferente de aprovado e tratar por ela",
        escalar: "Sim, se todas as etapas estiverem aprovadas e a conta seguir inativa",
      },
    ],
  },
];

export type MotivoBankly = { codigo: string; descricao: string; acao: string };

export type GrupoMotivos = {
  slug: string;
  titulo: string;
  tom: "corrigivel" | "bloqueio" | "escalavel";
  resumo: string;
  motivos: MotivoBankly[];
};

export const motivosBankly: GrupoMotivos[] = [
  {
    slug: "corrigivel",
    titulo: "Pode corrigir e tentar novamente",
    tom: "corrigivel",
    resumo: "O cliente ajusta o dado ou o envio e a etapa aceita nova tentativa.",
    motivos: [
      {
        codigo: "SELFIE_RECUSED",
        descricao: "Selfie falhou na prova de vida",
        acao: "Orientar reenvio com boa iluminação e sem óculos",
      },
      {
        codigo: "DOCUMENT_RECUSED",
        descricao: "Divergência entre documento e selfie",
        acao: "Solicitar reenvio do documento correto",
      },
      {
        codigo: "OCR_RECUSED",
        descricao: "Falha na leitura do documento",
        acao: "Pedir reenvio com melhor qualidade de imagem",
      },
      {
        codigo: "AGE_RECUSED",
        descricao: "Menor de 18 anos ou data de nascimento divergente",
        acao: "Orientar correção da data de nascimento",
      },
      {
        codigo: "NAME_RECUSED",
        descricao: "Nome divergente",
        acao: "Orientar correção do nome cadastrado",
      },
      {
        codigo: "PHOTO_RECUSED",
        descricao: "Imagem de baixa qualidade",
        acao: "Solicitar reenvio com melhor resolução",
      },
      {
        codigo: "DATA_RECUSED",
        descricao: "Dados cadastrais divergentes",
        acao: "Orientar correção dos dados gerais",
      },
      {
        codigo: "INCOMPLETE_DOCUMENTATION",
        descricao: "Documentos faltando",
        acao: "Orientar o envio dos documentos ausentes",
      },
      {
        codigo: "FORBIDDEN_WORDS",
        descricao: "Linguagem ofensiva em campos de texto",
        acao: "Orientar correção dos campos de texto",
      },
    ],
  },
  {
    slug: "bloqueio",
    titulo: "Bloqueio definitivo, não permite reenvio",
    tom: "bloqueio",
    resumo: "Sem caminho de retentativa. Comunicar o cliente com clareza e sem detalhe técnico.",
    motivos: [
      {
        codigo: "NOT_RETRY",
        descricao: "CPF marcado como fraude",
        acao: "Bloqueio definitivo, sem ação de suporte",
      },
      {
        codigo: "NOT_ALLOWED",
        descricao: "Parceiro sem acesso contratual",
        acao: "Acionar o contato comercial com o Bankly",
      },
      {
        codigo: "EMAIL_RECUSED",
        descricao: "E-mail associado a fraude",
        acao: "Bloqueio definitivo",
      },
      {
        codigo: "RISKY_BEHAVIOR",
        descricao: "Alto risco de fraude identificado",
        acao: "Bloqueio definitivo",
      },
      {
        codigo: "INTERNAL_POLICY",
        descricao: "Restrição regulatória de KYC e PLD, Banco Central",
        acao: "Bloqueio definitivo",
      },
      {
        codigo: "DOCUMENT_RESTRICTED",
        descricao: "CPF ou CNPJ restrito no SCRC, BCB 475/2025",
        acao: "Bloqueio definitivo",
      },
      {
        codigo: "INCORRECT_CNPJ",
        descricao: "CNPJ inapto, irregular ou baixado",
        acao: "Orientar regularização na Receita Federal antes de nova tentativa",
      },
      {
        codigo: "STATUS_RECUSED",
        descricao: "CPF irregular na Receita Federal",
        acao: "Orientar regularização do CPF na Receita Federal",
      },
    ],
  },
  {
    slug: "escalavel",
    titulo: "Acionar o Service Desk do Bankly",
    tom: "escalavel",
    resumo: "Casos que dependem de análise do parceiro bancário.",
    motivos: [
      {
        codigo: "NOT_FOUND",
        descricao: "CPF não encontrado nos bureaus de dados",
        acao: "Abrir chamado no Service Desk do Bankly",
      },
      {
        codigo: "PEP_RECUSED",
        descricao: "Pessoa politicamente exposta",
        acao: "Abrir chamado no Service Desk do Bankly",
      },
    ],
  },
];

export const acoesRapidas = [
  {
    categoria: "Corrigível",
    tom: "corrigivel" as const,
    exemplo: "Selfie ou documento recusado",
    acao: "Orientar reenvio com melhor iluminação e qualidade.",
  },
  {
    categoria: "Bloqueio",
    tom: "bloqueio" as const,
    exemplo: "CPF ou e-mail marcado como fraude",
    acao: "Bloqueio definitivo, sem ação de suporte disponível.",
  },
  {
    categoria: "Escalável",
    tom: "escalavel" as const,
    exemplo: "Erro de API ou pessoa politicamente exposta",
    acao: "Abrir chamado no Service Desk do Bankly ou com o time interno.",
  },
];

export const cadeiaDecisoes = [
  {
    validacao: "KYB automático",
    sistema: "Certa",
    dado: "CNPJ e bureaus",
    grava: "antifraud_response",
    avaliacao: "_antifraud_evaluator, resultado em CAFStatus",
  },
  {
    validacao: "KYB manual",
    sistema: "Interno",
    dado: "Arquivos no S3",
    grava: "company, documentos",
    avaliacao: "onboarding_kyb_manual_evaluator, indicador all_documents_uploaded",
  },
  {
    validacao: "KYC biometria",
    sistema: "Certa",
    dado: "CPF, documento e selfie",
    grava: "antifraud_response",
    avaliacao: "_antifraud_evaluator, resultado em CAFStatus",
  },
  {
    validacao: "Perfil pessoal",
    sistema: "Bankly, webhook",
    dado: "Cadastro da pessoa física",
    grava: "banking_webhook_response",
    avaliacao: "event_type APPROVED ou REPROVED",
  },
  {
    validacao: "Perfil empresarial",
    sistema: "Bankly, API e webhook",
    dado: "Cadastro da pessoa jurídica",
    grava: "banking_webhook_response",
    avaliacao: "message Success e event_type",
  },
  {
    validacao: "Conta bancária",
    sistema: "Bankly, webhook",
    dado: "Criação da conta",
    grava: "banking_webhook_response",
    avaliacao: "event_type CREATED ou REPROVED",
  },
  {
    validacao: "Verificação de conta",
    sistema: "Bankly",
    dado: "personal_status e business_status",
    grava: "banking_webhook_response",
    avaliacao: "Matriz de combinações, ver etapa 5",
  },
];

export const glossarioOnboarding = [
  { termo: "KYB", significado: "Know Your Business, verificação de identidade de uma empresa" },
  {
    termo: "KYC",
    significado: "Know Your Customer, verificação de identidade de uma pessoa física",
  },
  {
    termo: "CAF",
    significado: "Customer Authentication Framework, plataforma da Certa usada nas validações",
  },
  {
    termo: "CAFStatus",
    significado: "Status devolvido pela Certa: APPROVED, REPROVED, PROCESSING ou PENDING",
  },
  { termo: "Certa", significado: "Provider de antifraude e validação de identidade" },
  { termo: "Unico", significado: "SDK de biometria integrado à Certa para captura da selfie" },
  {
    termo: "Bankly",
    significado: "Plataforma bancária como serviço, responsável por perfis e contas",
  },
  { termo: "Cognito", significado: "Serviço AWS de autenticação de usuários" },
  { termo: "S3", significado: "Serviço AWS de armazenamento dos documentos do onboarding" },
];
