/**
 * DADOS FICTÍCIOS (MOCK) · área de Atendimento.
 *
 * Nada aqui vem de sistema real. Os filiados abaixo existem apenas para
 * validar a interface e o fluxo de ação sensível.
 *
 * FASE 2: a integração real (Softnex, Cashback, Estornos, Metabase) será feita
 * exclusivamente via proxy server-side com createServerFn. O browser nunca
 * chama API de parceiro direto, e CPF, e-mail e telefone sempre trafegam
 * mascarados na tela, conforme LGPD.
 */

export type FiliadoContato = {
  email: string | null;
  telefone: string | null;
};

export type Filiado = {
  cpf: string;
  nome: string;
  nascimento: string;
  status: "ativo" | "inadimplente" | "cancelado";
  plano: string;
  matricula: string;
  cidade: string;
  uf: string;
  desde: string;
  carteirinha: "emitida" | "pendente" | "sem emissão";
  contato: FiliadoContato;
};

/** Somente dígitos, aceita CPF com ou sem máscara. */
export function somenteDigitos(valor: string): string {
  return valor.replace(/\D/g, "");
}

/** Aplica a máscara 000.000.000-00 progressivamente. */
export function mascararCpf(valor: string): string {
  const d = somenteDigitos(valor).slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return `${d.slice(0, 3)}.${d.slice(3)}`;
  if (d.length <= 9) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6)}`;
  return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;
}

export function cpfCompleto(valor: string): boolean {
  return somenteDigitos(valor).length === 11;
}

/** Mascaramento LGPD para exibição: ***.***.**8-00 */
export function cpfProtegido(cpf: string): string {
  const d = somenteDigitos(cpf);
  if (d.length !== 11) return cpf;
  return `***.***.**${d.slice(8, 9)}-${d.slice(9)}`;
}

export function emailProtegido(email: string | null): string {
  if (!email) return "não cadastrado";
  const [usuario, dominio] = email.split("@");
  if (!dominio) return email;
  const visivel = usuario.slice(0, 2);
  return `${visivel}${"*".repeat(Math.max(usuario.length - 2, 2))}@${dominio}`;
}

export function telefoneProtegido(telefone: string | null): string {
  if (!telefone) return "não cadastrado";
  const d = somenteDigitos(telefone);
  if (d.length < 8) return telefone;
  return `(${d.slice(0, 2)}) *****-${d.slice(-4)}`;
}

const CAMPOS_PESSOAIS = /(cpf|documento|e-?mail|telefone|phone|celular)/i;

/**
 * Percorre qualquer payload e mascara os campos cujo nome indica dado pessoal.
 * Usada antes de gravar e antes de exibir a auditoria, para que nenhum módulo
 * precise lembrar do mascaramento por conta própria.
 */
export function sanitizarPayloadAuditoria(payload: unknown): unknown {
  function mascarar(chave: string, valor: unknown): unknown {
    if (typeof valor !== "string" || valor.trim() === "") return valor;
    if (/(cpf|documento)/i.test(chave)) return cpfProtegido(valor);
    if (/e-?mail/i.test(chave)) return emailProtegido(valor);
    if (/(telefone|phone|celular)/i.test(chave)) return telefoneProtegido(valor);
    return valor;
  }

  function percorrer(valor: unknown): unknown {
    if (Array.isArray(valor)) return valor.map(percorrer);
    if (valor && typeof valor === "object") {
      const saida: Record<string, unknown> = {};
      for (const [chave, item] of Object.entries(valor as Record<string, unknown>)) {
        saida[chave] = CAMPOS_PESSOAIS.test(chave)
          ? mascarar(chave, percorrer(item))
          : percorrer(item);
      }
      return saida;
    }
    return valor;
  }

  return percorrer(payload);
}

/**
 * Higieniza texto livre, trocando dados pessoais por marcadores.
 *
 * Usada em dois momentos: antes de gravar em banco e antes de qualquer saída
 * para serviço externo de IA. A ordem das trocas importa: documentos mais
 * longos vêm primeiro, para que um CNPJ não seja lido como CPF.
 */
export function higienizarTextoLivre(texto: string): string {
  return (
    texto
      // RG vem primeiro, porque depende do rótulo antes do número.
      .replace(/\b(?:rg|identidade)\b[:\s]*[\d.\-/]{7,14}/gi, "[rg]")
      .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, "[email]")
      // CNPJ: 00.000.000/0000-00 ou 14 dígitos seguidos.
      .replace(/(?<!\d)\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}(?!\d)/g, "[cnpj]")
      // Cartão: 13 a 19 dígitos, com espaço, ponto ou hífen entre grupos.
      .replace(/(?<!\d)(?:\d[ .-]?){12,18}\d(?!\d)/g, (t) => {
        const d = t.replace(/\D/g, "");
        return d.length >= 13 && d.length <= 19 ? "[cartao]" : t;
      })
      // CPF com máscara ou 11 dígitos, sem casar dentro de sequência maior.
      .replace(/(?<!\d)\d{3}\.?\d{3}\.?\d{3}-?\d{2}(?!\d)/g, "[cpf]")
      .replace(/(?<!\d)(?:\+?55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}(?!\d)/g, "[telefone]")
      // Data de nascimento e datas em geral.
      .replace(/(?<!\d)\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}(?!\d)/g, "[data]")
      .replace(/(?<!\d)\d{4}-\d{2}-\d{2}(?!\d)/g, "[data]")
      // CEP: 00000-000 ou 00000000.
      .replace(/(?<!\d)\d{5}-?\d{3}(?!\d)/g, "[cep]")
  );
}

/** Base fictícia de teste. Use estes CPFs na busca. */
export const filiadosMock: Filiado[] = [
  {
    cpf: "12345678909",
    nome: "Ana Beatriz Marques",
    nascimento: "14/03/1991",
    status: "ativo",
    plano: "MaisTODOS Saúde Família",
    matricula: "MT-004512",
    cidade: "Belo Horizonte",
    uf: "MG",
    desde: "08/2022",
    carteirinha: "emitida",
    contato: { email: "ana.marques@exemplo.com.br", telefone: "31988776655" },
  },
  {
    cpf: "98765432100",
    nome: "Carlos Eduardo Nogueira",
    nascimento: "02/11/1985",
    status: "inadimplente",
    plano: "MaisTODOS Saúde Individual",
    matricula: "MT-009877",
    cidade: "Contagem",
    uf: "MG",
    desde: "01/2023",
    carteirinha: "pendente",
    contato: { email: "carlos.nogueira@exemplo.com.br", telefone: "31997654321" },
  },
  {
    cpf: "11144477735",
    nome: "Juliana Ferreira Lopes",
    nascimento: "27/07/1996",
    status: "ativo",
    plano: "MaisTODOS Odonto Plus",
    matricula: "MT-014203",
    cidade: "Uberlândia",
    uf: "MG",
    desde: "05/2024",
    carteirinha: "emitida",
    contato: { email: "juliana.lopes@exemplo.com.br", telefone: null },
  },
  {
    cpf: "52998224725",
    nome: "Rodrigo Alves Pinheiro",
    nascimento: "19/01/1979",
    status: "cancelado",
    plano: "MaisTODOS Saúde Família",
    matricula: "MT-002190",
    cidade: "Betim",
    uf: "MG",
    desde: "03/2021",
    carteirinha: "sem emissão",
    contato: { email: null, telefone: "31991122334" },
  },
];

/** Busca fictícia por CPF, aceita com ou sem máscara. */
export function buscarFiliadoMock(cpf: string): Filiado | null {
  const d = somenteDigitos(cpf);
  return filiadosMock.find((f) => f.cpf === d) ?? null;
}

/**
 * Formato ÚNICO de status do Atendimento: rótulo mais classe de cor.
 * Todo mapa de status mora neste arquivo e devolve este formato, consumido
 * pelo componente BadgeStatus. Nenhuma rota declara mapa próprio.
 */
export type EstadoVisual = { label: string; classe: string };

export const statusFiliado: Record<Filiado["status"], EstadoVisual> = {
  ativo: { label: "Ativo", classe: "bg-success/10 text-success border-success/30" },
  inadimplente: {
    label: "Inadimplente",
    classe: "bg-accent text-accent-foreground border-border-strong",
  },
  cancelado: { label: "Cancelado", classe: "bg-muted text-muted-foreground border-border-strong" },
};

/* ------------------------------------------------------------------ *
 * CASHBACK (MOCK) · Fonte: Solatio ProspectorAPI/Cashback.
 * Indexado pelos mesmos 4 CPFs da base fictícia acima.
 * ------------------------------------------------------------------ */

export type CashbackStatus = "Pending" | "Authorized" | "Expired" | "Dead" | "Canceled";

export type LancamentoCashback = {
  id: string;
  data: string; // ISO, aaaa-mm-dd
  descricao: string;
  valor: number;
  status: CashbackStatus;
  liquidacao: string | null;
  autorizado: boolean;
};

export const statusCashback: Record<CashbackStatus, EstadoVisual> = {
  Pending: { label: "Pending", classe: "bg-accent text-accent-foreground border-border-strong" },
  Authorized: { label: "Authorized", classe: "bg-success/10 text-success border-success/30" },
  Expired: { label: "Expired", classe: "bg-muted text-muted-foreground border-border-strong" },
  Dead: { label: "Dead", classe: "bg-muted text-muted-foreground border-border-strong" },
  Canceled: {
    label: "Canceled",
    classe: "bg-destructive/10 text-destructive border-destructive/30",
  },
};

export const cashbackMock: Record<string, LancamentoCashback[]> = {
  "12345678909": [
    {
      id: "CB-8801",
      data: "2026-01-12",
      descricao: "Compra Farmácia Popular",
      valor: 18.4,
      status: "Authorized",
      liquidacao: "2026-01-20",
      autorizado: true,
    },
    {
      id: "CB-8817",
      data: "2026-02-03",
      descricao: "Consulta Clínica Vida",
      valor: 32.9,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-8829",
      data: "2026-02-19",
      descricao: "Exame laboratorial",
      valor: 12.75,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-8840",
      data: "2026-03-07",
      descricao: "Ótica Bem Ver",
      valor: 45.0,
      status: "Expired",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-8856",
      data: "2026-03-22",
      descricao: "Drogaria Central",
      valor: 9.6,
      status: "Authorized",
      liquidacao: "2026-03-30",
      autorizado: true,
    },
    {
      id: "CB-8871",
      data: "2026-04-11",
      descricao: "Odonto Sorriso",
      valor: 27.3,
      status: "Canceled",
      liquidacao: null,
      autorizado: false,
    },
  ],
  "98765432100": [
    {
      id: "CB-9012",
      data: "2026-01-05",
      descricao: "Compra Supermercado Rede",
      valor: 22.15,
      status: "Dead",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-9033",
      data: "2026-01-28",
      descricao: "Farmácia São João",
      valor: 14.8,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-9048",
      data: "2026-02-14",
      descricao: "Consulta cardiologia",
      valor: 60.0,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-9060",
      data: "2026-03-02",
      descricao: "Exame de imagem",
      valor: 38.5,
      status: "Expired",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-9074",
      data: "2026-03-25",
      descricao: "Drogaria Preço Bom",
      valor: 7.9,
      status: "Authorized",
      liquidacao: "2026-04-02",
      autorizado: true,
    },
    {
      id: "CB-9090",
      data: "2026-04-18",
      descricao: "Fisioterapia Movimento",
      valor: 41.2,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-9101",
      data: "2026-05-06",
      descricao: "Laboratório Análise",
      valor: 16.35,
      status: "Canceled",
      liquidacao: null,
      autorizado: false,
    },
  ],
  "11144477735": [
    {
      id: "CB-7701",
      data: "2026-02-08",
      descricao: "Odonto Plus limpeza",
      valor: 25.0,
      status: "Authorized",
      liquidacao: "2026-02-16",
      autorizado: true,
    },
    {
      id: "CB-7715",
      data: "2026-02-27",
      descricao: "Farmácia Vida Nova",
      valor: 11.45,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-7728",
      data: "2026-03-15",
      descricao: "Clareamento dental",
      valor: 78.9,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-7741",
      data: "2026-04-02",
      descricao: "Raio X panorâmico",
      valor: 19.7,
      status: "Expired",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-7759",
      data: "2026-04-29",
      descricao: "Drogaria Popular",
      valor: 6.25,
      status: "Dead",
      liquidacao: null,
      autorizado: false,
    },
  ],
  "52998224725": [
    {
      id: "CB-6604",
      data: "2025-11-14",
      descricao: "Consulta ortopedia",
      valor: 55.0,
      status: "Canceled",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-6619",
      data: "2025-12-03",
      descricao: "Farmácia Bem Estar",
      valor: 13.1,
      status: "Expired",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-6630",
      data: "2025-12-21",
      descricao: "Exame de sangue",
      valor: 21.4,
      status: "Dead",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-6647",
      data: "2026-01-09",
      descricao: "Drogaria Saúde Total",
      valor: 8.75,
      status: "Pending",
      liquidacao: null,
      autorizado: false,
    },
    {
      id: "CB-6658",
      data: "2026-01-30",
      descricao: "Consulta dermatologia",
      valor: 47.6,
      status: "Authorized",
      liquidacao: "2026-02-07",
      autorizado: true,
    },
  ],
};

export function buscarCashbackMock(cpf: string): LancamentoCashback[] {
  return cashbackMock[somenteDigitos(cpf)] ?? [];
}

/* ------------------------------------------------------------------ *
 * ESTORNOS (MOCK) · transações elegíveis, Wallet e Pedido CDT.
 * ------------------------------------------------------------------ */

export type OrigemTransacao = "Wallet" | "Pedido CDT";

export type SituacaoTransacao = "Liquidada" | "Autorizada" | "Estorno solicitado" | "Estornada";

export type TransacaoEstorno = {
  id: string;
  data: string;
  descricao: string;
  valor: number;
  origem: OrigemTransacao;
  situacao: SituacaoTransacao;
  /** Presente quando a origem é Pedido CDT: identifica o pedido e a unidade. */
  pedido?: string;
  unidade?: string;
};

export const situacaoTransacao: Record<SituacaoTransacao, EstadoVisual> = {
  Liquidada: {
    label: "Liquidada",
    classe: "bg-accent text-accent-foreground border-border-strong",
  },
  Autorizada: {
    label: "Autorizada",
    classe: "bg-accent text-accent-foreground border-border-strong",
  },
  "Estorno solicitado": {
    label: "Estorno solicitado",
    classe: "bg-success/10 text-success border-success/30",
  },
  Estornada: {
    label: "Estornada",
    classe: "bg-muted text-muted-foreground border-border-strong",
  },
};

export const estornosMock: Record<string, TransacaoEstorno[]> = {
  "12345678909": [
    {
      id: "TX-4410-AB",
      data: "2026-04-12",
      descricao: "Recarga de carteira",
      valor: 120.0,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "TX-4432-CD",
      data: "2026-04-20",
      descricao: "Pagamento mensalidade",
      valor: 89.9,
      origem: "Wallet",
      situacao: "Autorizada",
    },
    {
      id: "PD-77120",
      data: "2026-05-03",
      descricao: "Pedido de cartão adicional",
      valor: 24.5,
      origem: "Pedido CDT",
      situacao: "Liquidada",
      pedido: "77120",
      unidade: "BH-CENTRO",
    },
    {
      id: "PD-77188",
      data: "2026-05-19",
      descricao: "Pedido kit boas-vindas",
      valor: 15.0,
      origem: "Pedido CDT",
      situacao: "Liquidada",
      pedido: "77188",
      unidade: "BH-CENTRO",
    },
    {
      id: "TX-4501-EF",
      data: "2026-06-02",
      descricao: "Compra em rede parceira",
      valor: 63.75,
      origem: "Wallet",
      situacao: "Autorizada",
    },
  ],
  "98765432100": [
    {
      id: "TX-5102-GH",
      data: "2026-03-11",
      descricao: "Pagamento mensalidade",
      valor: 74.9,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "TX-5140-IJ",
      data: "2026-04-08",
      descricao: "Taxa de segunda via",
      valor: 12.0,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "PD-81044",
      data: "2026-04-25",
      descricao: "Pedido de carteirinha física",
      valor: 19.9,
      origem: "Pedido CDT",
      situacao: "Autorizada",
      pedido: "81044",
      unidade: "CONTAGEM-01",
    },
    {
      id: "TX-5199-KL",
      data: "2026-05-17",
      descricao: "Recarga de carteira",
      valor: 50.0,
      origem: "Wallet",
      situacao: "Estornada",
    },
  ],
  "11144477735": [
    {
      id: "TX-6203-MN",
      data: "2026-04-04",
      descricao: "Pagamento mensalidade Odonto",
      valor: 49.9,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "PD-90311",
      data: "2026-04-21",
      descricao: "Pedido de cartão dependente",
      valor: 22.0,
      origem: "Pedido CDT",
      situacao: "Liquidada",
      pedido: "90311",
      unidade: "UDI-02",
    },
    {
      id: "TX-6250-OP",
      data: "2026-05-09",
      descricao: "Compra em rede parceira",
      valor: 31.4,
      origem: "Wallet",
      situacao: "Autorizada",
    },
    {
      id: "PD-90388",
      data: "2026-05-28",
      descricao: "Pedido kit odonto",
      valor: 18.6,
      origem: "Pedido CDT",
      situacao: "Liquidada",
      pedido: "90388",
      unidade: "UDI-02",
    },
    {
      id: "TX-6299-QR",
      data: "2026-06-14",
      descricao: "Recarga de carteira",
      valor: 80.0,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "TX-6310-ST",
      data: "2026-06-27",
      descricao: "Taxa de reemissão",
      valor: 9.9,
      origem: "Wallet",
      situacao: "Autorizada",
    },
  ],
  "52998224725": [
    {
      id: "TX-7005-UV",
      data: "2025-12-06",
      descricao: "Pagamento mensalidade",
      valor: 92.5,
      origem: "Wallet",
      situacao: "Estornada",
    },
    {
      id: "TX-7031-WX",
      data: "2026-01-15",
      descricao: "Taxa de cancelamento",
      valor: 35.0,
      origem: "Wallet",
      situacao: "Liquidada",
    },
    {
      id: "PD-64010",
      data: "2026-01-22",
      descricao: "Pedido de segunda via",
      valor: 19.9,
      origem: "Pedido CDT",
      situacao: "Liquidada",
      pedido: "64010",
      unidade: "BETIM-01",
    },
    {
      id: "TX-7060-YZ",
      data: "2026-02-04",
      descricao: "Compra em rede parceira",
      valor: 27.8,
      origem: "Wallet",
      situacao: "Autorizada",
    },
  ],
};

export function buscarEstornosMock(cpf: string): TransacaoEstorno[] {
  return estornosMock[somenteDigitos(cpf)] ?? [];
}

/* ------------------------------------------------------------------ *
 * CARTEIRINHAS (MOCK)
 * Softnex ainda sem endpoint definido, dados fictícios.
 * Metabase: Private Labels emitidos, somente leitura.
 * ------------------------------------------------------------------ */

export type CartaoSoftnex = {
  numero: string;
  vinculo: "Titular" | "Dependente";
  nome: string;
  validade: string;
  entrada: string;
  saida: string | null;
  situacao: SituacaoCartao;
};

export type SituacaoCartao = "Ativo" | "Bloqueado" | "Cancelado";

/** Situação do cartão Softnex, no mesmo formato dos outros mapas de status. */
export const situacaoCartao: Record<SituacaoCartao, EstadoVisual> = {
  Ativo: { label: "Ativo", classe: "bg-success/10 text-success border-success/30" },
  Bloqueado: {
    label: "Bloqueado",
    classe: "bg-accent text-accent-foreground border-border-strong",
  },
  Cancelado: {
    label: "Cancelado",
    classe: "bg-muted text-muted-foreground border-border-strong",
  },
};

export type PrivateLabelMetabase = {
  id: string;
  produto: string;
  emissao: string;
  bandeira: string;
  situacao: string;
};

export type CarteirinhasFiliado = {
  softnex: CartaoSoftnex[];
  metabase: PrivateLabelMetabase[];
};

export const carteirinhasMock: Record<string, CarteirinhasFiliado> = {
  "12345678909": {
    softnex: [
      {
        numero: "6390 **** **** 1042",
        vinculo: "Titular",
        nome: "Ana Beatriz Marques",
        validade: "08/2028",
        entrada: "08/2022",
        saida: null,
        situacao: "Ativo",
      },
      {
        numero: "6390 **** **** 1043",
        vinculo: "Dependente",
        nome: "Luiz Marques Filho",
        validade: "08/2028",
        entrada: "09/2022",
        saida: null,
        situacao: "Ativo",
      },
    ],
    metabase: [
      {
        id: "PL-33120",
        produto: "Private Label MaisTODOS Saúde",
        emissao: "12/08/2022",
        bandeira: "Elo",
        situacao: "Emitido",
      },
      {
        id: "PL-41870",
        produto: "Private Label MaisTODOS Farmácia",
        emissao: "03/02/2024",
        bandeira: "Elo",
        situacao: "Emitido",
      },
    ],
  },
  "98765432100": {
    softnex: [
      {
        numero: "6390 **** **** 7715",
        vinculo: "Titular",
        nome: "Carlos Eduardo Nogueira",
        validade: "01/2027",
        entrada: "01/2023",
        saida: null,
        situacao: "Bloqueado",
      },
    ],
    metabase: [
      {
        id: "PL-38004",
        produto: "Private Label MaisTODOS Saúde",
        emissao: "18/01/2023",
        bandeira: "Elo",
        situacao: "Pendente de entrega",
      },
    ],
  },
  "11144477735": {
    softnex: [
      {
        numero: "6390 **** **** 2288",
        vinculo: "Titular",
        nome: "Juliana Ferreira Lopes",
        validade: "05/2029",
        entrada: "05/2024",
        saida: null,
        situacao: "Ativo",
      },
      {
        numero: "6390 **** **** 2289",
        vinculo: "Dependente",
        nome: "Marina Lopes Ferreira",
        validade: "05/2029",
        entrada: "06/2024",
        saida: null,
        situacao: "Ativo",
      },
    ],
    metabase: [
      {
        id: "PL-52210",
        produto: "Private Label MaisTODOS Odonto",
        emissao: "22/05/2024",
        bandeira: "Elo",
        situacao: "Emitido",
      },
    ],
  },
  "52998224725": {
    softnex: [
      {
        numero: "6390 **** **** 9031",
        vinculo: "Titular",
        nome: "Rodrigo Alves Pinheiro",
        validade: "03/2026",
        entrada: "03/2021",
        saida: "01/2026",
        situacao: "Cancelado",
      },
    ],
    metabase: [],
  },
};

export function buscarCarteirinhasMock(cpf: string): CarteirinhasFiliado {
  return carteirinhasMock[somenteDigitos(cpf)] ?? { softnex: [], metabase: [] };
}

/** Formata valor em reais, padrão pt-BR. */
export function moeda(valor: number): string {
  return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

/** Data ISO aaaa-mm-dd exibida como dd/mm/aaaa. */
export function dataBr(iso: string | null): string {
  if (!iso) return "não liquidado";
  const [a, m, d] = iso.split("-");
  if (!a || !m || !d) return iso;
  return `${d}/${m}/${a}`;
}
