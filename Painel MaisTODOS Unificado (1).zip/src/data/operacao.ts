/**
 * Modelo de dados da área "Operação".
 *
 * Toda a arquitetura é orientada a dados: para habilitar uma nova área
 * (Conta Digital, Pagamentos, App, Cashback) basta adicionar um novo
 * objeto `OperacaoArea` em `areas` · as rotas, menus e páginas se adaptam.
 */

import { sistemasLogistica } from "@/data/logistica";

export type Tool = {
  slug: string;
  nome: string;
  categoria: string;
  descricao: string;
  link?: string;
  quemUtiliza: string[];
  comoSolicitarAcesso: string[];
  tutoriais: {
    titulo: string;
    tipo: "Vídeo" | "Documento" | "Passo a passo";
    /** Slug do fluxo mapeado no Hub, quando o tutorial abre um fluxograma. */
    fluxo?: string;
  }[];
};

export type SlackChannel = {
  nomeGrupo: string;
  objetivo: string;
  quandoUtilizar: string;
  tiposDemanda: string[];
  quemMarcar: string[];
  informacoesObrigatorias: string[];
  modeloMensagem: string;
};

export type Financeira = {
  slug: string;
  nome: string;
  resumo: string;
  visaoGeral: {
    produto: string;
    publico: string;
    horario: string;
    sla: string;
    observacoes: string[];
  };
  processo: { passo: string; detalhe: string }[];
  fluxograma: { label: string; tone?: "start" | "decision" | "action" | "end" }[][];
  scripts: { titulo: string; tag: string; texto: string }[];
  prazos: { item: string; prazo: string; obs?: string }[];
  canais: { tipo: "Slack"; slack: SlackChannel }[];
  documentacao: { titulo: string; tipo: string; descricao: string }[];
  historico: { data: string; titulo: string; descricao: string }[];
};

export type Regional = {
  slug: string;
  nome: string;
  consultor: string;
  cargo: string;
  email?: string;
  telefone: string;
  slack?: string;
  estados: string[];
  observacoes?: string;
};

export type Coordenador = {
  nome: string;
  cargo: string;
  telefone: string;
};

export type SegmentoComercial = {
  slug: string;
  nome: string;
  descricao: string;
  coordenador?: Coordenador;
  regionais: Regional[];
};

export type Material = {
  titulo: string;
  categoria: "Documentação geral" | "Política" | "Treinamento" | "Guia interno";
  descricao: string;
  atualizadoEm: string;
};

export type Comunicado = {
  data: string;
  titulo: string;
  tipo: "Novidade" | "Alteração de processo" | "Atualização operacional" | "Aviso importante";
  resumo: string;
  destaque?: boolean;
};

/**
 * Cada área da Operação organiza suas seções em dois grupos:
 * "rotinas" reúne a execução das tarefas do dia a dia,
 * "guia" reúne o conteúdo didático, processos e materiais de estudo.
 */
export type SecaoGrupo = "rotinas" | "guia";

export const gruposSecao: Record<SecaoGrupo, { nome: string; descricao: string; emoji: string }> = {
  rotinas: {
    nome: "Rotinas de trabalho",
    descricao: "Execução do dia a dia: sistemas, ações e tratativas da operação.",
    emoji: "⚙️",
  },
  guia: {
    nome: "Guia da operação",
    descricao: "Conteúdo didático: processos, playbooks, materiais e comunicados.",
    emoji: "📘",
  },
};

export type AreaSection = { slug: string; nome: string; emoji: string; grupo: SecaoGrupo };

export type OperacaoArea = {
  slug: string;
  nome: string;
  emoji: string;
  descricao: string;
  disponivel: boolean;
  /** Seções próprias da área. Quando ausente, usa areaSections. */
  secoes?: AreaSection[];
  fluxoOperacao?: {
    resumo: string;
    etapas: { titulo: string; descricao: string; responsavel: string; sla: string }[];
    regras: string[];
  };
  ferramentas: Tool[];
  financeiras: Financeira[];
  comercial: SegmentoComercial[];
  materiais: Material[];
  comunicados: Comunicado[];
};

/* ------------------------------------------------------------------ */
/* Crédito PF                                                          */
/* ------------------------------------------------------------------ */

const ferramentasCreditoPF: Tool[] = [
  {
    slug: "zendesk",
    nome: "Zendesk",
    categoria: "Atendimento",
    descricao:
      "Plataforma oficial de tickets. Todo atendimento de Crédito PF nasce, é tratado e é encerrado dentro do Zendesk.",
    link: "https://maistodos.zendesk.com",
    quemUtiliza: ["Atendimento Crédito PF", "Backoffice", "Supervisão"],
    comoSolicitarAcesso: [
      "Abrir chamado no Jira (fila Acessos) com gestor em cópia",
      "Informar e-mail corporativo, squad e perfil desejado (agente ou light agent)",
      "Liberação em até 1 dia útil",
    ],
    tutoriais: [
      { titulo: "Como registrar e categorizar um ticket", tipo: "Passo a passo" },
      { titulo: "Macros oficiais do Crédito PF", tipo: "Documento" },
    ],
  },
  {
    slug: "slack",
    nome: "Slack",
    categoria: "Comunicação",
    descricao:
      "Canal principal de acionamento das financeiras parceiras e dos times internos. Cada financeira possui um grupo dedicado.",
    link: "https://slack.com",
    quemUtiliza: ["Toda a operação", "Financeiras parceiras", "Times internos"],
    comoSolicitarAcesso: [
      "Acesso criado automaticamente no onboarding",
      "Solicitar entrada nos grupos das financeiras ao líder direto",
    ],
    tutoriais: [
      { titulo: "Boas práticas de acionamento externo", tipo: "Documento" },
      { titulo: "Como usar os modelos de mensagem", tipo: "Passo a passo" },
    ],
  },
  {
    slug: "retool",
    nome: "Retool",
    categoria: "Operação",
    descricao:
      "Painéis internos para consulta e tratativa de propostas, reprocessamentos e ajustes operacionais de Crédito PF.",
    link: "https://retool.com",
    quemUtiliza: ["Backoffice", "Analistas de operação"],
    comoSolicitarAcesso: [
      "Chamado no Jira (fila Acessos) com aprovação do gestor",
      "Treinamento obrigatório antes da liberação",
    ],
    tutoriais: [
      { titulo: "Consultando uma proposta no Retool", tipo: "Vídeo" },
      { titulo: "Ações críticas e o que nunca fazer", tipo: "Documento" },
    ],
  },
  {
    slug: "plataforma-maistodos",
    nome: "Plataforma MaisTODOS",
    categoria: "Produto",
    descricao:
      "Ambiente do cliente e do estabelecimento. Usada para validar cadastro, contratos e status da proposta.",
    link: "https://maistodos.com.br",
    quemUtiliza: ["Atendimento", "Comercial", "Backoffice"],
    comoSolicitarAcesso: ["Perfil criado no onboarding", "Perfis administrativos via Jira"],
    tutoriais: [{ titulo: "Navegando pelo cadastro do cliente", tipo: "Passo a passo" }],
  },
  {
    slug: "metabase",
    nome: "MetaBase",
    categoria: "Dados",
    descricao:
      "Relatórios e dashboards operacionais: volumes, conversão, SLA e produtividade do Crédito PF.",
    link: "https://metabase.com",
    quemUtiliza: ["Gestão", "Supervisão", "Analistas"],
    comoSolicitarAcesso: ["Chamado no Jira (fila Dados) informando as dashboards necessárias"],
    tutoriais: [{ titulo: "Dashboards oficiais do Crédito PF", tipo: "Documento" }],
  },
  {
    slug: "gestao-comissao-nupay-parcelex-repasses",
    nome: "Gestão de Comissão NuPay e Parcelex Repasses",
    categoria: "Financeiro",
    descricao:
      "Painel de acompanhamento das comissões e dos repasses das operações NuPay e Parcelex, usado na conferência dos valores devidos e já liquidados.",
    quemUtiliza: ["Financeiro", "Backoffice", "Gestão"],
    comoSolicitarAcesso: [
      "Abrir chamado no Jira (fila Financeiro) com aprovação do gestor",
      "Informar e-mail corporativo e quais visões de repasse precisa acompanhar",
    ],
    tutoriais: [
      { titulo: "Conferindo comissões e repasses do mês", tipo: "Passo a passo" },
      { titulo: "Divergências de repasse: o que checar antes de acionar", tipo: "Documento" },
    ],
  },
  {
    slug: "boletocloud",
    nome: "BoletoCloud",
    categoria: "Financeiro",
    descricao:
      "Plataforma de emissão e consulta de boletos, usada para segunda via, baixa e conferência de pagamentos.",
    quemUtiliza: ["Atendimento Crédito PF", "Backoffice financeiro", "Cobrança"],
    comoSolicitarAcesso: [
      "Abrir chamado no Jira (fila Acessos) com aprovação do gestor",
      "Informar e-mail corporativo e perfil desejado (consulta ou emissão)",
    ],
    tutoriais: [
      { titulo: "Emitindo a segunda via de um boleto", tipo: "Passo a passo" },
      { titulo: "Consultando status de pagamento e baixa", tipo: "Documento" },
    ],
  },
  {
    slug: "nupay-business",
    nome: "NuPay Business",
    categoria: "Financeira",
    descricao:
      "Portal da NuPay para consulta de transações, status de pagamento e acompanhamento das operações intermediadas.",
    quemUtiliza: ["Atendimento Crédito PF", "Backoffice"],
    comoSolicitarAcesso: [
      "Solicitar no grupo Slack da NuPay com o gestor marcado",
      "Enviar nome completo, e-mail corporativo e CPF",
    ],
    tutoriais: [
      { titulo: "Consultando uma transação na NuPay Business", tipo: "Passo a passo" },
      { titulo: "Status de pagamento: como interpretar", tipo: "Documento" },
    ],
  },
  {
    slug: "centrax-parcelex",
    nome: "Centrax (Parcelex)",
    categoria: "Financeira",
    descricao:
      "Portal da financeira Parcelex para consulta de propostas, status de análise, formalização e pendências documentais.",
    quemUtiliza: ["Atendimento Crédito PF", "Backoffice"],
    comoSolicitarAcesso: [
      "Solicitar no grupo Slack #maistodos-parcelex",
      "Enviar nome completo, e-mail corporativo e CPF",
    ],
    tutoriais: [
      { titulo: "Consulta de proposta no Centrax", tipo: "Passo a passo" },
      { titulo: "Tratando pendências documentais", tipo: "Documento" },
    ],
  },
  {
    slug: "tshield",
    nome: "TShield",
    categoria: "Prevenção a fraude",
    descricao:
      "Ferramenta de análise antifraude e validação de identidade, consultada nas operações com suspeita de inconsistência cadastral.",
    quemUtiliza: ["Backoffice", "Prevenção a fraude", "Supervisão"],
    comoSolicitarAcesso: [
      "Abrir chamado no Jira (fila Acessos) com aprovação da liderança",
      "Treinamento obrigatório antes da liberação",
    ],
    tutoriais: [
      { titulo: "Consultando uma análise no TShield", tipo: "Passo a passo" },
      { titulo: "Sinais de alerta e próximos passos", tipo: "Documento" },
    ],
  },
  {
    slug: "bmp",
    nome: "BMP",
    categoria: "Financeira",
    descricao:
      "Instituição responsável por parte da liquidação e movimentação financeira das operações.",
    quemUtiliza: ["Backoffice financeiro"],
    comoSolicitarAcesso: ["Chamado no Jira (fila Acessos) com aprovação do gestor financeiro"],
    tutoriais: [{ titulo: "Conciliação de repasses", tipo: "Documento" }],
  },
  {
    slug: "acesso-lara",
    nome: "Acesso Lara",
    categoria: "Financeira",
    descricao:
      "Portal da financeira Lara para acompanhamento de propostas e pendências documentais.",
    quemUtiliza: ["Atendimento Crédito PF"],
    comoSolicitarAcesso: ["Solicitar no grupo Slack #maistodos-lara com gestor marcado"],
    tutoriais: [{ titulo: "Tratando pendências na Lara", tipo: "Passo a passo" }],
  },
  {
    slug: "dimensa",
    nome: "Dimensa",
    categoria: "Backoffice",
    descricao: "Sistema de apoio para gestão de carteira, contratos e informações cadastrais.",
    quemUtiliza: ["Backoffice", "Financeiro"],
    comoSolicitarAcesso: ["Chamado no Jira (fila Acessos)"],
    tutoriais: [{ titulo: "Consulta de contrato", tipo: "Passo a passo" }],
  },
  {
    slug: "cobransaas",
    nome: "Cobransaas",
    categoria: "Cobrança",
    descricao: "Ferramenta de régua de cobrança e negociação de parcelas em atraso.",
    quemUtiliza: ["Cobrança", "Atendimento"],
    comoSolicitarAcesso: ["Chamado no Jira (fila Acessos) com aprovação da liderança de cobrança"],
    tutoriais: [{ titulo: "Registrando um acordo", tipo: "Vídeo" }],
  },
  {
    slug: "comissao-de-pagamento",
    nome: "Comissão de Pagamento",
    categoria: "Financeiro",
    descricao:
      "Painel de apuração e conferência das comissões pagas ao time comercial e parceiros.",
    quemUtiliza: ["Financeiro", "Comercial", "Gestão"],
    comoSolicitarAcesso: ["Chamado no Jira (fila Financeiro)"],
    tutoriais: [{ titulo: "Conferindo a apuração mensal", tipo: "Documento" }],
  },
  {
    slug: "accounts",
    nome: "Accounts",
    categoria: "Acessos",
    descricao: "Gestão central de identidades e permissões dos sistemas MaisTODOS.",
    quemUtiliza: ["Todos os colaboradores", "TI"],
    comoSolicitarAcesso: ["Login com e-mail corporativo (SSO)"],
    tutoriais: [{ titulo: "Trocando sua senha e MFA", tipo: "Passo a passo" }],
  },
  {
    slug: "jira",
    nome: "Jira",
    categoria: "Chamados",
    descricao:
      "Central de chamados internos: acessos, bugs, melhorias e demandas para outras áreas.",
    link: "https://atlassian.com/software/jira",
    quemUtiliza: ["Todos os colaboradores"],
    comoSolicitarAcesso: ["Acesso criado no onboarding via SSO"],
    tutoriais: [{ titulo: "Abrindo um chamado corretamente", tipo: "Passo a passo" }],
  },
];

function slackPadrao(nome: string, grupo: string, pessoas: string[]): SlackChannel {
  return {
    nomeGrupo: grupo,
    objetivo: `Canal oficial de acionamento entre a operação MaisTODOS e a ${nome}.`,
    quandoUtilizar:
      "Após esgotar as consultas nos sistemas oficiais (Zendesk, Retool e portal da financeira) e quando houver pendência que dependa da financeira.",
    tiposDemanda: [
      "Consulta de status de proposta",
      "Pendência documental",
      "Divergência de valores ou taxas",
      "Reprocessamento e correções",
      "Incidentes e indisponibilidade",
    ],
    quemMarcar: pessoas,
    informacoesObrigatorias: [
      "Número do ticket Zendesk",
      "CPF do cliente (sem pontuação)",
      "ID/nº da proposta",
      "Data e hora da ocorrência",
      "Print da tela com o erro",
      "Descrição objetiva do que já foi tentado",
    ],
    modeloMensagem: `Olá, time ${nome}! 👋

*Ticket:* #00000
*CPF:* 000.000.000-00
*Proposta:* 000000
*Ocorrência:* [descreva em uma frase]
*Já verificamos:* [sistemas/consultas realizadas]
*Solicitação:* [o que precisamos da ${nome}]

Obrigado!`,
  };
}

const financeirasCreditoPF: Financeira[] = [
  {
    slug: "maistodos",
    nome: "MaisTODOS",
    resumo: "Operação própria de crédito, com análise e formalização internas.",
    visaoGeral: {
      produto: "Crédito PF próprio para pacientes/clientes de parceiros",
      publico: "Pessoa física com CPF regular",
      horario: "Seg a sex, 08h às 18h",
      sla: "Análise em até 2 horas úteis",
      observacoes: [
        "Tratativas internas não exigem acionamento externo",
        "Escalonamento direto com o backoffice",
      ],
    },
    processo: [
      { passo: "1. Receber demanda", detalhe: "Ticket entra no Zendesk pela fila Crédito PF." },
      {
        passo: "2. Validar identidade",
        detalhe: "Confirmar CPF, nome completo e e-mail cadastrado.",
      },
      { passo: "3. Consultar proposta", detalhe: "Buscar no Retool pelo CPF ou ID da proposta." },
      { passo: "4. Tratar pendência", detalhe: "Resolver internamente ou acionar backoffice." },
      { passo: "5. Encerrar", detalhe: "Registrar solução e categorizar o ticket." },
    ],
    fluxograma: [
      [{ label: "Demanda recebida", tone: "start" }],
      [{ label: "Validar identidade", tone: "action" }],
      [{ label: "Proposta localizada?", tone: "decision" }],
      [
        { label: "SIM → Tratar pendência", tone: "action" },
        { label: "NÃO → Acionar backoffice", tone: "action" },
      ],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Status da proposta",
        tag: "Consulta",
        texto:
          "Já localizei sua proposta aqui no sistema. Ela está em análise e o prazo para retorno é de até 2 horas úteis. Assim que houver atualização, eu te aviso por aqui.",
      },
      {
        titulo: "Pendência documental",
        tag: "Pendência",
        texto:
          "Para seguir com sua solicitação, preciso que você reenvie o documento com foto legível, sem cortes e dentro da validade. Pode me enviar por aqui mesmo.",
      },
    ],
    prazos: [
      { item: "Análise de proposta", prazo: "2 horas úteis" },
      { item: "Retorno de pendência documental", prazo: "1 dia útil" },
      { item: "Liberação após aprovação", prazo: "Até 1 dia útil" },
    ],
    canais: [
      {
        tipo: "Slack",
        slack: slackPadrao("MaisTODOS", "#credito-pf-backoffice", [
          "@backoffice-credito",
          "@lideranca-credito",
        ]),
      },
    ],
    documentacao: [
      {
        titulo: "Política de Crédito PF",
        tipo: "PDF",
        descricao: "Regras de elegibilidade, limites e taxas.",
      },
      {
        titulo: "Manual do atendimento",
        tipo: "PDF",
        descricao: "Procedimento oficial ponta a ponta.",
      },
    ],
    historico: [
      {
        data: "2026-07-20",
        titulo: "Novo SLA de análise",
        descricao: "Prazo reduzido de 4h para 2h úteis.",
      },
      {
        data: "2026-05-02",
        titulo: "Atualização de scripts",
        descricao: "Scripts de pendência revisados.",
      },
    ],
  },
  {
    slug: "capim",
    nome: "Capim",
    resumo: "Financeira parceira focada em crédito odontológico.",
    visaoGeral: {
      produto: "Parcelamento de tratamentos odontológicos",
      publico: "Pacientes de clínicas odontológicas parceiras",
      horario: "Seg a sex, 09h às 18h",
      sla: "Retorno em até 4 horas úteis",
      observacoes: [
        "Consultar sempre o portal antes de acionar o Slack",
        "Propostas expiram em 7 dias",
      ],
    },
    processo: [
      {
        passo: "1. Receber demanda",
        detalhe: "Ticket Zendesk com identificação da clínica e do paciente.",
      },
      { passo: "2. Consultar proposta", detalhe: "Buscar pelo CPF no portal Capim." },
      {
        passo: "3. Classificar",
        detalhe: "Análise, pendência documental, formalização ou pagamento.",
      },
      { passo: "4. Acionar Capim", detalhe: "Somente se não houver informação nos sistemas." },
      { passo: "5. Retornar ao cliente", detalhe: "Registrar tratativa no ticket e encerrar." },
    ],
    fluxograma: [
      [{ label: "Demanda Capim", tone: "start" }],
      [{ label: "Consultar portal Capim", tone: "action" }],
      [{ label: "Informação disponível?", tone: "decision" }],
      [
        { label: "SIM → Responder cliente", tone: "action" },
        { label: "NÃO → Acionar Slack Capim", tone: "action" },
      ],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Proposta em análise",
        tag: "Consulta",
        texto:
          "Sua proposta está em análise junto à financeira Capim. O prazo de retorno é de até 4 horas úteis e assim que tivermos o resultado entraremos em contato.",
      },
      {
        titulo: "Proposta expirada",
        tag: "Reenvio",
        texto:
          "Identifiquei que sua proposta expirou, pois o prazo de aceite é de 7 dias. Vou solicitar a geração de uma nova proposta agora mesmo.",
      },
    ],
    prazos: [
      { item: "Análise de crédito", prazo: "4 horas úteis" },
      { item: "Validade da proposta", prazo: "7 dias corridos" },
      { item: "Repasse à clínica", prazo: "2 dias úteis após formalização" },
    ],
    canais: [
      {
        tipo: "Slack",
        slack: slackPadrao("Capim", "#maistodos-capim", ["@suporte-capim", "@backoffice-credito"]),
      },
    ],
    documentacao: [
      {
        titulo: "Manual operacional Capim",
        tipo: "PDF",
        descricao: "Fluxo completo e regras da parceria.",
      },
      {
        titulo: "Tabela de taxas",
        tipo: "XLSX",
        descricao: "Taxas vigentes por faixa de parcelamento.",
      },
    ],
    historico: [
      {
        data: "2026-07-11",
        titulo: "Novo portal",
        descricao: "Portal Capim atualizado com nova busca por CPF.",
      },
      {
        data: "2026-06-01",
        titulo: "Prazo de repasse",
        descricao: "Repasse passou de 3 para 2 dias úteis.",
      },
    ],
  },
  {
    slug: "parcelex",
    nome: "Parcelex",
    resumo: "Financeira parceira para parcelamento de serviços de saúde e estética.",
    visaoGeral: {
      produto: "Crédito parcelado para serviços",
      publico: "Pessoa física aprovada em análise da Parcelex",
      horario: "Seg a sex, 09h às 19h",
      sla: "Retorno em até 1 dia útil",
      observacoes: [
        "Acesso ao portal solicitado via Slack",
        "Documentação exige selfie + documento",
      ],
    },
    processo: [
      { passo: "1. Receber demanda", detalhe: "Ticket Zendesk categorizado como Parcelex." },
      { passo: "2. Consultar portal", detalhe: "Verificar status no Acesso Parcelex." },
      { passo: "3. Validar documentação", detalhe: "Conferir documentos enviados e pendências." },
      { passo: "4. Acionar Parcelex", detalhe: "Slack com ticket, CPF e proposta." },
      { passo: "5. Encerrar", detalhe: "Registrar retorno e finalizar o ticket." },
    ],
    fluxograma: [
      [{ label: "Demanda Parcelex", tone: "start" }],
      [{ label: "Consultar Acesso Parcelex", tone: "action" }],
      [{ label: "Pendência documental?", tone: "decision" }],
      [
        { label: "SIM → Orientar cliente", tone: "action" },
        { label: "NÃO → Seguir análise", tone: "action" },
      ],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Pendência de selfie",
        tag: "Pendência",
        texto:
          "Para concluir sua análise, a financeira precisa de uma selfie segurando o documento de identificação, em ambiente claro e sem uso de filtros.",
      },
    ],
    prazos: [
      { item: "Análise de crédito", prazo: "1 dia útil" },
      { item: "Reanálise após pendência", prazo: "1 dia útil" },
      { item: "Formalização", prazo: "2 dias úteis" },
    ],
    canais: [
      {
        tipo: "Slack",
        slack: slackPadrao("Parcelex", "#maistodos-parcelex", [
          "@suporte-parcelex",
          "@backoffice-credito",
        ]),
      },
    ],
    documentacao: [
      {
        titulo: "Guia Parcelex",
        tipo: "PDF",
        descricao: "Regras de análise e documentação aceita.",
      },
    ],
    historico: [
      {
        data: "2026-06-18",
        titulo: "Nova validação biométrica",
        descricao: "Selfie passou a ser obrigatória.",
      },
    ],
  },
  {
    slug: "parcela-mais",
    nome: "Parcela Mais",
    resumo: "Parceira com foco em parcelamento de tratamentos de médio ticket.",
    visaoGeral: {
      produto: "Crédito parcelado para tratamentos",
      publico: "Pessoa física com score mínimo exigido",
      horario: "Seg a sex, 09h às 18h",
      sla: "Retorno em até 1 dia útil",
      observacoes: ["Consultas de status apenas por Slack"],
    },
    processo: [
      { passo: "1. Receber demanda", detalhe: "Ticket Zendesk categorizado como Parcela Mais." },
      { passo: "2. Coletar dados", detalhe: "CPF, proposta e clínica." },
      { passo: "3. Acionar parceira", detalhe: "Slack com modelo oficial de mensagem." },
      { passo: "4. Encerrar", detalhe: "Registrar retorno e finalizar." },
    ],
    fluxograma: [
      [{ label: "Demanda Parcela Mais", tone: "start" }],
      [{ label: "Coletar CPF e proposta", tone: "action" }],
      [{ label: "Acionar Slack", tone: "action" }],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Consulta de status",
        tag: "Consulta",
        texto:
          "Estou verificando sua proposta junto à financeira parceira. O prazo de retorno é de até 1 dia útil e te informo assim que tivermos a resposta.",
      },
    ],
    prazos: [
      { item: "Análise de crédito", prazo: "1 dia útil" },
      { item: "Repasse", prazo: "3 dias úteis" },
    ],
    canais: [
      {
        tipo: "Slack",
        slack: slackPadrao("Parcela Mais", "#maistodos-parcela-mais", ["@suporte-parcelamais"]),
      },
    ],
    documentacao: [
      { titulo: "Fluxo Parcela Mais", tipo: "PDF", descricao: "Processo operacional resumido." },
    ],
    historico: [
      {
        data: "2026-04-09",
        titulo: "Início da parceria",
        descricao: "Operação iniciada na regional Sudeste.",
      },
    ],
  },
  {
    slug: "lara",
    nome: "Lara",
    resumo: "Financeira parceira com portal próprio para acompanhamento de propostas.",
    visaoGeral: {
      produto: "Crédito parcelado",
      publico: "Pessoa física",
      horario: "Seg a sex, 08h às 18h",
      sla: "Retorno em até 4 horas úteis",
      observacoes: ["Acionamento pelo Slack #maistodos-lara"],
    },
    processo: [
      { passo: "1. Receber demanda", detalhe: "Ticket Zendesk categorizado como Lara." },
      { passo: "2. Consultar portal", detalhe: "Acesso Lara → busca por CPF." },
      { passo: "3. Tratar pendência", detalhe: "Orientar cliente ou acionar a financeira." },
      { passo: "4. Encerrar", detalhe: "Registrar tratativa no ticket." },
    ],
    fluxograma: [
      [{ label: "Demanda Lara", tone: "start" }],
      [{ label: "Consultar Acesso Lara", tone: "action" }],
      [{ label: "Resolvido?", tone: "decision" }],
      [
        { label: "SIM → Encerrar", tone: "action" },
        { label: "NÃO → Slack Lara", tone: "action" },
      ],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Documento ilegível",
        tag: "Pendência",
        texto:
          "O documento enviado não pôde ser validado pela financeira. Pode reenviar uma foto nítida, com todas as bordas visíveis e boa iluminação?",
      },
    ],
    prazos: [
      { item: "Análise", prazo: "4 horas úteis" },
      { item: "Reanálise", prazo: "1 dia útil" },
    ],
    canais: [
      {
        tipo: "Slack",
        slack: slackPadrao("Lara", "#maistodos-lara", ["@suporte-lara", "@backoffice-credito"]),
      },
    ],
    documentacao: [
      { titulo: "Manual Lara", tipo: "PDF", descricao: "Passo a passo de consulta e pendências." },
    ],
    historico: [
      { data: "2026-05-27", titulo: "Novo horário", descricao: "Atendimento ampliado até 18h." },
    ],
  },
  {
    slug: "nupay",
    nome: "Nupay",
    resumo: "Meio de pagamento parceiro utilizado em parte das operações de Crédito PF.",
    visaoGeral: {
      produto: "Pagamento parcelado via Nupay",
      publico: "Clientes com conta ativa no parceiro",
      horario: "24/7 (suporte em horário comercial)",
      sla: "Retorno em até 1 dia útil",
      observacoes: ["Estornos seguem regra própria do parceiro"],
    },
    processo: [
      { passo: "1. Receber demanda", detalhe: "Ticket Zendesk com identificação do pagamento." },
      { passo: "2. Validar transação", detalhe: "Conferir ID da transação no Retool." },
      { passo: "3. Acionar Nupay", detalhe: "Slack com ID e evidências." },
      { passo: "4. Encerrar", detalhe: "Registrar desfecho no ticket." },
    ],
    fluxograma: [
      [{ label: "Demanda Nupay", tone: "start" }],
      [{ label: "Validar transação", tone: "action" }],
      [{ label: "Transação encontrada?", tone: "decision" }],
      [
        { label: "SIM → Tratar", tone: "action" },
        { label: "NÃO → Slack Nupay", tone: "action" },
      ],
      [{ label: "Registrar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Pagamento não identificado",
        tag: "Pagamento",
        texto:
          "Ainda não identificamos a confirmação do seu pagamento. Pode me enviar o comprovante com data, horário e ID da transação para agilizarmos a verificação?",
      },
    ],
    prazos: [
      { item: "Confirmação de pagamento", prazo: "Até 2 horas" },
      { item: "Estorno", prazo: "Até 7 dias úteis" },
    ],
    canais: [
      { tipo: "Slack", slack: slackPadrao("Nupay", "#maistodos-nupay", ["@suporte-nupay"]) },
    ],
    documentacao: [
      { titulo: "Regras de estorno", tipo: "PDF", descricao: "Condições e prazos de estorno." },
    ],
    historico: [
      {
        data: "2026-03-14",
        titulo: "Integração atualizada",
        descricao: "Novo status de conciliação no Retool.",
      },
    ],
  },
  {
    slug: "inss",
    nome: "INSS",
    resumo: "Operação de crédito consignado para beneficiários do INSS.",
    visaoGeral: {
      produto: "Consignado INSS",
      publico: "Aposentados e pensionistas",
      horario: "Seg a sex, 09h às 17h",
      sla: "Averbação em até 2 dias úteis",
      observacoes: [
        "Regras regulatórias específicas",
        "Margem consignável deve ser conferida antes da proposta",
      ],
    },
    processo: [
      {
        passo: "1. Validar benefício",
        detalhe: "Conferir número do benefício e margem disponível.",
      },
      { passo: "2. Simular proposta", detalhe: "Aplicar taxa vigente e prazo permitido." },
      { passo: "3. Formalizar", detalhe: "Coletar biometria e aceite formal." },
      { passo: "4. Averbar", detalhe: "Enviar para averbação e acompanhar retorno." },
      { passo: "5. Encerrar", detalhe: "Registrar no ticket e informar o cliente." },
    ],
    fluxograma: [
      [{ label: "Demanda INSS", tone: "start" }],
      [{ label: "Conferir margem", tone: "action" }],
      [{ label: "Margem disponível?", tone: "decision" }],
      [
        { label: "SIM → Simular e formalizar", tone: "action" },
        { label: "NÃO → Orientar cliente", tone: "action" },
      ],
      [{ label: "Averbar e encerrar", tone: "end" }],
    ],
    scripts: [
      {
        titulo: "Margem insuficiente",
        tag: "Consignado",
        texto:
          "Verifiquei que sua margem consignável no momento não permite a contratação. Ela é atualizada mensalmente e podemos tentar novamente na próxima competência.",
      },
    ],
    prazos: [
      { item: "Averbação", prazo: "2 dias úteis" },
      { item: "Liberação do valor", prazo: "Até 1 dia útil após averbação" },
    ],
    canais: [
      { tipo: "Slack", slack: slackPadrao("INSS", "#maistodos-inss", ["@backoffice-consignado"]) },
    ],
    documentacao: [
      {
        titulo: "Normativo consignado",
        tipo: "PDF",
        descricao: "Regras regulatórias e limites vigentes.",
      },
    ],
    historico: [
      {
        data: "2026-07-01",
        titulo: "Nova taxa teto",
        descricao: "Atualização da taxa máxima permitida.",
      },
    ],
  },
];

const comercialCreditoPF: SegmentoComercial[] = [
  {
    slug: "odonto",
    nome: "Odontologia",
    descricao: "Clínicas e consultórios odontológicos parceiros.",
    coordenador: {
      nome: "Matheus Uliana",
      cargo: "Coordenador Comercial",
      telefone: "(16) 98171-0758",
    },
    regionais: [
      {
        slug: "interior",
        nome: "Interior",
        consultor: "João Nardini",
        cargo: "Executivo Comercial",
        telefone: "(16) 98824-4426",
        estados: ["SP Interior", "GO", "DF", "TO"],
      },
      {
        slug: "sao-paulo-minas",
        nome: "São Paulo / Minas",
        consultor: "Gui Ferrari",
        cargo: "Executivo Comercial",
        telefone: "(16) 98253-0019",
        estados: ["SP Capital", "Vale do Paraíba", "MG"],
      },
      {
        slug: "centro-sul",
        nome: "Centro Sul",
        consultor: "Talita Maciel",
        cargo: "Executiva Comercial",
        telefone: "(16) 98171-1245",
        estados: ["PR", "SC", "RS", "MT", "MS", "RO"],
      },
      {
        slug: "costa-leste",
        nome: "Costa Leste",
        consultor: "Fernanda Barbosa",
        cargo: "Executiva Comercial",
        telefone: "(16) 98187-0982",
        estados: ["RJ", "ES", "BA", "SE", "AL"],
      },
      {
        slug: "equatorial",
        nome: "Equatorial",
        consultor: "Sabrina Oliveira",
        cargo: "Executiva Comercial",
        telefone: "(16) 98252-5359",
        estados: ["PE", "RN", "PB", "CE", "MA", "PI", "PA", "AM", "AC", "RR"],
      },
    ],
  },
  {
    slug: "medicina",
    nome: "Medicina",
    descricao: "Clínicas médicas, estética avançada e procedimentos.",
    coordenador: {
      nome: "William Lima",
      cargo: "Coordenador Comercial",
      telefone: "(16) 98196-0049",
    },
    regionais: [
      {
        slug: "interior",
        nome: "Interior",
        consultor: "Will Santos",
        cargo: "Executivo Comercial",
        telefone: "(16) 98196-0036",
        estados: ["SP Interior", "GO", "DF", "TO"],
      },
      {
        slug: "sao-paulo-minas",
        nome: "São Paulo / Minas",
        consultor: "William Tardivo",
        cargo: "Executivo Comercial",
        telefone: "(16) 98237-0165",
        estados: ["SP Capital", "Vale do Paraíba", "MG"],
      },
      {
        slug: "centro-sul",
        nome: "Centro Sul",
        consultor: "Cristiane Santos",
        cargo: "Executiva Comercial",
        telefone: "(16) 98194-0024",
        estados: ["PR", "SC", "RS", "MT", "MS", "RO"],
      },
      {
        slug: "costa-leste",
        nome: "Costa Leste",
        consultor: "Dayane Aparecida",
        cargo: "Executiva Comercial",
        telefone: "(16) 98184-0058",
        estados: ["RJ", "ES", "BA", "SE", "AL"],
      },
      {
        slug: "equatorial",
        nome: "Equatorial",
        consultor: "Jhon",
        cargo: "Executivo Comercial",
        telefone: "(16) 98184-0041",
        estados: ["PE", "RN", "PB", "CE", "MA", "PI", "PA", "AM", "AC", "RR"],
      },
    ],
  },
  {
    slug: "novos-negocios",
    nome: "Novos Negócios",
    descricao: "Novas verticais, parcerias e projetos piloto.",
    regionais: [
      {
        slug: "nacional",
        nome: "Nacional",
        consultor: "Gustavo Ferraz",
        cargo: "Head de Novos Negócios",
        email: "gustavo.ferraz@maistodos.com.br",
        telefone: "(11) 99000-0021",
        slack: "@gustavo.ferraz",
        estados: ["Brasil"],
        observacoes: "Cobertura nacional para pilotos e parcerias estratégicas.",
      },
      {
        slug: "sudeste",
        nome: "Sudeste",
        consultor: "Camila Duarte",
        cargo: "Consultora de Expansão",
        email: "camila.duarte@maistodos.com.br",
        telefone: "(11) 99000-0022",
        slack: "@camila.duarte",
        estados: ["SP", "RJ", "MG"],
        observacoes: "Prospecção de novas verticais de saúde.",
      },
    ],
  },
];

export const areas: OperacaoArea[] = [
  {
    slug: "credito-pf",
    nome: "Crédito PF",
    emoji: "💳",
    descricao:
      "Operação de crédito para pessoa física, financeiras parceiras, ferramentas e time comercial.",
    disponivel: true,
    fluxoOperacao: {
      resumo:
        "A jornada operacional do Crédito PF é a mesma para todas as financeiras: a demanda entra pelo Zendesk, é qualificada, consultada nos sistemas oficiais e só então · se necessário · a financeira é acionada pelo Slack.",
      etapas: [
        {
          titulo: "1. Recebimento da demanda",
          descricao:
            "Ticket criado no Zendesk pela clínica, cliente ou time comercial e direcionado à fila Crédito PF.",
          responsavel: "Atendimento",
          sla: "Triagem em até 30 min",
        },
        {
          titulo: "2. Qualificação e identificação",
          descricao:
            "Validar identidade, identificar a financeira envolvida e classificar o tipo de demanda.",
          responsavel: "Atendimento",
          sla: "10 min",
        },
        {
          titulo: "3. Consulta nos sistemas",
          descricao:
            "Consultar Retool, Plataforma MaisTODOS e o portal da financeira antes de qualquer acionamento externo.",
          responsavel: "Atendimento",
          sla: "20 min",
        },
        {
          titulo: "4. Tratativa interna",
          descricao:
            "Resolver o que estiver ao alcance da operação: orientação, reenvio de documentos, reprocessamento.",
          responsavel: "Atendimento / Backoffice",
          sla: "2 horas úteis",
        },
        {
          titulo: "5. Acionamento da financeira",
          descricao:
            "Somente quando a informação depende da parceira. Usar o grupo Slack e o modelo de mensagem oficial.",
          responsavel: "Atendimento",
          sla: "Conforme SLA da financeira",
        },
        {
          titulo: "6. Retorno ao cliente",
          descricao:
            "Comunicar a solução com linguagem clara, confirmar entendimento e registrar no ticket.",
          responsavel: "Atendimento",
          sla: "Imediato após retorno",
        },
        {
          titulo: "7. Encerramento e registro",
          descricao:
            "Categorizar corretamente o ticket, registrar causa raiz e sinalizar recorrências à liderança.",
          responsavel: "Atendimento",
          sla: "Mesmo dia",
        },
      ],
      regras: [
        "Nunca acionar a financeira sem antes consultar os sistemas oficiais.",
        "Todo acionamento externo precisa de ticket, CPF e proposta.",
        "Toda tratativa deve ser registrada no ticket · o que não está no Zendesk não aconteceu.",
        "Prazos prometidos ao cliente devem sempre seguir o SLA da financeira.",
      ],
    },
    ferramentas: ferramentasCreditoPF,
    financeiras: financeirasCreditoPF,
    comercial: comercialCreditoPF,
    materiais: [
      {
        titulo: "Política de Crédito PF",
        categoria: "Política",
        descricao: "Critérios de elegibilidade, limites, taxas e regras de exceção.",
        atualizadoEm: "2026-07-15",
      },
      {
        titulo: "Manual de atendimento Crédito PF",
        categoria: "Documentação geral",
        descricao: "Procedimento oficial ponta a ponta, válido para todas as financeiras.",
        atualizadoEm: "2026-07-02",
      },
      {
        titulo: "Trilha de onboarding do analista",
        categoria: "Treinamento",
        descricao: "Materiais dos primeiros 30 dias na operação de Crédito PF.",
        atualizadoEm: "2026-06-20",
      },
      {
        titulo: "Guia de acionamento das financeiras",
        categoria: "Guia interno",
        descricao: "Como, quando e com quais informações acionar cada parceira.",
        atualizadoEm: "2026-07-18",
      },
      {
        titulo: "Política de LGPD no atendimento",
        categoria: "Política",
        descricao: "Tratamento de dados pessoais durante o atendimento.",
        atualizadoEm: "2026-05-30",
      },
      {
        titulo: "Guia de tom de voz",
        categoria: "Guia interno",
        descricao: "Como se comunicar com o cliente em cada tipo de situação.",
        atualizadoEm: "2026-04-12",
      },
    ],
    comunicados: [
      {
        data: "2026-08-14",
        titulo: "Prazo para emissão de nota fiscal após aprovação · Parcelex",
        tipo: "Aviso importante",
        resumo:
          "Após a aprovação da proposta na financeira Parcelex, as clínicas têm o prazo de 25 dias corridos para a emissão da nota fiscal e anexo na proposta. Caso a nota fiscal não seja enviada dentro desse prazo, a proposta será cancelada.",
        destaque: true,
      },
    ],
  },
  {
    slug: "conta-digital",
    nome: "Conta Digital",
    emoji: "🏦",
    descricao:
      "Conta digital MaisTODOS: fluxo de onboarding em 10 etapas, providers envolvidos, retornos possíveis e ação de suporte em cada reprovação.",
    disponivel: true,
    secoes: [
      { slug: "onboarding", nome: "Fluxo de Onboarding", emoji: "🧭", grupo: "guia" },
      { slug: "reprovacoes", nome: "Reprovações e Glossário", emoji: "🧾", grupo: "guia" },
      { slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" },
    ],

    ferramentas: [],
    financeiras: [],
    comercial: [],
    materiais: [],
    comunicados: [],
  },
  {
    slug: "pagamentos",
    nome: "Pagamentos",
    emoji: "💸",
    descricao:
      "Maquininha, portais, repasses e conciliação: processos e playbooks da operação de Pagamentos.",
    disponivel: true,
    secoes: [{ slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" }],
    ferramentas: [],
    financeiras: [],
    comercial: [],
    materiais: [],
    comunicados: [],
  },
  {
    slug: "logistica",
    nome: "Logística",
    emoji: "📦",
    descricao:
      "Supply e Logística: envio de maquininhas, bobinas e carteirinhas, nota fiscal, frete, rastreio e follow-up de entregas.",
    disponivel: true,
    secoes: [
      { slug: "ferramentas", nome: "Sistemas do Supply", emoji: "🛠️", grupo: "rotinas" },
      { slug: "fluxos", nome: "Fluxos de Envio", emoji: "🚚", grupo: "guia" },
      { slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" },
    ],

    ferramentas: sistemasLogistica,
    financeiras: [],
    comercial: [],
    materiais: [],
    comunicados: [],
  },

  {
    slug: "app",
    nome: "App",
    emoji: "📱",
    descricao:
      "Aplicativo MaisTODOS e atendimento ao cliente final: filiados, cashback, estornos, carteirinhas, painel N2 e auditoria.",
    disponivel: true,
    secoes: [{ slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" }],

    ferramentas: [],
    financeiras: [],
    comercial: [],
    materiais: [],
    comunicados: [],
  },
  {
    slug: "cashback",
    nome: "Cashback",
    emoji: "🎁",
    descricao:
      "Programa de cashback e benefícios: soluções paliativas, consultas de saldo do parceiro e procedimentos no Retool.",
    disponivel: true,
    secoes: [{ slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" }],
    ferramentas: [],
    financeiras: [],
    comercial: [],
    materiais: [],
    comunicados: [],
  },
];

export function getArea(slug: string): OperacaoArea | undefined {
  return areas.find((a) => a.slug === slug);
}

export const areaSections: AreaSection[] = [
  { slug: "ferramentas", nome: "Central de Ferramentas", emoji: "🛠️", grupo: "rotinas" },
  { slug: "financeiras", nome: "Financeiras Parceiras", emoji: "🏦", grupo: "rotinas" },
  { slug: "fluxo", nome: "Fluxo da Operação", emoji: "📊", grupo: "guia" },
  { slug: "comercial", nome: "Time Comercial", emoji: "👥", grupo: "rotinas" },
  { slug: "materiais", nome: "Materiais de Apoio", emoji: "📚", grupo: "guia" },
  { slug: "comunicados", nome: "Comunicados", emoji: "📢", grupo: "guia" },
  { slug: "processos", nome: "Processos e Playbooks", emoji: "📄", grupo: "guia" },
];
