/**
 * Operação · Logística Supply.
 * Conteúdo do mapeamento de processos do time de Supply: envio de maquininhas,
 * bobinas, carteirinhas Private Label e follow-up de rastreio.
 */

import fluxoTef from "@/assets/logistica/fluxo-tef.webp";
import fluxoBobina from "@/assets/logistica/fluxo-bobina.webp";
import fluxoPrivateLabel from "@/assets/logistica/fluxo-private-label.webp";
import type { Tool } from "@/data/operacao";

export type PassoLogistica = {
  n: number;
  fase: string;
  responsavel: string;
  titulo: string;
  /** Caminho exato dentro do sistema, como aparece no fluxograma. */
  caminho?: string;
  descricao: string;
  /** Cuidado ou regra que evita erro na etapa. */
  obs?: string;
  /** Etapa de decisão: gera dois caminhos. */
  decisao?: boolean;
  /** Rótulo da seta que sai da decisão. */
  saida?: string;
};

export type FaseLogistica = {
  nome: string;
  tom: "roxo" | "azul" | "laranja" | "ambar" | "verde";
};

export type FluxoLogistica = {
  slug: string;
  nome: string;
  resumo: string;
  sistemas: string[];
  fases: FaseLogistica[];
  imagem: string;
  imagemAlt: string;
  passos: PassoLogistica[];
  pontosCriticos: string[];
  notas?: string[];
};

const passosTef: PassoLogistica[] = [
  {
    n: 1,
    fase: "Captura e organização dos dados",
    responsavel: "Supply",
    titulo: "Localizar pedido",
    caminho:
      "Portal de TODOS > aba Pedidos > subaba conforme o tipo (Clínicas, EPTs, Franquias, Parceiros) > filtrar pela coluna Status",
    descricao: "Trabalhar os pedidos com status 'Pedido efetuado'.",
  },
  {
    n: 2,
    fase: "Captura e organização dos dados",
    responsavel: "Supply",
    titulo: "Coletar dados do pedido e do parceiro",
    descricao:
      "Do pedido: número de ID, criado em, e-mail, CEP, item e quantidade. Do parceiro, clicando no nome: Razão Social, Nome Fantasia e CNPJ.",
  },
  {
    n: 3,
    fase: "Captura e organização dos dados",
    responsavel: "Supply",
    titulo: "Registrar na planilha",
    caminho: "Planilha de solicitações POS > aba conforme o tipo do parceiro",
    descricao: "Preencher pedido, data, CNPJ, CEP, UF, tipo de item e quantidade.",
    obs: "As demais colunas (transportadora, ordem, SN, NF, rastreio) são completadas nas próximas fases.",
  },
  {
    n: 4,
    fase: "Captura e organização dos dados",
    responsavel: "Supply",
    titulo: "Atualizar cadastro no OMIE",
    caminho:
      "Vendas > Clientes > Exibir todos > colar CNPJ > abrir cadastro > Pesquisar SEFAZ > atualizar informações selecionadas > Salvar",
    descricao: "O cadastro atualizado é o que alimenta a nota fiscal de remessa.",
    obs: "Não atualizar Nome Fantasia e Razão Social. Conferir o CEP: o do OMIE está sempre correto.",
  },
  {
    n: 5,
    fase: "Preparo logístico e abertura no Jira",
    responsavel: "Supply",
    titulo: "Cotar frete",
    caminho:
      "Smart Envio > Simular Fretes > CEP de origem e destino, peso e dimensões > Realizar cotação > comparar transportadoras (valor por prazo) > Selecionar",
    descricao: "Registrar a transportadora escolhida na planilha.",
  },
  {
    n: 6,
    fase: "Preparo logístico e abertura no Jira",
    responsavel: "Supply",
    titulo: "Abrir card no Jira",
    caminho:
      "Central de Serviços > Logística > Solicitação de Maquininha > preencher tipo, conteúdo, número do pedido, CNPJ, quantidade e dados do estabelecimento > Salvar",
    descricao: "O card é o controle oficial do envio até o gatilho de cobrança.",
    obs: "Gera o número OL-XXX: anotar na planilha e depois na nota fiscal.",
  },
  {
    n: 7,
    fase: "Preparo logístico e abertura no Jira",
    responsavel: "Supply",
    titulo: "Preparar o equipamento",
    descricao:
      "Máquina usada: retirar a máscara antiga, limpar e colar o novo modelo. Máquina nova: aplicar a máscara.",
  },
  {
    n: 8,
    fase: "Preparo logístico e abertura no Jira",
    responsavel: "Supply",
    titulo: "Bipar serial number",
    descricao:
      "Bipar o SN das maquininhas e impressoras e registrar na coluna Serial/SN da planilha.",
    obs: "Esse SN será reaproveitado na nota fiscal do OMIE.",
  },
  {
    n: 9,
    fase: "Emissão fiscal e envio",
    responsavel: "Supply",
    titulo: "Emitir NF de remessa no OMIE",
    caminho:
      "Remessa de Produto > Exibir todos > abrir nota parecida > Duplicar > trocar CNPJ do cliente > ajustar itens e quantidades > Departamento 0006 Aluguel > Transportadora > Informações Adicionais: número do pedido + SN + OL-XXX > Salvar > Concluir Remessa",
    descricao: "A nota de remessa acompanha o equipamento na caixa.",
    obs: "Duplicar nota da mesma UF (dentro de São Paulo) ou de outra UF (fora de São Paulo), por causa do CFOP.",
  },
  {
    n: 10,
    fase: "Emissão fiscal e envio",
    responsavel: "Supply",
    titulo: "Registrar número da NF",
    caminho: "OMIE > Exibir todos",
    descricao: "Copiar o número da nota gerada e anotar na coluna NF da planilha.",
  },
  {
    n: 11,
    fase: "Emissão fiscal e envio",
    responsavel: "Supply",
    titulo: "Imprimir etiqueta",
    caminho:
      "Smart Envio > Imprimir Etiquetas > localizar a NF > selecionar > Etiqueta 10x15 + Documento simplificado 10x15 > imprimir na Brother QL-800",
    descricao: "Etiqueta e documento simplificado vão colados na caixa.",
  },
  {
    n: 12,
    fase: "Emissão fiscal e envio",
    responsavel: "Supply",
    titulo: "Conferir, empacotar e solicitar coleta",
    caminho:
      "Smart Envio > Solicitar Coleta > selecionar a razão social 'Administradora Cartão De Crédito Todos S.A.'",
    descricao:
      "Cruzar o número da NF com o número do pedido na planilha e empacotar equipamento e nota fiscal na caixa.",
    obs: "Solicitar coleta antes das 11h, no mesmo dia do envio.",
  },
  {
    n: 13,
    fase: "Acompanhamento e finalização",
    responsavel: "Supply",
    titulo: "Atualizar rastreio na planilha",
    descricao:
      "Preencher código de rastreio, site de rastreio, previsão de entrega e status, por exemplo 'em trânsito'.",
  },
  {
    n: 14,
    fase: "Acompanhamento e finalização",
    responsavel: "Supply",
    titulo: "Atualizar status e marcar Em Trânsito",
    caminho:
      "Portal de TODOS: marcar 'Postado'. Jira: pesquisar o card OL-XXX, preencher Serial Number, Ordem (número da NF) e Código de Rastreio > alterar status para 'Em Trânsito'",
    descricao: "A partir daqui o franqueado consegue acompanhar a entrega no portal.",
  },
  {
    n: 15,
    fase: "Acompanhamento e finalização",
    responsavel: "Supply",
    titulo: "Finalizar após a entrega",
    caminho:
      "Smart Envio: conferir a entrega pelo código de rastreio > voltar ao card no Jira > atualizar status",
    descricao:
      "Status final conforme o item: Entregue, Iniciar Cobrança, ou Concluir para impressora e bobina.",
  },
];

const fasesTef: FaseLogistica[] = [
  { nome: "Captura e organização dos dados", tom: "roxo" },
  { nome: "Preparo logístico e abertura no Jira", tom: "azul" },
  { nome: "Emissão fiscal e envio", tom: "laranja" },
  { nome: "Acompanhamento e finalização", tom: "verde" },
];

const passosBobina: PassoLogistica[] = [
  {
    n: 1,
    fase: "Captura e organização dos dados (Jira)",
    responsavel: "Supply",
    titulo: "Filtrar pedidos de bobina no Jira",
    caminho:
      "Link com filtro fixo: Espaço = Logística Terminal, Status = Aberto, Conteúdo Envio = Bobina, Tipo de Solicitação (OL) = Envio Bobina",
    descricao: "O pedido de bobina chega pelo Jira, não pelo Portal de TODOS.",
  },
  {
    n: 2,
    fase: "Captura e organização dos dados (Jira)",
    responsavel: "Supply",
    titulo: "Abrir o card e copiar os dados",
    descricao:
      "Clicar no número do card e copiar um a um: número de ID, CNPJ, Estado, nome do estabelecimento, criado em, e-mail, item e quantidade.",
    obs: "Copiar em bloco causa erro de preenchimento na planilha.",
  },
  {
    n: 3,
    fase: "Captura e organização dos dados (Jira)",
    responsavel: "Supply",
    titulo: "Registrar na planilha, aba Bobina",
    caminho: "Planilha de solicitações POS > aba Bobina",
    descricao:
      "Anotar também o número do card do Jira: ele será reutilizado na nota fiscal do OMIE.",
  },
  {
    n: 4,
    fase: "Cadastro do cliente e cotação de frete",
    responsavel: "Supply",
    titulo: "Atualizar cadastro no OMIE",
    caminho:
      "Vendas e NF-e > Clientes > Exibir todos > colar CNPJ > abrir cadastro > Pesquisar SEFAZ > atualizar informações selecionadas > Salvar",
    descricao: "Garante endereço e inscrição corretos para a nota.",
    obs: "Não atualizar Nome Fantasia e Razão Social. Conferir o CEP: o do OMIE está sempre correto.",
  },
  {
    n: 5,
    fase: "Cadastro do cliente e cotação de frete",
    responsavel: "Supply",
    titulo: "Cotar frete no Smart Envio",
    caminho:
      "Simular Fretes > preencher CEP, peso e dimensões > Realizar cotação > escolher a transportadora com melhor valor e prazo",
    descricao: "Registrar a transportadora escolhida na planilha.",
  },
  {
    n: 6,
    fase: "Emissão fiscal (NF de bobina)",
    responsavel: "Supply",
    titulo: "Emitir NF de remessa no OMIE",
    caminho:
      "Remessa de Produto > Exibir todos > abrir nota parecida, só bobina > Duplicar > trocar CNPJ do cliente (Medicina ou Odontologia, se clínica) > ajustar quantidade > Departamento 0006 Aluguel > Transportadora > Informações Adicionais: número do card do Jira > Salvar > Concluir Remessa",
    descricao: "A nota é a base do cálculo de tributação da próxima fase.",
    obs: "Duplicar nota da mesma UF, dentro ou fora de São Paulo, por causa do CFOP.",
  },
  {
    n: 7,
    fase: "Emissão fiscal (NF de bobina)",
    responsavel: "Supply",
    titulo: "Registrar número da NF na planilha",
    caminho: "OMIE > Exibir todos",
    descricao:
      "Copiar o número gerado e anotar na coluna NF: será usado na etapa de tributação e no envio.",
  },
  {
    n: 8,
    fase: "Tributação estadual (DIFAL e GNRE)",
    responsavel: "Supply",
    titulo: "A entrega é dentro de São Paulo?",
    descricao:
      "Notas para dentro de São Paulo não pagam DIFAL e seguem direto para o envio físico. Notas para outros estados exigem a guia GNRE, Guia Nacional de Recolhimento de Tributos Estaduais.",
    decisao: true,
    saida: "Não, outro estado",
  },
  {
    n: 9,
    fase: "Tributação estadual (DIFAL e GNRE)",
    responsavel: "Supply",
    titulo: "Gerar guia no Portal GNRE",
    caminho:
      "Selecionar UF favorecida > Tipo GNRE Simples > Inscrito UF Favorecida: Não > preencher dados do remetente (CNPJ, Razão Social, endereço, UF, município, CEP) > Receita: sempre 100102 ICMS Consumidor Final Não Contribuinte Outra UF por Operação > Documento de Origem: Nota Fiscal + número da nota",
    descricao: "A guia é emitida por nota, com base no destino da entrega.",
  },
  {
    n: 10,
    fase: "Tributação estadual (DIFAL e GNRE)",
    responsavel: "Supply",
    titulo: "Buscar valor do ICMS e preencher a guia",
    caminho:
      "No OMIE, abrir a mesma NF > Itens da Remessa > duplo clique no item > aba ICMS > copiar Valor do ICMS > colar em Valor Principal no GNRE, junto com Período de Referência, Data de Vencimento e Data de Pagamento > Validar > Emitir",
    descricao: "O valor precisa espelhar exatamente o ICMS da nota.",
  },
  {
    n: 11,
    fase: "Tributação estadual (DIFAL e GNRE)",
    responsavel: "Supply e Financeiro",
    titulo: "Salvar guia e enviar para o Financeiro",
    caminho:
      "Salvar PDF no padrão 'NF [número] [Estado] [Valor ICMS]', por exemplo NF 3810 DF 6.43",
    descricao: "Enviar por e-mail ao Financeiro para pagamento.",
    obs: "Quando o Financeiro enviar o comprovante, imprimir e colocar na caixa da bobina junto com a nota fiscal.",
  },
  {
    n: 12,
    fase: "Envio físico e acompanhamento",
    responsavel: "Supply",
    titulo: "Imprimir etiqueta",
    caminho:
      "Smart Envio > Imprimir Etiquetas > localizar a NF > Etiqueta 10x15 + Documento simplificado 10x15 > imprimir na Brother QL-800",
    descricao: "Etiqueta e documento simplificado vão colados na caixa.",
  },
  {
    n: 13,
    fase: "Envio físico e acompanhamento",
    responsavel: "Supply",
    titulo: "Empacotar e solicitar coleta",
    caminho:
      "Smart Envio > Solicitar Coleta > selecionar 'Administradora Cartão De Crédito Todos S.A.'",
    descricao:
      "Conferir NF por pedido e empacotar a bobina com a nota fiscal e o comprovante do DIFAL, quando houver.",
    obs: "Solicitar coleta antes das 11h, no mesmo dia do envio.",
  },
  {
    n: 14,
    fase: "Envio físico e acompanhamento",
    responsavel: "Supply",
    titulo: "Atualizar rastreio e marcar Em Trânsito",
    caminho:
      "Planilha: código de rastreio, site de rastreio, previsão de entrega e status. Jira: abrir o card, preencher NF, código e site de rastreio > alterar status para 'Em Trânsito'",
    descricao: "Mantém o card e a planilha alinhados para o follow-up semanal.",
  },
  {
    n: 15,
    fase: "Envio físico e acompanhamento",
    responsavel: "Supply",
    titulo: "Finalizar após a entrega",
    caminho:
      "Copiar o código de rastreio > conferir status no Smart Envio (Coletado, Em Trânsito, Entrega) > voltar ao card no Jira",
    descricao: "Atualizar o status para Entregue, Iniciar Cobrança, ou Concluir para bobina.",
  },
];

const fasesBobina: FaseLogistica[] = [
  { nome: "Captura e organização dos dados (Jira)", tom: "roxo" },
  { nome: "Cadastro do cliente e cotação de frete", tom: "azul" },
  { nome: "Emissão fiscal (NF de bobina)", tom: "laranja" },
  { nome: "Tributação estadual (DIFAL e GNRE)", tom: "ambar" },
  { nome: "Envio físico e acompanhamento", tom: "verde" },
];

const passosPrivateLabel: PassoLogistica[] = [
  {
    n: 1,
    fase: "Triagem e envio para produção (Portal de TODOS)",
    responsavel: "Supply",
    titulo: "Abrir Solicitações de Cartões",
    caminho: "Portal de TODOS > aba Pedidos > Solicitações de Cartões",
    descricao: "Ponto de entrada de todos os pedidos de carteirinha.",
  },
  {
    n: 2,
    fase: "Triagem e envio para produção (Portal de TODOS)",
    responsavel: "Supply",
    titulo: "Verificar o status de cada pedido",
    descricao:
      "Pedido confirmado: liberado para seguir para produção. Pedido cancelado: não atuar, preencher CANCELADO nos campos ID da Softnex, OP e Lote. Pedido pendente: o solicitante não confirmou, alterar o status para 'Pedido confirmado' e seguir com a produção. Duplicidade de solicitação: cancelar uma das solicitações e seguir com a outra.",
    decisao: true,
    saida: "Pedidos confirmados",
  },
  {
    n: 3,
    fase: "Triagem e envio para produção (Portal de TODOS)",
    responsavel: "Supply",
    titulo: "Verificar a modalidade do cartão",
    descricao:
      "Cartão Verde ou Cartão de Time define o fabricante da produção: padrão código 2, Thomas Greg; outras opções 30 Valid e 60 Idemia. Cartões de time têm código próprio por time.",
  },
  {
    n: 4,
    fase: "Triagem e envio para produção (Portal de TODOS)",
    responsavel: "Supply",
    titulo: "Enviar pedidos confirmados para a Softnex",
    caminho: "Selecionar as linhas confirmadas > campo Ação: 'Enviar pedido para Softnex' > Ir",
    descricao:
      "Mensagem de confirmação esperada: 'Pedidos enviados com sucesso, aguarde processamento'.",
  },
  {
    n: 5,
    fase: "Triagem e envio para produção (Portal de TODOS)",
    responsavel: "Supply",
    titulo: "Aguardar o ID da Softnex",
    descricao:
      "Atualizar a página após alguns minutos até o Portal de TODOS preencher automaticamente o campo 'ID da softnex'.",
  },
  {
    n: 6,
    fase: "Produção dos cartões (portal Softnex e CredTODOS)",
    responsavel: "Supply",
    titulo: "Acessar o portal Softnex no dia seguinte",
    caminho: "credtodos.softnex.com.br > Adesão > Produção de cartões > Cartões aguardando emissão",
    descricao: "A produção só aparece no portal no dia seguinte ao envio.",
  },
  {
    n: 7,
    fase: "Produção dos cartões (portal Softnex e CredTODOS)",
    responsavel: "Supply",
    titulo: "Filtrar pelo período desejado",
    caminho: "Preencher data inicial e final em 'Cartão cadastrado entre' e aplicar o filtro",
    descricao: "Usar a flag de confirmação para conferir o conjunto correto de cartões.",
  },
  {
    n: 8,
    fase: "Produção dos cartões (portal Softnex e CredTODOS)",
    responsavel: "Supply",
    titulo: "Selecionar todos os cartões disponíveis",
    caminho: "Lista de cartões aguardando produção > campo 'Escolha uma opção' > Selecionar Todos",
    descricao: "A seleção define o lote que será produzido.",
  },
  {
    n: 9,
    fase: "Produção dos cartões (portal Softnex e CredTODOS)",
    responsavel: "Supply",
    titulo: "Solicitar a produção de todos os registros",
    caminho: "Mesmo campo > Solicitar Todos os Registros > confirmar em OK",
    descricao: "O sistema processa e retorna os lotes gerados.",
  },
  {
    n: 10,
    fase: "Produção dos cartões (portal Softnex e CredTODOS)",
    responsavel: "Supply",
    titulo: "Obter o número do lote e preencher no Portal de TODOS",
    caminho:
      "Abrir o arquivo do lote (ícone de página) > identificar o número do lote e os dados do CDT > voltar ao Portal de TODOS e preencher o campo 'Lote' do pedido correspondente",
    descricao: "Esse número de lote é a referência usada depois para o rastreio.",
  },
  {
    n: 11,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply",
    titulo: "Localizar o pedido e obter o número do lote",
    caminho: "Portal de TODOS > buscar pelo nome do CDT > Pesquisar",
    descricao: "Identificar a última solicitação e copiar o número do lote.",
  },
  {
    n: 12,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply",
    titulo: "Entrar no portal Jall",
    caminho: "jall.com.br/auth/login > Entrar com oAuth2 > informar login e senha",
    descricao: "O portal Jall dá acesso aos relatórios de postagem da transportadora.",
  },
  {
    n: 13,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply",
    titulo: "Gerar relatório Unificado",
    caminho:
      "Aba Relatórios > tipo Unificado > Campos Comuns: AR, Bairro, CEP de Destino, Cidade, Código do HAWB, Nome do Recebedor, RG, UF > Campos Baixa: selecionar todos > Tipo de Data: Data de Postagem, período de até 30 dias > marcar 'Encaminhar para e-mail' > Solicitar",
    descricao: "O relatório chega por e-mail com os códigos de rastreio do período.",
  },
  {
    n: 14,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply",
    titulo: "Localizar o CDT no arquivo recebido",
    descricao:
      "Baixar o arquivo enviado por e-mail, localizar o CDT pela Cidade ou CEP e copiar o código HAWB correspondente.",
  },
  {
    n: 15,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply",
    titulo: "Rastrear o código HAWB",
    caminho: "flashcourier.com.br > colar o código HAWB > resolver o captcha > Rastrear",
    descricao: "Verificar o status atual da entrega.",
  },
  {
    n: 16,
    fase: "Rastreio e atualização de status de entrega",
    responsavel: "Supply e CX",
    titulo: "Atualizar o status no Portal de TODOS",
    descricao:
      "Com o status de 'Entregue' confirmado no rastreio, atualizar o pedido correspondente no Portal de TODOS e retornar ao franqueado.",
  },
];

const fasesPrivateLabel: FaseLogistica[] = [
  { nome: "Triagem e envio para produção (Portal de TODOS)", tom: "roxo" },
  { nome: "Produção dos cartões (portal Softnex e CredTODOS)", tom: "ambar" },
  { nome: "Rastreio e atualização de status de entrega", tom: "azul" },
];

const criticosEnvio = [
  "Transcrição manual do Jira e do Portal de TODOS para a planilha: a mesma informação é digitada duas vezes.",
  "DIFAL interestadual: etapa extra com dependência do Financeiro, atrasa a liberação da coleta.",
  "O franqueado não recebe o rastreio automaticamente, só quando o Supply atualiza o portal.",
  "Sem controle de estoque com endereçamento: o serial number é bipado sem sistema de suporte.",
  "Pedidos duplicados são possíveis, o Portal de TODOS não tem trava automática.",
  "A Smart Envios não tem API conhecida, o rastreio é consultado manualmente no site.",
];

export const fluxosLogistica: FluxoLogistica[] = [
  {
    slug: "maquininhas",
    nome: "Envio de maquininhas e TEF",
    resumo:
      "Da solicitação no Portal de TODOS até o gatilho de cobrança no Jira, passando por cadastro no OMIE, nota fiscal, frete, etiqueta e rastreio.",
    sistemas: ["Portal de TODOS", "Planilha POS", "OMIE", "Smart Envio", "Jira"],
    fases: fasesTef,
    imagem: fluxoTef,
    imagemAlt: "Fluxograma detalhado do processo de envio de maquininhas e TEF, em quatro fases",
    passos: passosTef,
    pontosCriticos: criticosEnvio,
    notas: [
      "Pedido novo nasce no Portal de TODOS, feito pelo franqueado.",
      "Troca de maquininha ou impressora nasce no atendimento do CX, que abre o card no Jira.",
      "O mesmo CNPJ pode ter dois segmentos, Medicina e Odonto: confirme para qual segmento o envio está sendo feito.",
    ],
  },
  {
    slug: "bobinas",
    nome: "Envio de bobinas",
    resumo:
      "Pedido solicitado pelo Jira, com uma fase exclusiva de tributação estadual: DIFAL e guia GNRE antes de liberar a coleta para fora de São Paulo.",
    sistemas: ["Jira", "Planilha POS", "OMIE", "Portal GNRE", "Smart Envio"],
    fases: fasesBobina,
    imagem: fluxoBobina,
    imagemAlt:
      "Fluxograma detalhado do processo de envio de bobinas, com a fase de tributação estadual",
    passos: passosBobina,
    pontosCriticos: criticosEnvio,
    notas: [
      "O pedido de bobina nasce no Jira, com filtro fixo do espaço Logística Terminal.",
      "DIFAL e GNRE precisam estar pagos antes de liberar a coleta para fora de São Paulo.",
      "Copiar os dados do card um a um: cópia em bloco quebra o preenchimento da planilha.",
    ],
  },
  {
    slug: "carteirinhas",
    nome: "Carteirinhas Private Label · Softnex",
    resumo:
      "Triagem dos pedidos no Portal de TODOS, produção na Softnex e rastreio pelos portais Jall e Flash Courier até a resposta ao franqueado.",
    sistemas: ["Portal de TODOS", "Portal Softnex CredTODOS", "Portal Jall", "Flash Courier"],
    fases: fasesPrivateLabel,
    imagem: fluxoPrivateLabel,
    imagemAlt:
      "Fluxograma detalhado do processo de envio de cartões Private Label para a Softnex, com acompanhamento de produção",
    passos: passosPrivateLabel,
    pontosCriticos: [
      "Pedidos em 'Pendente': o franqueado não conclui a confirmação e o Supply corrige na mão.",
      "Pedidos duplicados: sem trava automática, a detecção e o cancelamento são manuais.",
      "O cliente não recebe rastreio automático: o processo é reativo, só rastreia quando há reclamação.",
      "Rastreio pela Flash: vários portais, download de relatório e filtro manual, muito trabalhoso.",
      "O rastreio é feito uma vez por semana em lote, o cliente pode ficar dias sem resposta.",
    ],
    notas: [
      "O cartão físico segue necessário: é o meio de identificação do filiado em clínicas e parceiros.",
      "Existem dois grupos: cartão padrão verde e cartões de times, cada um com fabricante homologado.",
      "A transição para o cartão digital está em andamento e o volume físico já vem caindo.",
    ],
  },
  {
    slug: "follow-up",
    nome: "Follow-up de rastreio · atualização semanal",
    resumo:
      "Uma vez por semana o Supply revisa os cards 'Em Trânsito' no Jira, confere a entrega no Smart Envio e atualiza cada card.",
    sistemas: ["Jira", "Smart Envio"],
    fases: [
      { nome: "Acompanhamento", tom: "azul" },
      { nome: "Fechamento", tom: "verde" },
    ],
    imagem: fluxoTef,
    imagemAlt: "Fluxograma de referência do acompanhamento de entregas",
    passos: [
      {
        n: 1,
        fase: "Acompanhamento",
        responsavel: "Supply",
        titulo: "Filtrar os cards 'Em Trânsito' no Jira",
        descricao: "Listar todos os envios pendentes de confirmação de entrega.",
      },
      {
        n: 2,
        fase: "Acompanhamento",
        responsavel: "Supply",
        titulo: "Pegar o código de rastreio de cada card",
        descricao: "Copiar o código de rastreio registrado anteriormente em cada card.",
      },
      {
        n: 3,
        fase: "Acompanhamento",
        responsavel: "Supply",
        titulo: "Consultar o status no Smart Envio",
        descricao:
          "Colar o código e verificar o status atual: coletado, em trânsito, entregue ou com ocorrência.",
      },
      {
        n: 4,
        fase: "Fechamento",
        responsavel: "Supply",
        titulo: "Atualizar o status do card no Jira",
        descricao:
          "Se entregue: mover para 'Entregue' e depois 'Iniciar Cobrança'. Se houver ocorrência: registrar no card e acionar o CX.",
      },
    ],
    pontosCriticos: [
      "Processo repetitivo e totalmente automatizável, hoje consome uma janela semanal do time.",
      "Depende de a Smart Envios disponibilizar API ou webhook de rastreio.",
    ],
  },
];

export type AutomacaoLogistica = {
  titulo: string;
  descricao: string;
  preRequisito: string;
  complexidade: "Baixa" | "Baixa a média" | "Média" | "Alta";
  prioridade: "Alta" | "Média" | "Baixa";
};

export const automacoesLogistica: AutomacaoLogistica[] = [
  {
    titulo: "Jira para planilha, transcrição automática",
    descricao:
      "O N8N monitora novos cards no Jira e preenche a planilha de controle de envio com todos os dados do pedido.",
    preRequisito: "Acesso à API do Jira",
    complexidade: "Baixa",
    prioridade: "Alta",
  },
  {
    titulo: "Planilha para NF-e, geração automática da nota",
    descricao:
      "Os dados da planilha alimentam os campos do sistema de nota fiscal, eliminando a digitação manual.",
    preRequisito: "Verificar API do sistema NF-e (Cred)",
    complexidade: "Baixa a média",
    prioridade: "Alta",
  },
  {
    titulo: "Follow-up de rastreio automático",
    descricao:
      "Verificação semanal do status dos cards 'Em Trânsito', atualização automática no Jira e alerta quando houver ocorrência.",
    preRequisito: "API da Smart Envios",
    complexidade: "Baixa",
    prioridade: "Alta",
  },
  {
    titulo: "Notificação de rastreio ao franqueado",
    descricao:
      "A cada mudança de etapa (expedido, em trânsito, entregue), envio automático de e-mail ou WhatsApp com o código de rastreio.",
    preRequisito: "API da Smart Envios e e-mail do cadastro do pedido",
    complexidade: "Média",
    prioridade: "Média",
  },
  {
    titulo: "Detecção de pedidos duplicados",
    descricao:
      "Monitorar novos pedidos no Portal de Todos e identificar duplicidade (mesmo franqueado, mesmo item, intervalo menor que 30 dias), alertando o Supply antes do processamento.",
    preRequisito: "Acesso à API do Portal de Todos",
    complexidade: "Média",
    prioridade: "Média",
  },
  {
    titulo: "Aviso de pedidos em 'Pendente'",
    descricao:
      "Monitorar pedidos com status Pendente e notificar o franqueado para concluir a confirmação.",
    preRequisito: "Acesso à API do Portal de Todos",
    complexidade: "Baixa",
    prioridade: "Média",
  },
  {
    titulo: "DIFAL: geração da guia e envio ao Financeiro",
    descricao:
      "Detectar envios para fora de São Paulo, preencher a guia DIFAL e encaminhar ao Financeiro com os dados da nota.",
    preRequisito: "Verificar se o sistema de DIFAL tem API ou formulário web",
    complexidade: "Média",
    prioridade: "Média",
  },
  {
    titulo: "Controle de estoque com endereçamento",
    descricao:
      "Após o inventário inicial, manter a rastreabilidade de cada serial number com endereçamento de estoque.",
    preRequisito: "Inventário físico inicial e definição da estrutura de estoque",
    complexidade: "Alta",
    prioridade: "Baixa",
  },
];

export const papeisLogistica = [
  {
    area: "Supply e Logística",
    responsabilidade:
      "Executa os fluxos: emite notas, embala, bipa seriais, rastreia entregas e atualiza os cards no Jira.",
  },
  {
    area: "CX e Atendimento",
    responsabilidade:
      "Abre cards no Jira para pedidos de troca e fala com o cliente sobre o status da entrega.",
  },
  {
    area: "Financeiro",
    responsabilidade:
      "Recebe a guia DIFAL dos envios interestaduais, paga e devolve o comprovante ao Supply.",
  },
  {
    area: "Franquia",
    responsabilidade: "Faz o pedido no Portal de Todos e acompanha a entrega.",
  },
  {
    area: "Produto e Processos",
    responsabilidade:
      "Adapta o Portal de Todos aos novos fluxos de solicitação e faz as pontes de integração entre sistemas.",
  },
];

export const sistemasLogistica: Tool[] = [
  {
    slug: "portal-de-todos",
    nome: "Portal de Todos",
    categoria: "Portal interno",
    descricao:
      "Pedidos de maquininhas, bobinas, impressoras e carteirinhas, com os dados do franqueado e o campo de rastreio.",
    quemUtiliza: ["Supply", "Franquias"],
    comoSolicitarAcesso: ["Solicitar login e senha ao time de Produto", "Acesso via web"],
    tutoriais: [
      {
        titulo: "Como tratar pedidos pendentes e duplicados",
        fluxo: "carteirinhas",
        tipo: "Passo a passo",
      },
    ],
  },
  {
    slug: "jira-logistica",
    nome: "Jira",
    categoria: "Gestão de demandas",
    descricao:
      "Cards de solicitação, status de entrega e controle de serial number. Os cards avançam por fases até 'Iniciar Cobrança'.",
    quemUtiliza: ["Supply", "CX"],
    comoSolicitarAcesso: ["Solicitar acesso interno ao time de Processos e TI"],
    tutoriais: [{ titulo: "Fases do card de envio", fluxo: "bobinas", tipo: "Documento" }],
  },
  {
    slug: "nfe-cred",
    nome: "NF-e · sistema da credenciadora (Cred)",
    categoria: "Fiscal",
    descricao: "Emissão das notas fiscais de remessa dos equipamentos.",
    quemUtiliza: ["Supply"],
    comoSolicitarAcesso: ["Login e senha liberados pela credenciadora"],
    tutoriais: [{ titulo: "Emitir nota de remessa", fluxo: "maquininhas", tipo: "Passo a passo" }],
  },
  {
    slug: "smart-envios",
    nome: "Smart Envios",
    categoria: "Transporte",
    descricao:
      "Cotação e contratação de frete e geração da etiqueta de envio. Hoje sem API conhecida: consulta manual.",
    quemUtiliza: ["Supply"],
    comoSolicitarAcesso: ["Login de parceiro solicitado ao contato comercial"],
    tutoriais: [
      { titulo: "Cotar frete e gerar etiqueta", fluxo: "maquininhas", tipo: "Passo a passo" },
    ],
  },
  {
    slug: "portal-flash",
    nome: "Portal da Flash",
    categoria: "Transporte",
    descricao:
      "Relatório unificado com o código AR por lote e rastreio individual das carteirinhas por código AR.",
    quemUtiliza: ["Supply"],
    comoSolicitarAcesso: ["Acesso web liberado pela transportadora"],
    tutoriais: [
      {
        titulo: "Extrair relatório e rastrear pelo código AR",
        fluxo: "carteirinhas",
        tipo: "Passo a passo",
      },
    ],
  },
  {
    slug: "portal-soft-next",
    nome: "Portal da Soft Next",
    categoria: "Fabricante",
    descricao:
      "Envio dos pedidos de produção de carteirinhas e geração do arquivo TXT com o número de lote.",
    quemUtiliza: ["Supply"],
    comoSolicitarAcesso: ["Acesso web liberado pelo fabricante"],
    tutoriais: [
      {
        titulo: "Solicitar produção e confirmar lote",
        fluxo: "carteirinhas",
        tipo: "Passo a passo",
      },
    ],
  },
  {
    slug: "planilha-controle-envio",
    nome: "Planilha de controle de envio",
    categoria: "Controle",
    descricao:
      "Controle de pedidos, serial numbers e rastreio. Alimentada por transcrição manual dos cards do Jira.",
    quemUtiliza: ["Supply"],
    comoSolicitarAcesso: ["Compartilhamento solicitado ao time de Supply"],
    tutoriais: [
      { titulo: "Preenchimento padrão da planilha", fluxo: "maquininhas", tipo: "Documento" },
    ],
  },
];
