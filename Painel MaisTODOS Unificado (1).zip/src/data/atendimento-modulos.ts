import {
  Users,
  Wallet,
  Undo2,
  CreditCard,
  ShieldAlert,
  ScrollText,
  type LucideIcon,
} from "lucide-react";
import type { ModuloOperacional } from "@/data/permissoes";

/**
 * Módulos de Atendimento do App. A casa deles é Operação · App.
 * Todos são OPERAÇÃO: quem pode usar cada um está declarado em
 * src/data/permissoes.ts, através do campo `modulo`.
 */
export type AtendimentoModulo = {
  to: string;
  slug: string;
  nome: string;
  descricao: string;
  icon: LucideIcon;
  /** Chave do módulo operacional na fonte única de verdade de permissões. */
  modulo: ModuloOperacional;
};

export const atendimentoModulos: AtendimentoModulo[] = [
  {
    to: "/atendimento/filiados",
    slug: "filiados",
    nome: "Gerenciamento de Filiados",
    descricao: "Busca por CPF, card de contexto e atualização ou remoção de contato.",
    icon: Users,
    modulo: "atendimento_filiados",
  },
  {
    to: "/atendimento/cashback",
    slug: "cashback",
    nome: "Cashback",
    descricao: "Consulta do saldo do filiado e liberação em lote.",
    icon: Wallet,
    modulo: "atendimento_cashback",
  },
  {
    to: "/atendimento/estornos",
    slug: "estornos",
    nome: "Estornos",
    descricao: "Solicitação e acompanhamento de estornos com confirmação humana.",
    icon: Undo2,
    modulo: "atendimento_estornos",
  },
  {
    to: "/atendimento/carteirinhas",
    slug: "carteirinhas",
    nome: "Carteirinhas",
    descricao: "Emissão e consulta de carteirinhas nas bases Softnex e Metabase.",
    icon: CreditCard,
    modulo: "atendimento_carteirinhas",
  },
  {
    to: "/atendimento/n2",
    slug: "n2",
    nome: "Painel N2",
    descricao: "Ações restritas de engenharia e suporte de segundo nível.",
    icon: ShieldAlert,
    modulo: "atendimento_n2",
  },
  {
    to: "/atendimento/auditoria",
    slug: "auditoria",
    nome: "Auditoria",
    descricao: "Registro de todas as ações sensíveis executadas pelo time.",
    icon: ScrollText,
    // A gravação continua para todos os papéis; só a leitura é de gestor e admin.
    modulo: "auditoria",
  },
];
