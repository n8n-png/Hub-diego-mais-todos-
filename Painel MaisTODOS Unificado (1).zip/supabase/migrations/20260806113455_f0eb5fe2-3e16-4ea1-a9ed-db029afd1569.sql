-- 1) Novos papéis de Atendimento no enum de papéis existente
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'atendimento_n1';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'atendimento_n2';

-- 2) Auditoria das ações sensíveis da área de Atendimento
CREATE TABLE public.atendimento_auditoria (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  user_name text,
  modulo text NOT NULL,
  acao text NOT NULL,
  alvo text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  resultado text NOT NULL DEFAULT 'sucesso',
  observacao text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.atendimento_auditoria TO authenticated;
GRANT ALL ON public.atendimento_auditoria TO service_role;

ALTER TABLE public.atendimento_auditoria ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuario registra sua propria acao"
  ON public.atendimento_auditoria FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuario le suas proprias acoes"
  ON public.atendimento_auditoria FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admin e gestor leem toda a auditoria"
  ON public.atendimento_auditoria FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'gestor'));

CREATE INDEX atendimento_auditoria_created_at_idx
  ON public.atendimento_auditoria (created_at DESC);