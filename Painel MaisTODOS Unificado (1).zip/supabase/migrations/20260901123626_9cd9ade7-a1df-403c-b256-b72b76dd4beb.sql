-- 1) Privilégios por tabela, substituindo o GRANT amplo aplicado por laço.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM authenticated;

-- Papéis e liberações: leitura apenas. Escrita só por service role no servidor.
GRANT SELECT ON public.user_roles TO authenticated;
GRANT SELECT ON public.user_area_access TO authenticated;

-- Auditoria imutável: registrar e consultar.
GRANT SELECT, INSERT ON public.atendimento_auditoria TO authenticated;

-- Perfis: a própria linha, conforme RLS.
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;

-- Consultas da IA: o app grava a pergunta e lê o histórico.
GRANT SELECT, INSERT ON public.ai_queries TO authenticated;

-- Consumo de tokens: gravado por service role, lido pelo painel.
GRANT SELECT ON public.ai_usage TO authenticated;

-- Base de conhecimento: leitura ampla, escrita restrita a admin pela RLS.
GRANT SELECT ON public.kb_categories TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.kb_documents TO authenticated;
GRANT SELECT, INSERT, DELETE ON public.kb_chunks TO authenticated;
GRANT SELECT, INSERT ON public.kb_document_versions TO authenticated;

GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;

-- 2) Domínio corporativo também na troca de e-mail.
CREATE OR REPLACE FUNCTION public.enforce_corporate_email_domain()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NULL OR lower(split_part(NEW.email, '@', 2)) <> 'maistodos.com.br' THEN
    RAISE EXCEPTION 'O Hub MaisTODOS é um ambiente interno: apenas e-mails do domínio maistodos.com.br podem criar conta.';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_corporate_email_domain() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS enforce_corporate_email_domain_update ON auth.users;
CREATE TRIGGER enforce_corporate_email_domain_update
BEFORE UPDATE OF email ON auth.users
FOR EACH ROW
WHEN (NEW.email IS DISTINCT FROM OLD.email)
EXECUTE FUNCTION public.enforce_corporate_email_domain();