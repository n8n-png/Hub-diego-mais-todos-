CREATE TABLE public.user_area_access (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  area_slug text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (user_id, area_slug)
);

CREATE INDEX idx_user_area_access_user_id ON public.user_area_access(user_id);

GRANT SELECT ON public.user_area_access TO authenticated;
GRANT ALL ON public.user_area_access TO service_role;

ALTER TABLE public.user_area_access ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuario le suas proprias liberacoes"
ON public.user_area_access FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admin le todas as liberacoes"
ON public.user_area_access FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));