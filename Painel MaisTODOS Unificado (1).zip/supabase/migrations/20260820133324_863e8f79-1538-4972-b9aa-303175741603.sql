DROP POLICY IF EXISTS "Signed in users can read kb files" ON storage.objects;
CREATE POLICY "Read kb files of active documents"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'kb-files'
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR EXISTS (
      SELECT 1 FROM public.kb_documents d
      WHERE d.status = 'ativo'::public.kb_status
        AND d.file_path = storage.objects.name
    )
  )
);

DROP POLICY IF EXISTS "Autenticados leem imagens da base" ON storage.objects;
CREATE POLICY "Read kb images used by active documents"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'kb-imagens'
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR EXISTS (
      SELECT 1 FROM public.kb_documents d
      WHERE d.status = 'ativo'::public.kb_status
        AND position(storage.objects.name in d.content) > 0
    )
  )
);