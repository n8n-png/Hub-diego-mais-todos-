CREATE OR REPLACE FUNCTION public.enforce_corporate_email_domain()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NULL OR lower(split_part(NEW.email, '@', 2)) <> 'maistodos.com.br' THEN
    RAISE EXCEPTION 'O Hub MaisTODOS é um ambiente interno: apenas e-mails do domínio maistodos.com.br podem criar conta.';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_corporate_email_domain() FROM PUBLIC, anon, authenticated;