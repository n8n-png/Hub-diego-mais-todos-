-- 1) Trava de domínio corporativo em novos cadastros
CREATE OR REPLACE FUNCTION public.enforce_corporate_email_domain()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NULL OR lower(split_part(NEW.email, '@', 2)) <> 'maistodos.com.br' THEN
    RAISE EXCEPTION 'O Hub MaisTODOS e um ambiente interno: apenas e-mails do dominio maistodos.com.br podem criar conta.';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.enforce_corporate_email_domain() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS enforce_corporate_email_domain ON auth.users;
CREATE TRIGGER enforce_corporate_email_domain
BEFORE INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.enforce_corporate_email_domain();

-- 2) Base de conhecimento: leitura restrita
DROP POLICY IF EXISTS "Signed in users read chunks" ON public.kb_chunks;
CREATE POLICY "Autenticado le trechos de documentos ativos"
ON public.kb_chunks FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.kb_documents d
    WHERE d.id = kb_chunks.document_id
      AND (d.status = 'ativo'::kb_status OR public.has_role(auth.uid(), 'admin'::app_role))
  )
);

DROP POLICY IF EXISTS "Anyone signed in can read categories" ON public.kb_categories;
CREATE POLICY "Autenticado le categorias"
ON public.kb_categories FOR SELECT TO authenticated
USING (auth.uid() IS NOT NULL);

-- 3) Funções de busca continuam restritas a documentos ativos
CREATE OR REPLACE FUNCTION public.match_kb_chunks(query_embedding vector, match_count integer DEFAULT 6)
RETURNS TABLE(chunk_id uuid, document_id uuid, content text, similarity double precision, title text, version integer, updated_at timestamp with time zone, category_name text, doc_type kb_doc_type)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT c.id, d.id, c.content, 1 - (c.embedding <=> query_embedding),
         d.title, d.version, d.updated_at, cat.name, d.doc_type
  FROM public.kb_chunks c
  JOIN public.kb_documents d ON d.id = c.document_id
  LEFT JOIN public.kb_categories cat ON cat.id = d.category_id
  WHERE d.status = 'ativo' AND c.embedding IS NOT NULL
  ORDER BY c.embedding <=> query_embedding
  LIMIT match_count;
$$;

CREATE OR REPLACE FUNCTION public.search_kb_chunks_text(query_text text, match_count integer DEFAULT 6)
RETURNS TABLE(chunk_id uuid, document_id uuid, content text, similarity double precision, title text, version integer, updated_at timestamp with time zone, category_name text, doc_type kb_doc_type)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  select c.id, d.id, c.content,
         ts_rank(to_tsvector('portuguese', coalesce(d.title,'') || ' ' || c.content),
                 websearch_to_tsquery('portuguese', query_text))::double precision,
         d.title, d.version, d.updated_at, cat.name, d.doc_type
  from public.kb_chunks c
  join public.kb_documents d on d.id = c.document_id
  left join public.kb_categories cat on cat.id = d.category_id
  where d.status = 'ativo'
    and to_tsvector('portuguese', coalesce(d.title,'') || ' ' || c.content)
        @@ websearch_to_tsquery('portuguese', query_text)
  order by 4 desc
  limit match_count;
$$;

-- 4) Privilégios amplos: remover TRUNCATE, REFERENCES e TRIGGER de anon e authenticated
DO $$
DECLARE t record;
BEGIN
  FOR t IN
    SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relkind = 'r'
  LOOP
    EXECUTE format('REVOKE ALL ON public.%I FROM anon', t.relname);
    EXECUTE format('REVOKE ALL ON public.%I FROM authenticated', t.relname);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t.relname);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t.relname);
  END LOOP;
END;
$$;