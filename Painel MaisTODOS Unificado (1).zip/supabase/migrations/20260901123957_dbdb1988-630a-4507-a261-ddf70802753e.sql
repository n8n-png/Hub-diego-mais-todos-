CREATE OR REPLACE FUNCTION public.expurgar_dados_ia_antigos()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  removidas_queries integer := 0;
  removidos_usos integer := 0;
BEGIN
  -- RETENÇÃO: 12 meses para dados operacionais de IA.
  -- Esta função NUNCA toca em public.atendimento_auditoria: a trilha é imutável
  -- por decisão de produto e o prazo de guarda está pendente de definição
  -- jurídica e de compliance.
  DELETE FROM public.ai_queries WHERE created_at < now() - interval '12 months';
  GET DIAGNOSTICS removidas_queries = ROW_COUNT;

  DELETE FROM public.ai_usage WHERE created_at < now() - interval '12 months';
  GET DIAGNOSTICS removidos_usos = ROW_COUNT;

  RETURN jsonb_build_object(
    'ai_queries_removidas', removidas_queries,
    'ai_usage_removidos', removidos_usos,
    'executado_em', now()
  );
END;
$$;

REVOKE ALL ON FUNCTION public.expurgar_dados_ia_antigos() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.expurgar_dados_ia_antigos() FROM anon;
REVOKE ALL ON FUNCTION public.expurgar_dados_ia_antigos() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.expurgar_dados_ia_antigos() TO service_role;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    BEGIN
      PERFORM cron.unschedule('expurgo-ia-mensal');
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
    PERFORM cron.schedule(
      'expurgo-ia-mensal',
      '0 3 1 * *',
      'SELECT public.expurgar_dados_ia_antigos();'
    );
  END IF;
END
$$;