create or replace function public.search_kb_chunks_text(query_text text, match_count integer default 6)
returns table(chunk_id uuid, document_id uuid, content text, similarity double precision,
  title text, version integer, updated_at timestamptz, category_name text, doc_type kb_doc_type)
language sql stable security definer set search_path to 'public' as $$
  select c.id, d.id, c.content,
         ts_rank(to_tsvector('portuguese', coalesce(d.title,'') || ' ' || c.content),
                 websearch_to_tsquery('portuguese', query_text))::double precision,
         d.title, d.version, d.updated_at, cat.name, d.doc_type
  from public.kb_chunks c
  join public.kb_documents d on d.id = c.document_id
  left join public.kb_categories cat on cat.id = d.category_id
  where d.status = 'ativo'
    and to_tsvector('portuguese', coalesce(d.title,'') || ' ' || c.content)
        @@ websearch_to_tsquery('portuguese', query_text)
  order by 4 desc
  limit match_count;
$$;

revoke all on function public.search_kb_chunks_text(text, integer) from public;
revoke all on function public.search_kb_chunks_text(text, integer) from anon;
grant execute on function public.search_kb_chunks_text(text, integer) to authenticated;
grant execute on function public.search_kb_chunks_text(text, integer) to service_role;

create index if not exists kb_chunks_content_fts on public.kb_chunks
  using gin (to_tsvector('portuguese', content));