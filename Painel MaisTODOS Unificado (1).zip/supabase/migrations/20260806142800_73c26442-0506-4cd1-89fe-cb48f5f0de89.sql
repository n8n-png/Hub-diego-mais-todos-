ALTER TYPE public.kb_doc_type ADD VALUE IF NOT EXISTS 'notion';

ALTER TABLE public.kb_documents
  ADD COLUMN IF NOT EXISTS notion_page_id text,
  ADD COLUMN IF NOT EXISTS notion_url text,
  ADD COLUMN IF NOT EXISTS source_updated_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS kb_documents_notion_page_id_key
  ON public.kb_documents (notion_page_id)
  WHERE notion_page_id IS NOT NULL;