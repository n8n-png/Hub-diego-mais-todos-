const APP_URL = "https://mais-tudo-mais-sabio.lovable.app";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  chrome.contextMenus.create({
    id: "maisia-review",
    title: "Revisar com o Copiloto MaisIA",
    contexts: ["selection"],
  });
});

async function openPanel(tab, selection) {
  if (selection) await chrome.storage.local.set({ maisiaSelection: selection });
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (e) {
    chrome.tabs.create({ url: `${APP_URL}/maisia` });
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "maisia-review") openPanel(tab, info.selectionText || "");
});

chrome.action.onClicked.addListener((tab) => openPanel(tab));

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type === "MAISIA_OPEN" && sender.tab) openPanel(sender.tab, msg.selection || "");
});
