const APP_URL = "https://mais-tudo-mais-sabio.lovable.app/maisia";

const frame = document.getElementById("frame");
const fallback = document.getElementById("fallback");
document.getElementById("open-tab").href = APP_URL;
document.getElementById("fallback-link").href = APP_URL;

let loaded = false;
frame.addEventListener("load", () => {
  loaded = true;
});
frame.src = APP_URL;

setTimeout(() => {
  if (!loaded) {
    frame.style.display = "none";
    fallback.style.display = "block";
  }
}, 6000);

chrome.storage.local.get("maisiaSelection").then(({ maisiaSelection }) => {
  if (!maisiaSelection) return;
  const box = document.getElementById("sel");
  document.getElementById("sel-text").textContent =
    maisiaSelection.slice(0, 300) + (maisiaSelection.length > 300 ? "…" : "");
  box.style.display = "block";
  document.getElementById("copy").addEventListener("click", async () => {
    await navigator.clipboard.writeText(maisiaSelection);
    document.getElementById("copy").textContent = "Copiado!";
  });
  chrome.storage.local.remove("maisiaSelection");
});
